"""The command-line entry point: exit codes and printed summary."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from tests.helpers import CUSTOMER_HEADER, basic_customers

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def run_cli(project, *extra: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "run_pipeline.py", "--input-dir", str(project.input_dir), "--db", str(project.db_path),
         "--log-file", str(project.log_file), *extra],
        cwd=PROJECT_ROOT, capture_output=True, text=True)


def test_exit_code_0_and_summary_on_success(project):
    project.write("customers", basic_customers(2))
    done = run_cli(project, "--dataset", "customers")
    assert done.returncode == 0
    assert "SUCCESS" in done.stdout and "run_id:" in done.stdout and "customers" in done.stdout


def test_exit_code_1_and_reason_when_a_dataset_fails(project):
    project.write("customers", [["C000001"]], header=["customer_id"])
    done = run_cli(project)
    assert done.returncode == 1
    assert "FAILED" in done.stdout and "SCHEMA_MISSING_COLUMNS" in done.stdout and "SKIPPED" in done.stdout


def test_exit_code_2_for_a_configuration_error(project):
    done = run_cli(project, "--dataset", "nope")
    assert done.returncode == 2
    assert "CONFIG ERROR" in done.stderr
    assert not project.db_path.exists()


def test_extra_column_warning_is_printed(project):
    project.write("customers", [row + ["x"] for row in basic_customers(1)], header=CUSTOMER_HEADER + ["note"])
    done = run_cli(project, "--dataset", "customers")
    assert done.returncode == 0
    assert "EXTRA_COLUMNS_IGNORED" in done.stdout
