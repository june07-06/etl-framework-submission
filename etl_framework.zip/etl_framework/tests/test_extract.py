"""Extract behaviour: malformed rows, empty input, blank lines, encoding, missing file."""
from __future__ import annotations

import json

from tests.helpers import CUSTOMER_HEADER, assert_reconciled, counts, customer


def test_malformed_row_rejected_with_line_number(project):
    rows = [customer(customer_id="C000001"),
            customer(customer_id="C000002")[:-1],                      # 5 fields instead of 6  -> line 3
            customer(customer_id="C000003") + ["unexpected_extra"],    # 7 fields              -> line 4
            customer(customer_id="C000004", email="four@example.com")]
    project.write("customers", rows)
    result = project.run(["customers"])["customers"]

    assert result.status == "SUCCESS"
    assert counts(result) == (4, 2, 0, 2, 0, 0)          # in, inserted, already, rejected, dups, late
    assert project.rejects() == [(3, "MALFORMED_ROW"), (4, "MALFORMED_ROW")]
    raw = project.scalar("select raw_record from rejected_records where row_number = 3")
    assert json.loads(raw)["raw_fields"][0] == "C000002"          # the original row is kept for replay
    assert_reconciled(result)


def test_empty_file_succeeds_with_zero_counts(project):
    """A file with only a header is a valid empty batch."""
    project.write("customers", [])
    project.write("orders", [])
    results = project.run()
    for name in ("customers", "orders"):
        assert results[name].status == "SUCCESS"
        assert counts(results[name]) == (0, 0, 0, 0, 0, 0)
        assert project.scalar(f"select count(*) from {name}_history") == 0
        assert project.scalar(f"select count(*) from {name}_current") == 0


def test_completely_empty_file_fails_with_no_header(project):
    project.write_raw("customers", b"")
    results = project.run()
    assert results["customers"].status == "FAILED"
    assert results["customers"].failure_reason.startswith("SCHEMA_NO_HEADER")
    assert results["orders"].status == "SKIPPED"


def test_blank_lines_are_ignored_and_not_counted_as_rows(project):
    header = ",".join(CUSTOMER_HEADER)
    line = ",".join(customer())
    project.write_raw("customers", f"{header}\n\n{line}\n\n\n")
    result = project.run(["customers"])["customers"]
    assert counts(result) == (1, 1, 0, 0, 0, 0)
    assert_reconciled(result)


def test_utf8_bom_in_header_is_handled(project):
    """Excel adds a hidden BOM character; the first column name must still be recognised."""
    header = ",".join(CUSTOMER_HEADER)
    project.write_raw("customers", b"\xef\xbb\xbf" + f"{header}\n{','.join(customer())}\n".encode("utf-8"))
    result = project.run(["customers"])["customers"]
    assert result.status == "SUCCESS"
    assert result.rows_inserted == 1


def test_quoted_field_containing_a_comma_is_one_value(project):
    project.write("customers", [customer(full_name="Rao, Asha")])
    result = project.run(["customers"])["customers"]
    assert result.rows_inserted == 1
    assert project.scalar("select full_name from customers_current") == "Rao, Asha"


def test_missing_source_file_fails_with_clear_reason(project):
    result = project.run(["customers"])["customers"]
    assert result.status == "FAILED"
    assert result.failure_reason.startswith("FileNotFoundError")
