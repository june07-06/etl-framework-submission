"""Referential integrity: every order must point to a customer that exists."""
from __future__ import annotations

from tests.helpers import assert_reconciled, basic_customers, counts, customer, order


def test_orphan_order_rejected_invalid_reference(project):
    project.write("customers", basic_customers(2))
    project.write("orders", [order(order_id="O00000001", customer_id="C000001"),
                             order(order_id="O00000002", customer_id="C999999")])
    result = project.run()["orders"]

    assert counts(result) == (2, 1, 0, 1, 0, 0)
    assert project.rejects("orders") == [(3, "INVALID_REFERENCE:customer_id")]
    assert project.query("select order_id from orders_current") == [("O00000001",)]
    assert_reconciled(result)


def test_order_for_a_customer_that_was_itself_rejected_is_an_orphan(project):
    project.write("customers", [customer(customer_id="C000001"),
                                customer(customer_id="C000002", email="")])          # C000002 is rejected
    project.write("orders", [order(customer_id="C000002")])
    results = project.run()
    assert results["customers"].rows_rejected == 1
    assert project.rejects("orders") == [(2, "INVALID_REFERENCE:customer_id")]


def test_orphan_loads_after_parent_arrives(project):
    """Idempotent replay: rerun the SAME orders file once the customer exists."""
    project.write("customers", basic_customers(1))
    project.write("orders", [order(customer_id="C000002")])
    first = project.run()
    assert first["orders"].rows_inserted == 0 and first["orders"].rows_rejected == 1

    project.write("customers", basic_customers(2))                  # the missing customer arrives
    second = project.run()

    assert counts(second["orders"]) == (1, 1, 0, 0, 0, 0)
    assert project.query("select order_id, customer_id from orders_current") == [("O00000001", "C000002")]
    # The reject record is kept for audit and marked as resolved by the later run.
    first_seen, last_seen, resolved = project.query(
        "select first_seen_run_id, last_seen_run_id, resolved_run_id from rejected_records")[0]
    assert first_seen == last_seen == project.run_ids[0]
    assert resolved == project.run_ids[1]
    assert project.scalar("select count(*) from rejected_records") == 1


def test_reference_check_uses_customers_loaded_in_earlier_runs(project):
    project.write("customers", basic_customers(2))
    project.run(["customers"])
    project.write("orders", [order(customer_id="C000002")])
    result = project.run(["orders"])["orders"]                      # customers file is not re-read
    assert counts(result) == (1, 1, 0, 0, 0, 0)


def test_orders_run_before_any_customer_exists_are_all_orphans(project):
    project.write("orders", [order(), order(order_id="O00000002")])
    result = project.run(["orders"])["orders"]
    assert counts(result) == (2, 0, 0, 2, 0, 0)
    assert project.rejects("orders") == [(2, "INVALID_REFERENCE:customer_id"), (3, "INVALID_REFERENCE:customer_id")]
