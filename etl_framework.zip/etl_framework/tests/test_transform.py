"""Transform: deterministic output, exact money, timestamp normalisation, record_hash."""
from __future__ import annotations

import hashlib

import pandas as pd
import pytest

from etl.config_loader import load_dataset_config
from etl.extract import extract_csv
from etl.transform import transform
from etl.validate import normalize
from tests.helpers import HEADERS, customer, order, write_csv


def transformed(tmp_path, dataset: str, rows: list[list[str]]) -> pd.DataFrame:
    """Run extract -> normalize -> transform on a few rows (no database involved)."""
    config = load_dataset_config(f"config/datasets/{dataset}.yaml")
    path = tmp_path / f"{dataset}.csv"
    write_csv(path, HEADERS[dataset], rows)
    return transform(normalize(extract_csv(path).data, config["columns"]), config)


def test_transform_is_deterministic(tmp_path):
    rows = [customer(), customer(customer_id="C000002", email="b@example.com")]
    first = transformed(tmp_path, "customers", rows)
    second = transformed(tmp_path, "customers", rows)
    pd.testing.assert_frame_equal(first, second)
    assert first["record_hash"].tolist() == second["record_hash"].tolist()


def test_record_hash_matches_an_independent_sha256(tmp_path):
    """Pins the hash recipe: changing it would make every already-loaded row look 'different'."""
    frame = transformed(tmp_path, "customers", [customer()])
    canonical = ["C000001", "Asha Rao", "asha@example.com", "IN", "2024-01-15", "2024-01-15T09:00:00Z"]
    expected = hashlib.sha256(chr(31).join(canonical).encode("utf-8")).hexdigest()
    assert frame["record_hash"].iloc[0] == expected


def test_record_hash_ignores_formatting_but_not_content(tmp_path):
    same = transformed(tmp_path, "customers", [
        customer(),
        customer(full_name="  Asha Rao ", email="ASHA@EXAMPLE.COM", updated_at="2024-01-15T09:00:00+00:00"),
        customer(updated_at="2024-01-15 09:00:00"),                       # no offset = UTC
    ])
    assert same["record_hash"].nunique() == 1
    different = transformed(tmp_path, "customers", [customer(), customer(full_name="Asha Rao-Menon")])
    assert different["record_hash"].nunique() == 2


@pytest.mark.parametrize("quantity, price, cents", [
    ("3", "19.99", 5997),                 # 3 x 19.99, exact (binary floating point would give 5996.999...)
    ("1", "0.10", 10),
    ("7", "0.10", 70),
    ("1", "0", 0),
    ("1000", "100000.00", 10_000_000_000),
    ("1", "0.125", 13),                   # 12.5 cents rounds half up
    ("1", "0.124", 12),
])
def test_order_amount_is_exact_whole_cents(tmp_path, quantity, price, cents):
    frame = transformed(tmp_path, "orders", [order(quantity=quantity, unit_price=price)])
    assert int(frame["order_amount_cents"].iloc[0]) == cents


def test_total_of_many_small_amounts_is_exact(tmp_path):
    rows = [order(order_id=f"O{i:08d}", quantity="1", unit_price="0.10") for i in range(1, 1001)]
    frame = transformed(tmp_path, "orders", rows)
    assert int(frame["order_amount_cents"].sum()) == 10_000        # 1000 orders x 10 cents, no drift


@pytest.mark.parametrize("raw, expected", [
    ("2024-02-01T10:00:00Z", "2024-02-01T10:00:00Z"),
    ("2024-02-01T10:00:00+00:00", "2024-02-01T10:00:00Z"),
    ("2024-02-01T10:00:00+05:30", "2024-02-01T04:30:00Z"),            # converted to UTC
    ("2024-02-01T10:00:00-08:00", "2024-02-01T18:00:00Z"),
    ("2024-02-01 10:00:00", "2024-02-01T10:00:00Z"),                  # no offset is read as UTC
    ("2024-02-01T10:00", "2024-02-01T10:00:00Z"),
])
def test_timestamps_are_normalised_to_utc_iso(tmp_path, raw, expected):
    frame = transformed(tmp_path, "orders", [order(order_ts=raw)])
    assert frame["order_ts"].iloc[0] == expected


def test_derived_fields(tmp_path):
    customers = transformed(tmp_path, "customers", [customer(email="Asha@Mail.Example.org")])
    assert customers["email_domain"].iloc[0] == "mail.example.org"
    orders = transformed(tmp_path, "orders", [order(order_ts="2024-02-01T23:30:00-02:00")])
    assert orders["order_date"].iloc[0] == "2024-02-02"               # the UTC date, not the local one


def test_transform_does_not_depend_on_row_order(tmp_path):
    rows = [customer(customer_id=f"C{i:06d}", email=f"u{i}@example.com") for i in range(1, 6)]
    forward = transformed(tmp_path, "customers", rows).set_index("customer_id")
    backward = transformed(tmp_path, "customers", rows[::-1]).set_index("customer_id")
    pd.testing.assert_frame_equal(forward.sort_index(), backward.sort_index())
