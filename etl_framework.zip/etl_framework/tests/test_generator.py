"""The data generator: reproducible, labels kept apart from input, and the pipeline agrees with the labels."""
from __future__ import annotations

import csv
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import pytest

from etl.pipeline import run_pipeline
from generator.generate_data import CUSTOMER_DEFECTS, ORDER_DEFECTS, main as generate
from tests.helpers import CUSTOMER_HEADER, ORDER_HEADER, assert_reconciled

PROJECT_ROOT = Path(__file__).resolve().parents[1]
# Generated data is dated before mid-2025; use a "now" well after that so nothing valid looks like the future.
GENERATOR_NOW = datetime(2030, 1, 1, tzinfo=timezone.utc)


def make(tmp_path: Path, name: str, *args: str) -> tuple[Path, Path]:
    inputs, expected = tmp_path / name / "input", tmp_path / name / "expected"
    generate([*args, "--out-dir", str(inputs), "--expected-dir", str(expected)])
    return inputs, expected


def assert_pipeline_matches_expected(inputs: Path, expected: Path, db_path: Path) -> None:
    """Run the pipeline on generated input and compare EVERYTHING with the separately stored answers."""
    kwargs = dict(input_dir=inputs, db_path=db_path, log_file=db_path.with_suffix(".log"), now=GENERATOR_NOW)
    results = {r.dataset: r for r in run_pipeline("config/pipeline.yaml", **kwargs)}
    summary = json.loads((expected / "expected_summary.json").read_text(encoding="utf-8"))
    con = sqlite3.connect(db_path)
    try:
        for name in ("customers", "orders"):
            want, got = summary[name], results[name]
            assert got.status == "SUCCESS", got.failure_reason
            assert (got.rows_in, got.rows_inserted, got.rows_rejected, got.duplicates_dropped, got.late_records) == \
                   (want["rows_in"], want["rows_inserted"], want["rows_rejected"], want["duplicates_dropped"],
                    want["late_records"]), name
            assert_reconciled(got)
            assert con.execute(f"select count(*) from {name}_history").fetchone()[0] == want["history_rows"]
            assert con.execute(f"select count(*) from {name}_current").fetchone()[0] == want["current_rows"]

        wanted = {(r["dataset"], int(r["row_number"]), r["expected_reject_reasons"])
                  for r in csv.DictReader(open(expected / "expected_rejects.csv", encoding="utf-8"))}
        found = set(con.execute("select dataset, row_number, reject_reasons from rejected_records"))
        assert found == wanted, f"missing={sorted(wanted - found)[:3]} unexpected={sorted(found - wanted)[:3]}"

        for name, columns in (("customers", ["customer_id", "full_name", "email", "country_code", "updated_at"]),
                              ("orders", ["order_id", "customer_id", "status", "order_amount_cents", "updated_at"])):
            wanted_rows = {tuple(r[c] for c in columns) for r in
                           csv.DictReader(open(expected / f"expected_current_{name}.csv", encoding="utf-8"))}
            found_rows = {tuple(str(v) for v in r) for r in
                          con.execute(f"select {', '.join(columns)} from {name}_current")}
            assert found_rows == wanted_rows, name

        totals = [con.execute(f"select sum(order_amount_cents) from orders_{t}").fetchone()[0]
                  for t in ("current", "history")]
        assert totals == [summary["orders"]["current_order_amount_cents_sum"], summary["orders"]["history_order_amount_cents_sum"]]
    finally:
        con.close()

    rerun = run_pipeline("config/pipeline.yaml", **kwargs)                    # a rerun must change nothing
    assert all(r.rows_inserted == 0 for r in rerun)


def test_same_seed_gives_identical_files_and_a_different_seed_does_not(tmp_path):
    first = make(tmp_path, "a", "--seed", "5")
    second = make(tmp_path, "b", "--seed", "5")
    other = make(tmp_path, "c", "--seed", "6")
    names = ["customers.csv", "orders.csv"]
    names_expected = ["expected_rejects.csv", "expected_summary.json", "expected_current_customers.csv",
                      "expected_current_orders.csv"]
    for name in names:
        assert (first[0] / name).read_bytes() == (second[0] / name).read_bytes()
    for name in names_expected:
        assert (first[1] / name).read_bytes() == (second[1] / name).read_bytes()
    assert (first[0] / "orders.csv").read_bytes() != (other[0] / "orders.csv").read_bytes()


def test_generated_files_use_unix_line_endings_on_every_platform(tmp_path):
    """Same seed must give byte-identical files everywhere, so no file may use Windows line endings."""
    inputs, expected = make(tmp_path, "run")
    for folder in (inputs, expected):
        for path in folder.iterdir():
            assert b"\r" not in path.read_bytes(), path.name


def test_answer_key_is_kept_separate_from_input(tmp_path):
    inputs, expected = make(tmp_path, "run")
    assert sorted(p.name for p in inputs.iterdir()) == ["customers.csv", "orders.csv"]
    assert (inputs / "customers.csv").read_text(encoding="utf-8").splitlines()[0] == ",".join(CUSTOMER_HEADER)
    assert (inputs / "orders.csv").read_text(encoding="utf-8").splitlines()[0] == ",".join(ORDER_HEADER)
    assert sorted(p.name for p in expected.iterdir()) == [
        "expected_current_customers.csv", "expected_current_orders.csv", "expected_rejects.csv",
        "expected_summary.json"]


def test_every_defect_type_is_planted_at_any_size(tmp_path):
    for name, args in (("small", ["--customers", "1", "--orders", "1"]), ("default", [])):
        _, expected = make(tmp_path, name, *args)
        defects = {(r["dataset"], r["defect"])
                   for r in csv.DictReader(open(expected / "expected_rejects.csv", encoding="utf-8"))}
        assert {d for ds, d in defects if ds == "customers"} == set(CUSTOMER_DEFECTS)
        assert {d for ds, d in defects if ds == "orders"} == set(ORDER_DEFECTS)


def test_generated_data_contains_the_required_scenarios(tmp_path):
    inputs, expected = make(tmp_path, "run")
    orders = list(csv.reader(open(inputs / "orders.csv", encoding="utf-8")))[1:]
    boundary = {(r[4], r[5]) for r in orders if len(r) == 8}
    assert {("1", "0.00"), ("1000", "100000.00")} <= boundary                  # boundary values that must be accepted
    summary = json.loads((expected / "expected_summary.json").read_text(encoding="utf-8"))
    assert summary["orders"]["late_records"] > 0                                 # out-of-order data
    assert summary["orders"]["duplicates_dropped"] > 0                           # exact duplicates
    assert any(k.startswith("CONFLICTING_DUPLICATE") for k in summary["orders"]["rejects_by_reason"])
    assert "INVALID_REFERENCE:customer_id" in summary["orders"]["rejects_by_reason"]
    assert "MALFORMED_ROW" in summary["customers"]["rejects_by_reason"]


@pytest.mark.parametrize("seed", [42, 7, 2024])
def test_generator_bad_rows_match_expected_labels(tmp_path, seed):
    """The pipeline must reject exactly the rows (and reasons) the generator planted, and load the rest."""
    inputs, expected = make(tmp_path, f"seed{seed}", "--seed", str(seed), "--customers", "60", "--orders", "150")
    assert_pipeline_matches_expected(inputs, expected, tmp_path / f"seed{seed}.db")


def test_committed_sample_matches_its_expected_answers(tmp_path):
    assert_pipeline_matches_expected(PROJECT_ROOT / "data" / "sample", PROJECT_ROOT / "data" / "expected",
                                     tmp_path / "sample.db")


def test_larger_generated_run_still_matches_the_labels(tmp_path):
    inputs, expected = make(tmp_path, "big", "--customers", "2000", "--orders", "10000", "--bad-rate", "0.03")
    assert_pipeline_matches_expected(inputs, expected, tmp_path / "big.db")
