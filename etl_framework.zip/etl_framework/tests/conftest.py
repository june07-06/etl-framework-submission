"""pytest fixtures shared by every test file."""
from __future__ import annotations

import pytest

from tests.helpers import Project


@pytest.fixture
def project(tmp_path) -> Project:
    """A fresh, empty workspace (input folder + SQLite file + log file) for one test."""
    return Project(tmp_path)
