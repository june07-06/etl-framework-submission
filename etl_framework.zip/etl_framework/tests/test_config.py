"""Configuration: mistakes fail early with a clear message, and a new dataset plugs in with config only."""
from __future__ import annotations

import copy

import pytest
import yaml

from etl.config_loader import load_dataset_config, load_pipeline_config, validate_dataset_config
from etl.errors import ConfigError
from etl.pipeline import run_pipeline
from tests.helpers import NOW, assert_reconciled, basic_customers, counts, write_csv


def _orders_config() -> dict:
    return copy.deepcopy(load_dataset_config("config/datasets/orders.yaml"))


def test_project_config_files_are_valid():
    pipeline = load_pipeline_config("config/pipeline.yaml")
    assert [load_dataset_config(p)["name"] for p in pipeline["datasets"]] == ["customers", "orders"]


def _typo(cfg):
    cfg["columns"]["quantity"]["requried"] = True


def _not_snake_case(cfg):
    cfg["columns"]["OrderQty"] = {"type": "integer"}


def _key_not_required(cfg):
    cfg["columns"]["order_id"]["required"] = False


def _key_column_missing(cfg):
    cfg["natural_key"] = ["no_such_column"]


def _unknown_type(cfg):
    cfg["columns"]["quantity"]["type"] = "float"


def _range_on_string(cfg):
    cfg["columns"]["status"]["min"] = 1


def _bad_regex(cfg):
    cfg["columns"]["order_id"]["pattern"] = "([unclosed"


def _unknown_operation(cfg):
    cfg["derived"]["order_date"]["operation"] = "rot13"


def _derived_clashes(cfg):
    cfg["derived"]["status"] = {"operation": "date_part", "sources": ["order_ts"]}


def _reference_column_missing(cfg):
    cfg["references"][0]["column"] = "nope"


def _missing_target(cfg):
    del cfg["target"]


def _unsafe_table_name(cfg):
    cfg["target"]["history_table"] = "orders_history; drop table x"


@pytest.mark.parametrize("break_it, message", [
    (_typo, "requried"),
    (_not_snake_case, "snake_case"),
    (_key_not_required, "must be required"),
    (_key_column_missing, "no_such_column"),
    (_unknown_type, "type must be one of"),
    (_range_on_string, "min/max only apply"),
    (_bad_regex, "invalid regex"),
    (_unknown_operation, "operation must be one of"),
    (_derived_clashes, "clashes"),
    (_reference_column_missing, "nope"),
    (_missing_target, "target"),
    (_unsafe_table_name, "snake_case"),
])
def test_bad_dataset_config_fails_early_with_a_clear_message(break_it, message):
    config = _orders_config()
    break_it(config)
    with pytest.raises(ConfigError, match=message):
        validate_dataset_config(config)


def test_invalid_pipeline_config_is_rejected(tmp_path):
    path = tmp_path / "pipeline.yaml"
    base = {"database_path": "a.db", "input_dir": "in", "log_file": "l.log", "reports_dir": "r",
            "datasets": ["x.yaml"]}
    path.write_text(yaml.safe_dump({**base, "validation_mode": "turbo"}), encoding="utf-8")
    with pytest.raises(ConfigError, match="validation_mode"):
        load_pipeline_config(path)
    del base["datasets"]
    path.write_text(yaml.safe_dump(base), encoding="utf-8")
    with pytest.raises(ConfigError, match="datasets"):
        load_pipeline_config(path)


def test_unknown_dataset_name_is_a_config_error_and_creates_no_database(project):
    with pytest.raises(ConfigError, match="nope"):
        run_pipeline("config/pipeline.yaml", input_dir=project.input_dir, db_path=project.db_path,
                     log_file=project.log_file, dataset_names=["nope"], now=NOW)
    assert not project.db_path.exists()


def test_new_dataset_plugs_in_through_config_only(project, tmp_path):
    """The reusability proof: a third dataset ('products') is added with a YAML file and a CSV, no Python change."""
    products_config = {
        "name": "products", "source_file": "products.csv", "natural_key": ["sku"], "version_column": "updated_at",
        "target": {"history_table": "products_history", "current_table": "products_current"},
        "columns": {
            "sku": {"type": "string", "required": True, "pattern": "^P[0-9]{4}$"},
            "product_name": {"type": "string", "required": True},
            "category": {"type": "string", "required": True, "allowed_values": ["toys", "books"]},
            "price": {"type": "decimal", "required": True, "min": 0},
            "updated_at": {"type": "timestamp", "required": True, "not_in_future": True},
        },
        "references": [],
        "derived": {"price_cents": {"operation": "multiply_to_cents", "sources": ["price"]}},
    }
    products_path = tmp_path / "products.yaml"
    products_path.write_text(yaml.safe_dump(products_config), encoding="utf-8")
    base = load_pipeline_config("config/pipeline.yaml")
    pipeline_path = tmp_path / "pipeline_with_products.yaml"
    pipeline_path.write_text(yaml.safe_dump({
        "database_path": str(project.db_path), "input_dir": str(project.input_dir),
        "log_file": str(project.log_file), "reports_dir": str(tmp_path),
        "datasets": [str(p) for p in base["datasets"]] + [str(products_path)]}), encoding="utf-8")

    project.write("customers", basic_customers(1))
    project.write("orders", [])
    write_csv(project.input_dir / "products.csv", ["sku", "product_name", "category", "price", "updated_at"], [
        ["P0001", "Robot", "toys", "19.99", "2024-01-01T00:00:00Z"],
        ["P0002", "Novel", "books", "-1", "2024-01-01T00:00:00Z"],                 # out of range
        ["P0003", "Gadget", "tools", "5", "2024-01-01T00:00:00Z"],                 # category not allowed
        ["P0001", "Robot", "toys", "19.99", "2024-01-01T00:00:00Z"],               # exact duplicate
    ])
    results = {r.dataset: r for r in run_pipeline(pipeline_path, now=NOW)}

    assert results["products"].status == "SUCCESS"
    assert counts(results["products"]) == (4, 1, 0, 2, 1, 0)
    assert_reconciled(results["products"])
    assert project.query("select sku, price_cents from products_current") == [("P0001", 1999)]
    assert project.rejects("products") == [(3, "OUT_OF_RANGE:price"), (4, "INVALID_ALLOWED_VALUE:category")]
    again = {r.dataset: r for r in run_pipeline(pipeline_path, now=NOW)}          # and it is idempotent too
    assert counts(again["products"]) == (4, 0, 1, 2, 1, 0)
