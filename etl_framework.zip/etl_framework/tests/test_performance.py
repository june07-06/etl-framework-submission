"""Performance tooling: the optimization must not change results, and the benchmark runner must be trustworthy."""
from __future__ import annotations

import contextlib
import io
import sqlite3

import pandas as pd
import pytest

import run_benchmark
from etl import transform
from generator.generate_data import main as generate
from tests.helpers import order
from tests.test_transform import transformed


def make_input(tmp_path, customers=150, orders=400, seed=42):
    folder = tmp_path / f"input_{seed}"
    with contextlib.redirect_stdout(io.StringIO()):
        generate(["--customers", str(customers), "--orders", str(orders), "--seed", str(seed),
                  "--out-dir", str(folder), "--expected-dir", str(tmp_path / f"expected_{seed}")])
    return folder


# ---------- the optimization must not change a single stored value ----------

def test_optimized_and_baseline_runs_store_identical_data(tmp_path):
    folder = make_input(tmp_path)
    run_benchmark.run_once(folder, tmp_path / "before.db", baseline=True)
    run_benchmark.run_once(folder, tmp_path / "after.db", baseline=False)

    before, after = run_benchmark.fingerprints(tmp_path / "before.db"), run_benchmark.fingerprints(tmp_path / "after.db")
    assert before == after
    assert len(set(before.values())) == len(before)                      # five different tables, five different hashes


def test_transform_gives_identical_frames_with_and_without_the_optimization(tmp_path):
    rows = [order(quantity="1000", unit_price="100000.00"), order(order_id="O00000002", unit_price="0.125"),
            order(order_id="O00000003", quantity="1", unit_price="0"), order(order_id="O00000004", unit_price="19.99")]
    for case in (rows, []):                                              # including an empty batch
        optimized = transformed(tmp_path, "orders", case)
        with run_benchmark.baseline_mode():
            baseline = transformed(tmp_path, "orders", case)
        pd.testing.assert_frame_equal(optimized, baseline)


def test_baseline_mode_swaps_the_helper_and_always_restores_it():
    original = transform._plain
    values = pd.Series(["a", "b"], dtype="string")
    assert transform._plain(values) == ["a", "b"] and isinstance(transform._plain(values), list)
    with run_benchmark.baseline_mode():
        assert transform._plain(values) is values                       # "before": the pandas column itself
    assert transform._plain is original
    with pytest.raises(RuntimeError), run_benchmark.baseline_mode():
        raise RuntimeError("something failed inside the block")
    assert transform._plain is original                                  # restored even after an error


# ---------- fingerprints ----------

def test_fingerprint_ignores_run_ids_and_timestamps(tmp_path):
    folder = make_input(tmp_path)
    run_benchmark.run_once(folder, tmp_path / "a.db", baseline=False)
    run_benchmark.run_once(folder, tmp_path / "b.db", baseline=False)    # a different run_id and loaded_at
    assert run_benchmark.fingerprints(tmp_path / "a.db") == run_benchmark.fingerprints(tmp_path / "b.db")


def test_fingerprint_detects_a_changed_value_and_a_different_input(tmp_path):
    folder = make_input(tmp_path)
    run_benchmark.run_once(folder, tmp_path / "a.db", baseline=False)
    reference = run_benchmark.fingerprints(tmp_path / "a.db")

    connection = sqlite3.connect(tmp_path / "a.db")
    connection.execute("update orders_current set quantity = quantity + 1 where rowid = 1")
    connection.commit()
    connection.close()
    changed = run_benchmark.fingerprints(tmp_path / "a.db")
    assert [t for t in reference if reference[t] != changed[t]] == ["orders_current"]

    other = make_input(tmp_path, seed=7)
    run_benchmark.run_once(other, tmp_path / "c.db", baseline=False)
    assert run_benchmark.fingerprints(tmp_path / "c.db") != reference


# ---------- measurements ----------

def test_run_once_reports_consistent_timings(tmp_path):
    result = run_benchmark.run_once(make_input(tmp_path), tmp_path / "t.db", baseline=False)
    assert set(result["datasets"]) == {"customers", "orders"}
    for name, data in result["datasets"].items():
        stages = [data[s] for s in run_benchmark.STAGES]
        assert all(s >= 0 for s in stages), name
        assert sum(stages) <= data["total"] + 0.05, name                 # stages cannot add up to more than the total
        assert data["rows_in"] > 0
    assert result["wall"] >= max(d["total"] for d in result["datasets"].values())


def test_benchmark_failure_is_reported_not_hidden(tmp_path):
    folder = tmp_path / "empty_input"
    folder.mkdir()                                                       # no CSV files at all
    with pytest.raises(RuntimeError, match="benchmark run failed"):
        run_benchmark.run_once(folder, tmp_path / "x.db", baseline=False)


# ---------- the runner and its report ----------

def run_main(tmp_path, *extra):
    report = tmp_path / "performance.md"
    code = run_benchmark.main(["--customers", "1200", "--orders", "6000", "--repeats", "2",
                               "--report-file", str(report), *extra])
    return code, report.read_text(encoding="utf-8")


def test_runner_writes_a_complete_report_and_exits_zero(tmp_path, capsys):
    code, text = run_main(tmp_path)
    assert code == 0
    for heading in ("# Performance report", "## 1. Where the time goes", "## 2. The optimization",
                    "## 3. How it scales", "## Notes and limits"):
        assert heading in text
    assert "**Output unchanged:** **yes**" in text
    for stage in ("extract", "validate", "transform", "load"):
        assert f"| {stage} |" in text
    assert "rows per second" in text and "Profile of one **before** run" in text and "Slow per-value pandas accesses" in text
    assert "| 5,000 |" in text                                           # a smaller size was measured for scaling too


def test_runner_can_skip_scaling_and_profile(tmp_path):
    code, text = run_main(tmp_path, "--no-scaling", "--no-profile")
    assert code == 0
    assert "## 3. How it scales" not in text and "Profile of one" not in text


def test_runner_exits_nonzero_when_the_two_variants_differ(tmp_path, monkeypatch):
    """If an 'optimization' changed the stored data, the runner must say so and fail."""
    @contextlib.contextmanager
    def broken_baseline():
        original = transform._plain
        transform._plain = lambda series: list(reversed(series.to_numpy(dtype=object).tolist()))
        try:
            yield
        finally:
            transform._plain = original

    monkeypatch.setattr(run_benchmark, "baseline_mode", broken_baseline)
    code, text = run_main(tmp_path, "--no-scaling", "--no-profile")
    assert code == 1
    assert "**NO - the outputs differ!**" in text
