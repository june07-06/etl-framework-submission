"""Schema changes in the source file: missing, extra and duplicated columns."""
from __future__ import annotations

from tests.helpers import CUSTOMER_HEADER, assert_reconciled, basic_customers, customer, order


def test_missing_required_column_fails_batch(project):
    header = [c for c in CUSTOMER_HEADER if c != "email"]
    rows = [[v for c, v in zip(CUSTOMER_HEADER, customer()) if c != "email"]]
    project.write("customers", rows, header=header)
    project.write("orders", [order()])

    results = project.run()
    assert results["customers"].status == "FAILED"
    assert results["customers"].failure_reason == "SCHEMA_MISSING_COLUMNS: ['email']"
    assert results["customers"].rows_inserted == 0
    assert not project.table_exists("customers_history")           # nothing was written
    assert results["orders"].status == "SKIPPED"                  # a child is not run after its parent failed
    assert results["orders"].failure_reason.startswith("UPSTREAM_FAILED")


def test_fixing_the_file_and_rerunning_succeeds(project):
    project.write("customers", [["C000001", "A B"]], header=["customer_id", "full_name"])
    project.write("orders", [order()])
    assert project.run()["customers"].status == "FAILED"

    project.write("customers", basic_customers(1))
    results = project.run()
    assert results["customers"].status == "SUCCESS"
    assert results["orders"].status == "SUCCESS"
    assert results["orders"].rows_inserted == 1


def test_extra_column_warns_and_loads(project):
    project.write("customers", [customer() + ["hello"]], header=CUSTOMER_HEADER + ["note"])
    result = project.run(["customers"])["customers"]

    assert result.status == "SUCCESS"
    assert result.rows_inserted == 1
    assert result.warnings == ["EXTRA_COLUMNS_IGNORED: ['note']"]
    assert "EXTRA_COLUMNS_IGNORED" in project.scalar("select warnings from pipeline_runs")
    columns = [row[1] for row in project.query("pragma table_info(customers_history)")]
    assert "note" not in columns                                   # the extra column is ignored
    assert_reconciled(result)


def test_duplicated_column_name_fails(project):
    project.write("customers", [customer() + ["x@example.com"]], header=CUSTOMER_HEADER + ["email"])
    result = project.run(["customers"])["customers"]
    assert result.status == "FAILED"
    assert result.failure_reason == "SCHEMA_DUPLICATE_COLUMNS: ['email']"
