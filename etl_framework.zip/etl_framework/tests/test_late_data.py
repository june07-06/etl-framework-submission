"""Late-arriving and out-of-order versions: kept in history, never allowed to replace newer current data."""
from __future__ import annotations

from tests.helpers import assert_reconciled, basic_customers, counts, customer, order


def test_late_version_kept_in_history_not_current(project):
    """The newer version is listed first in the file; the older one arrives after it."""
    project.write("customers", [
        customer(full_name="Asha Rao-Menon", updated_at="2024-06-01T09:00:00Z"),
        customer(full_name="Asha Rao", updated_at="2024-01-15T09:00:00Z"),
    ])
    result = project.run(["customers"])["customers"]

    assert counts(result) == (2, 2, 0, 0, 0, 1)                       # one late record
    assert project.scalar("select count(*) from customers_history") == 2
    assert project.query("select full_name, updated_at from customers_current") == \
        [("Asha Rao-Menon", "2024-06-01T09:00:00Z")]
    assert_reconciled(result)


def test_versions_in_normal_order_are_not_late(project):
    project.write("customers", [customer(updated_at="2024-01-15T09:00:00Z"),
                                customer(full_name="Newer", updated_at="2024-06-01T09:00:00Z")])
    result = project.run(["customers"])["customers"]
    assert result.late_records == 0
    assert project.scalar("select full_name from customers_current") == "Newer"


def test_older_status_does_not_overwrite_current(project):
    """Domain edge case: an old 'placed' version arriving after 'delivered' must not roll the order back."""
    project.write("customers", basic_customers(1))
    project.write("orders", [order(status="delivered", updated_at="2024-02-05T12:00:00Z"),
                             order(status="placed", updated_at="2024-02-01T10:00:00Z")])
    result = project.run()["orders"]

    assert counts(result) == (2, 2, 0, 0, 0, 1)
    assert project.scalar("select status from orders_current") == "delivered"
    assert sorted(r[0] for r in project.query("select status from orders_history")) == ["delivered", "placed"]


def test_late_batch_in_a_later_run_is_a_backfill(project):
    """Run 1 loads the newest version; run 2 (a backfill file) adds an older one without changing 'current'."""
    project.write("customers", [customer(full_name="Newest", updated_at="2024-06-01T09:00:00Z")])
    project.run(["customers"])

    project.write("customers", [customer(full_name="Oldest", updated_at="2024-01-15T09:00:00Z")])
    result = project.run(["customers"])["customers"]

    assert counts(result) == (1, 1, 0, 0, 0, 1)
    assert project.scalar("select count(*) from customers_history") == 2
    assert project.query("select full_name from customers_current") == [("Newest",)]


def test_newer_version_in_a_later_run_replaces_current(project):
    project.write("customers", [customer(full_name="Old", updated_at="2024-01-15T09:00:00Z")])
    project.run(["customers"])
    project.write("customers", [customer(full_name="New", updated_at="2024-06-01T09:00:00Z")])
    result = project.run(["customers"])["customers"]

    assert counts(result) == (1, 1, 0, 0, 0, 0)
    assert project.query("select full_name from customers_current") == [("New",)]
    assert project.scalar("select count(*) from customers_history") == 2


def test_versions_are_compared_as_instants_not_as_text(project):
    """'10:00+05:30' is 04:30 UTC, which is EARLIER than '06:00Z', although the text sorts later."""
    project.write("customers", [
        customer(full_name="Earlier instant", updated_at="2024-03-01T10:00:00+05:30"),
        customer(full_name="Later instant", updated_at="2024-03-01T06:00:00Z"),
    ])
    project.run(["customers"])
    assert project.scalar("select full_name from customers_current") == "Later instant"


def test_history_keeps_every_version_with_its_lineage(project):
    project.write("customers", [customer(updated_at="2024-01-15T09:00:00Z"),
                                customer(full_name="Newer", updated_at="2024-06-01T09:00:00Z")])
    project.run(["customers"])
    rows = project.query("select updated_at, source_file, source_row_number, run_id from customers_history "
                         "order by updated_at")
    assert rows == [("2024-01-15T09:00:00Z", "customers.csv", 2, project.run_ids[0]),
                    ("2024-06-01T09:00:00Z", "customers.csv", 3, project.run_ids[0])]
