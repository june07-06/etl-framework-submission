"""Shared test helpers: build small CSV files, run the pipeline, query the database.

Every test gets its own temporary folder and SQLite file, so tests never touch real data
and never affect each other.
"""
from __future__ import annotations

import csv
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from etl.pipeline import DatasetResult, run_pipeline

# A fixed "current time" for every test run, so future-timestamp checks are deterministic.
NOW = datetime(2025, 6, 1, 12, 0, 0, tzinfo=timezone.utc)

CUSTOMER_HEADER = ["customer_id", "full_name", "email", "country_code", "signup_date", "updated_at"]
ORDER_HEADER = ["order_id", "customer_id", "order_ts", "status", "quantity", "unit_price", "currency", "updated_at"]
HEADERS = {"customers": CUSTOMER_HEADER, "orders": ORDER_HEADER}


def customer(**overrides: str) -> list[str]:
    """One valid customer row (as a list of text fields); override any column by name."""
    row = {"customer_id": "C000001", "full_name": "Asha Rao", "email": "asha@example.com", "country_code": "IN",
           "signup_date": "2024-01-15", "updated_at": "2024-01-15T09:00:00Z"}
    row.update(overrides)
    return [row[c] for c in CUSTOMER_HEADER]


def order(**overrides: str) -> list[str]:
    """One valid order row (as a list of text fields); override any column by name."""
    row = {"order_id": "O00000001", "customer_id": "C000001", "order_ts": "2024-02-01T10:00:00Z",
           "status": "placed", "quantity": "2", "unit_price": "10.00", "currency": "INR",
           "updated_at": "2024-02-01T10:00:00Z"}
    row.update(overrides)
    return [row[c] for c in ORDER_HEADER]


def basic_customers(count: int = 3) -> list[list[str]]:
    """C000001..C00000N, each with its own id, name and email."""
    return [customer(customer_id=f"C{i:06d}", full_name=f"User {i}", email=f"user{i}@example.com")
            for i in range(1, count + 1)]


def write_csv(path: Path, header: list[str], rows: list[list[str]]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


class Project:
    """A throwaway pipeline workspace: input folder, SQLite database and log file."""

    def __init__(self, root: Path) -> None:
        self.input_dir = root / "input"
        self.input_dir.mkdir()
        self.db_path = root / "warehouse.db"
        self.log_file = root / "pipeline.log"
        self.run_ids: list[str] = []

    def write(self, dataset: str, rows: list[list[str]], header: list[str] | None = None) -> Path:
        path = self.input_dir / f"{dataset}.csv"
        write_csv(path, header or HEADERS[dataset], rows)
        return path

    def write_raw(self, dataset: str, content: bytes | str) -> Path:
        path = self.input_dir / f"{dataset}.csv"
        path.write_bytes(content if isinstance(content, bytes) else content.encode("utf-8"))
        return path

    def run(self, datasets: list[str] | None = None, now: datetime = NOW) -> dict[str, DatasetResult]:
        """Run the pipeline once; returns {dataset name: result}."""
        results = run_pipeline("config/pipeline.yaml", input_dir=self.input_dir, db_path=self.db_path,
                               log_file=self.log_file, dataset_names=datasets, now=now)
        self.run_ids.append(results[0].run_id)
        return {r.dataset: r for r in results}

    def query(self, sql: str, params: tuple = ()) -> list[tuple]:
        con = sqlite3.connect(self.db_path)
        try:
            return con.execute(sql, params).fetchall()
        finally:
            con.close()

    def scalar(self, sql: str, params: tuple = ()) -> Any:
        return self.query(sql, params)[0][0]

    def table_exists(self, name: str) -> bool:
        return bool(self.query("select 1 from sqlite_master where type = 'table' and name = ?", (name,)))

    def rejects(self, dataset: str | None = None) -> list[tuple[int, str]]:
        """[(row_number, reject_reasons)] ordered by row number."""
        if dataset:
            return self.query("select row_number, reject_reasons from rejected_records where dataset = ? "
                              "order by row_number", (dataset,))
        return self.query("select row_number, reject_reasons from rejected_records order by dataset, row_number")


def counts(result: DatasetResult) -> tuple[int, int, int, int, int, int]:
    """(rows_in, inserted, already_loaded, rejected, duplicates_dropped, late_records)."""
    return (result.rows_in, result.rows_inserted, result.rows_already_loaded, result.rows_rejected,
            result.duplicates_dropped, result.late_records)


def assert_reconciled(result: DatasetResult) -> None:
    """The core promise: every input row is loaded, already loaded, rejected or a counted duplicate."""
    accounted = (result.rows_inserted + result.rows_already_loaded + result.rows_rejected
                 + result.duplicates_dropped)
    assert result.rows_in == accounted, f"{result.dataset}: rows_in={result.rows_in} but accounted={accounted}"


def write_mixed_input(project: Project) -> None:
    """A small realistic input with good rows, a late version, duplicates, orphans and several kinds of bad rows."""
    project.write("customers", basic_customers(3) + [
        customer(customer_id="C000004", email=""),                                       # missing email
        customer(customer_id="C000005", email="e@example.com")[:-1],                     # malformed
        customer(customer_id="C000001", full_name="Newest", updated_at="2024-06-01T09:00:00Z"),
        customer(customer_id="C000001", full_name="Oldest", updated_at="2023-12-01T09:00:00Z"),   # late
        basic_customers(1)[0]])                                                          # exact duplicate of row 2
    project.write("orders", [
        order(order_id="O00000001", customer_id="C000001"),
        order(order_id="O00000002", customer_id="C000002", status="delivered", updated_at="2024-02-05T12:00:00Z"),
        order(order_id="O00000002", customer_id="C000002", status="placed", updated_at="2024-02-01T10:00:00Z"),
        order(order_id="O00000003", customer_id="C777777"),                              # orphan
        order(order_id="O00000004", quantity="0"),                                       # out of range
        order(order_id="O00000005", customer_id="C000003", quantity="3", unit_price="19.99")])
