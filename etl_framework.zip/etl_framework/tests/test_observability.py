"""run_id, the pipeline_runs metrics table, and the JSON log."""
from __future__ import annotations

import json
import re

from tests.helpers import basic_customers, customer, order

ISO_UTC = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


def _log_lines(project) -> list[dict]:
    return [json.loads(line) for line in project.log_file.read_text(encoding="utf-8").splitlines()]


def test_pipeline_runs_has_one_row_per_dataset_with_counts_and_timings(project):
    project.write("customers", basic_customers(2) + [customer(customer_id="C000003", email="")])
    project.write("orders", [order()])
    results = project.run()

    rows = project.query("select dataset, status, rows_in, rows_inserted, rows_already_loaded, rows_rejected, "
                         "duplicates_dropped, late_records, failure_reason from pipeline_runs order by dataset")
    assert rows == [("customers", "SUCCESS", 3, 2, 0, 1, 0, 0, None),
                    ("orders", "SUCCESS", 1, 1, 0, 0, 0, 0, None)]
    assert results["customers"].rows_in == 3
    for started, ended, duration, *timings in project.query(
            "select started_at, ended_at, duration_seconds, extract_seconds, validate_seconds, transform_seconds, "
            "load_seconds from pipeline_runs"):
        assert ISO_UTC.match(started) and ISO_UTC.match(ended) and started <= ended
        assert duration >= 0
        assert all(t is not None and t >= 0 for t in timings)


def test_one_run_id_is_shared_and_stamped_everywhere(project):
    project.write("customers", [customer(), customer(customer_id="C000002", email="")])
    project.write("orders", [order()])
    project.run()
    run_id = project.run_ids[0]

    assert {r[0] for r in project.query("select run_id from pipeline_runs")} == {run_id}
    assert {r[0] for r in project.query("select run_id from customers_history")} == {run_id}
    assert {r[0] for r in project.query("select run_id from orders_current")} == {run_id}
    assert {r[0] for r in project.query("select first_seen_run_id from rejected_records")} == {run_id}
    assert all(line["run_id"] == run_id for line in _log_lines(project))


def test_every_run_gets_a_new_run_id(project):
    project.write("customers", basic_customers(1))
    project.run(["customers"])
    project.run(["customers"])
    assert len(set(project.run_ids)) == 2
    assert project.scalar("select count(distinct run_id) from pipeline_runs") == 2


def test_log_is_json_lines_with_the_expected_steps(project):
    project.write("customers", basic_customers(1))
    project.run(["customers"])
    lines = _log_lines(project)

    assert all({"ts", "level", "run_id", "message"} <= set(line) for line in lines)
    assert all(ISO_UTC.match(line["ts"]) for line in lines)
    steps = [line.get("step") for line in lines if line.get("dataset") == "customers"]
    assert steps == ["start", "extract", "validate", "validate", "finish"]
    finish = next(line for line in lines if line.get("step") == "finish")
    assert finish["status"] == "SUCCESS" and finish["rows_in"] == 1 and finish["rows_inserted"] == 1


def test_failure_reason_is_logged_and_stored(project):
    project.write("customers", [["C000001"]], header=["customer_id"])
    project.run(["customers"])

    errors = [line for line in _log_lines(project) if line["level"] == "ERROR"]
    assert len(errors) == 1
    assert errors[0]["dataset"] == "customers"
    assert errors[0]["failure_reason"].startswith("SCHEMA_MISSING_COLUMNS")
    assert "exception" in errors[0]                                             # the traceback is kept for debugging
    row = project.query("select status, failure_reason from pipeline_runs")[0]
    assert row[0] == "FAILED" and row[1].startswith("SCHEMA_MISSING_COLUMNS")


def test_warning_is_logged_for_an_extra_column(project):
    project.write("customers", [customer() + ["x"]], header=["customer_id", "full_name", "email", "country_code",
                                                             "signup_date", "updated_at", "note"])
    project.run(["customers"])
    warnings = [line for line in _log_lines(project) if line["level"] == "WARNING"]
    assert [w["extra_columns"] for w in warnings] == [["note"]]
