"""Row-level validation: missing values, types, formats, allowed values, ranges, future dates."""
from __future__ import annotations

import pytest

from tests.helpers import HEADERS, NOW, assert_reconciled, basic_customers, counts, customer, order


def _run_one(project, dataset: str, row: list[str]):
    """Load three good customers, then one test row of the given dataset; return that dataset's result."""
    project.write("customers", basic_customers() if dataset == "orders" else [row])
    if dataset == "orders":
        project.write("orders", [row])
    return project.run([dataset] if dataset == "customers" else None)[dataset]


# ---------- missing required values (nulls) ----------

@pytest.mark.parametrize("column", HEADERS["customers"])
def test_missing_required_customer_field_rejected(project, column):
    result = _run_one(project, "customers", customer(**{column: ""}))
    assert project.rejects() == [(2, f"MISSING_REQUIRED_FIELD:{column}")]
    assert counts(result) == (1, 0, 0, 1, 0, 0)


@pytest.mark.parametrize("column", HEADERS["orders"])
def test_missing_required_order_field_rejected(project, column):
    result = _run_one(project, "orders", order(**{column: ""}))
    assert project.rejects("orders") == [(2, f"MISSING_REQUIRED_FIELD:{column}")]
    assert counts(result) == (1, 0, 0, 1, 0, 0)


def test_whitespace_only_value_counts_as_missing(project):
    _run_one(project, "customers", customer(email="    "))
    assert project.rejects() == [(2, "MISSING_REQUIRED_FIELD:email")]


# ---------- invalid values: one reason code per rule ----------

BAD_VALUES = [
    ("customers", "customer_id", "X12", "INVALID_FORMAT:customer_id"),
    ("customers", "customer_id", "c000001", "INVALID_FORMAT:customer_id"),      # wrong case
    ("customers", "customer_id", "C0000012", "INVALID_FORMAT:customer_id"),     # 7 digits
    ("customers", "email", "a@b", "INVALID_FORMAT:email"),
    ("customers", "email", "no-at-sign.example.com", "INVALID_FORMAT:email"),
    ("customers", "email", "a b@example.com", "INVALID_FORMAT:email"),
    ("customers", "country_code", "XX", "INVALID_ALLOWED_VALUE:country_code"),
    ("customers", "country_code", "in", "INVALID_ALLOWED_VALUE:country_code"),  # matching is case-sensitive
    ("customers", "signup_date", "2024-02-30", "INVALID_TYPE:signup_date"),     # not a real date
    ("customers", "signup_date", "31/12/2024", "INVALID_TYPE:signup_date"),
    ("customers", "signup_date", "2999-01-01", "FUTURE_TIMESTAMP:signup_date"),
    ("customers", "updated_at", "not-a-timestamp", "INVALID_TYPE:updated_at"),
    ("customers", "updated_at", "2999-01-01T00:00:00Z", "FUTURE_TIMESTAMP:updated_at"),
    ("orders", "order_id", "ORD-1", "INVALID_FORMAT:order_id"),
    ("orders", "quantity", "abc", "INVALID_TYPE:quantity"),
    ("orders", "quantity", "2.5", "INVALID_TYPE:quantity"),
    ("orders", "quantity", "1e3", "INVALID_TYPE:quantity"),
    ("orders", "quantity", "0", "OUT_OF_RANGE:quantity"),
    ("orders", "quantity", "-1", "OUT_OF_RANGE:quantity"),
    ("orders", "quantity", "1001", "OUT_OF_RANGE:quantity"),
    ("orders", "unit_price", "abc", "INVALID_TYPE:unit_price"),
    ("orders", "unit_price", "-0.01", "OUT_OF_RANGE:unit_price"),
    ("orders", "unit_price", "100000.01", "OUT_OF_RANGE:unit_price"),
    ("orders", "status", "lost", "INVALID_ALLOWED_VALUE:status"),
    ("orders", "status", "Placed", "INVALID_ALLOWED_VALUE:status"),              # case-sensitive
    ("orders", "currency", "EUR", "INVALID_ALLOWED_VALUE:currency"),
    ("orders", "order_ts", "not-a-time", "INVALID_TYPE:order_ts"),
    ("orders", "order_ts", "2999-01-01T00:00:00Z", "FUTURE_TIMESTAMP:order_ts"),
]


@pytest.mark.parametrize("dataset, column, value, reason", BAD_VALUES)
def test_invalid_value_rejected_with_reason(project, dataset, column, value, reason):
    build = customer if dataset == "customers" else order
    result = _run_one(project, dataset, build(**{column: value}))
    assert project.rejects(dataset) == [(2, reason)]
    assert result.rows_inserted == 0
    assert_reconciled(result)


def test_multiple_failures_in_one_row_give_one_reject_with_all_reasons(project):
    _run_one(project, "orders", order(status="lost", unit_price="-5"))
    assert project.rejects("orders") == [(2, "INVALID_ALLOWED_VALUE:status; OUT_OF_RANGE:unit_price")]


# ---------- boundary values ----------

@pytest.mark.parametrize("quantity", ["1", "1000"])
@pytest.mark.parametrize("unit_price", ["0", "0.00", "0.01", "100000", "100000.00"])
def test_boundary_values_are_accepted(project, quantity, unit_price):
    result = _run_one(project, "orders", order(quantity=quantity, unit_price=unit_price))
    assert project.rejects("orders") == []
    assert result.rows_inserted == 1


def test_timestamp_exactly_now_is_accepted_but_one_second_later_is_future(project):
    project.write("customers", [customer(customer_id="C000001", updated_at="2025-06-01T12:00:00Z"),
                                customer(customer_id="C000002", email="b@example.com",
                                         updated_at="2025-06-01T12:00:01Z")])
    result = project.run(["customers"])["customers"]
    assert counts(result) == (2, 1, 0, 1, 0, 0)
    assert project.rejects() == [(3, "FUTURE_TIMESTAMP:updated_at")]


def test_date_today_is_accepted_but_tomorrow_is_future(project):
    assert NOW.date().isoformat() == "2025-06-01"
    project.write("customers", [customer(customer_id="C000001", signup_date="2025-06-01"),
                                customer(customer_id="C000002", email="b@example.com", signup_date="2025-06-02")])
    result = project.run(["customers"])["customers"]
    assert counts(result) == (2, 1, 0, 1, 0, 0)
    assert project.rejects() == [(3, "FUTURE_TIMESTAMP:signup_date")]


# ---------- cleaning that happens before validation ----------

def test_whitespace_is_trimmed_and_email_is_lowercased(project):
    project.write("customers", [customer(full_name="  Asha Rao  ", email="  ASHA@Example.COM ")])
    project.run(["customers"])
    assert project.query("select full_name, email, email_domain from customers_current") == \
        [("Asha Rao", "asha@example.com", "example.com")]


def test_columns_can_be_in_any_order(project):
    header = list(reversed(HEADERS["customers"]))
    project.write("customers", [list(reversed(customer()))], header=header)
    result = project.run(["customers"])["customers"]
    assert result.rows_inserted == 1
    assert project.scalar("select customer_id from customers_current") == "C000001"


# ---------- reject records must be traceable ----------

def test_reject_record_is_traceable_to_its_source(project):
    project.write("customers", [customer(), customer(customer_id="C000002", email="")])
    project.run(["customers"])
    row = project.query("select dataset, source_file, row_number, reject_reasons, raw_record, first_seen_run_id, "
                        "last_seen_run_id, resolved_run_id from rejected_records")[0]
    assert row[:4] == ("customers", "customers.csv", 3, "MISSING_REQUIRED_FIELD:email")
    assert '"customer_id": "C000002"' in row[4]
    assert row[5] == row[6] == project.run_ids[0]
    assert row[7] is None
