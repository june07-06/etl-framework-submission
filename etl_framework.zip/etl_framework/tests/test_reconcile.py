"""Reconciliation report: passes on good data, and FAILS when the data is corrupted on purpose."""
from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pytest

from etl.config_loader import load_dataset_config, load_pipeline_config
from etl.reconcile import ReportError, build_report, render_markdown
from generator.generate_data import main as generate
from tests.helpers import write_mixed_input

PROJECT_ROOT = Path(__file__).resolve().parents[1]
GENERATOR_NOW = datetime(2030, 1, 1, tzinfo=timezone.utc)


def datasets():
    return [load_dataset_config(p) for p in load_pipeline_config("config/pipeline.yaml")["datasets"]]


def report_for(project, *, expected_dir=None, with_source=True):
    connection = sqlite3.connect(project.db_path)
    try:
        return build_report(connection, datasets(), input_dir=project.input_dir if with_source else None,
                            expected_dir=expected_dir, database=str(project.db_path))
    finally:
        connection.close()


def failed(report) -> set[tuple[str, str]]:
    return {(c.dataset, c.name) for c in report.checks if not c.passed}


def corrupt(project, *statements: str) -> None:
    connection = sqlite3.connect(project.db_path)
    try:
        for statement in statements:
            connection.execute(statement)
        connection.commit()
    finally:
        connection.close()


def sql_statements(path: Path):
    """Split a .sql file into complete statements (comment-only lines between them are skipped)."""
    buffer = ""
    for line in path.read_text(encoding="utf-8").splitlines(keepends=True):
        if line.strip().startswith("--") and not buffer:
            continue
        buffer += line
        if sqlite3.complete_statement(buffer):
            yield buffer.strip()
            buffer = ""


# ---------- good data passes ----------

def test_clean_run_passes_every_check(project):
    write_mixed_input(project)
    project.run()
    report = report_for(project)

    assert report.passed, [(c.dataset, c.name, c.violations, c.detail) for c in report.checks if not c.passed]
    names = {(c.dataset, c.name) for c in report.checks}
    assert {("orders", "reference_customer_id"), ("orders", "aggregate_order_amount_cents"),
            ("customers", "current_is_latest_history_row"), ("all", "rejects_traceable"),
            ("customers", "source_rows_equal_rows_in")} <= names
    assert len(report.checks) >= 25


def test_report_still_passes_after_reruns_and_an_orphan_replay(project):
    write_mixed_input(project)
    project.run()
    project.run()
    # the missing customer arrives, so the orphan order loads on the next run
    customers = project.input_dir / "customers.csv"
    customers.write_text(customers.read_text(encoding="utf-8") + "C777777,Late Arrival,late@example.com,IN,"
                         "2024-01-01,2024-01-01T00:00:00Z\n", encoding="utf-8")
    project.run()
    report = report_for(project)
    assert report.passed, [(c.dataset, c.name, c.detail) for c in report.checks if not c.passed]
    assert project.scalar("select count(*) from rejected_records where resolved_run_id is not null") == 1


def test_run_table_explains_every_input_row(project):
    write_mixed_input(project)
    project.run()
    runs = {r["dataset"]: r for r in report_for(project).runs}
    for run in runs.values():
        assert run["rows_in"] == (run["rows_inserted"] + run["rows_already_loaded"] + run["rows_rejected"]
                                  + run["duplicates_dropped"])
    assert runs["customers"]["duplicates_dropped"] == 1 and runs["customers"]["late_records"] == 1


# ---------- corrupted data fails: each corruption must trip the matching check ----------

ORDER_COPY = ("insert into orders_history (order_id, customer_id, order_ts, status, quantity, unit_price, currency, "
              "updated_at, order_amount_cents, order_date, record_hash, run_id, source_file, source_row_number, "
              "loaded_at) select 'O99999999', 'C777777', order_ts, status, quantity, unit_price, currency, "
              "updated_at, order_amount_cents, order_date, record_hash, run_id, source_file, source_row_number, "
              "loaded_at from orders_history limit 1")
BAD_REJECT = ("insert into rejected_records (reject_id, dataset, source_file, row_number, reject_reasons, raw_record, "
              "first_seen_run_id, first_seen_at, last_seen_run_id, last_seen_at) values "
              "('x', 'orders', 'orders.csv', 1, '', 'not json', 'r', 't', 'r', 't')")

CORRUPTIONS = [
    ("a history row is deleted", ["delete from orders_history where rowid = (select min(rowid) from orders_history)"],
     [("orders", "history_equals_inserted")]),
    ("a current row no longer matches the newest history row",
     ["update orders_current set record_hash = 'tampered'"], [("orders", "current_is_latest_history_row")]),
    ("a current row has no history", ["delete from customers_history where customer_id = 'C000002'"],
     [("customers", "current_has_history")]),
    ("an order points to a customer that does not exist", [ORDER_COPY], [("orders", "reference_customer_id")]),
    ("a run's counts do not add up", ["update pipeline_runs set rows_in = rows_in + 5 where dataset = 'customers'"],
     [("customers", "run_counts_add_up")]),
    ("an order amount is changed by hand", ["update orders_current set order_amount_cents = order_amount_cents + 100"],
     [("orders", "aggregate_order_amount_cents")]),
    ("a reject loses its reason and its original row", [BAD_REJECT], [("all", "rejects_traceable")]),
    ("a reject uses an undocumented reason code",
     ["update rejected_records set reject_reasons = 'MADE_UP_CODE:x' where rowid = (select min(rowid) from rejected_records)"],
     [("all", "reject_reason_codes_known")]),
    ("the latest run of a dataset failed", ["update pipeline_runs set status = 'FAILED' where dataset = 'orders'"],
     [("orders", "latest_run_succeeded")]),
    ("a reject record is missing for the latest run",
     ["delete from rejected_records where dataset = 'orders' and rowid = "
      "(select min(rowid) from rejected_records where dataset = 'orders')"],
     [("orders", "rejects_cover_latest_run")]),
    ("history rows lose their run", ["update customers_history set run_id = 'ghost'"],
     [("customers", "lineage_complete")]),
]


@pytest.mark.parametrize("label, statements, expected_failures", CORRUPTIONS, ids=[c[0] for c in CORRUPTIONS])
def test_corruption_is_detected(project, label, statements, expected_failures):
    write_mixed_input(project)
    project.run()
    assert report_for(project).passed
    corrupt(project, *statements)
    report = report_for(project)
    assert not report.passed
    assert set(expected_failures) <= failed(report), failed(report)


def test_source_file_changed_after_loading_is_detected(project):
    write_mixed_input(project)
    project.run()
    customers = project.input_dir / "customers.csv"
    customers.write_text(customers.read_text(encoding="utf-8") + "C000009,Extra,x@example.com,IN,2024-01-01,"
                         "2024-01-01T00:00:00Z\n", encoding="utf-8")
    assert ("customers", "source_rows_equal_rows_in") in failed(report_for(project))


def test_report_cannot_be_built_before_the_pipeline_has_run(project):
    sqlite3.connect(project.db_path).close()
    with pytest.raises(ReportError, match="pipeline_runs"):
        report_for(project)


# ---------- comparison with the expected answers ----------

@pytest.fixture
def generated(project):
    """Generator output written straight into the project's input folder, plus its expected answers."""
    expected = project.input_dir.parent / "expected"
    generate(["--customers", "40", "--orders", "80", "--out-dir", str(project.input_dir),
              "--expected-dir", str(expected)])
    project.run(now=GENERATOR_NOW)
    return expected


def test_pipeline_output_matches_the_expected_answers(project, generated):
    report = report_for(project, expected_dir=generated)
    expected_checks = [c for c in report.checks if c.section == "expected"]
    assert len(expected_checks) >= 10
    assert report.passed, [(c.dataset, c.name, c.detail) for c in report.checks if not c.passed]
    assert {c.name for c in expected_checks} >= {"expected_run_counts", "expected_rejects", "expected_current_rows",
                                                 "expected_current_order_amount_cents_sum"}


def test_report_still_matches_the_expected_answers_after_a_rerun(project, generated):
    """A rerun inserts nothing (everything is 'already loaded'); the data and the comparison must still pass."""
    project.run(now=GENERATOR_NOW)
    project.run(now=GENERATOR_NOW)
    report = report_for(project, expected_dir=generated)
    assert report.passed, [(c.dataset, c.name, c.detail) for c in report.checks if not c.passed]
    latest = {r["dataset"]: r for r in report.runs}
    assert latest["orders"]["rows_inserted"] == 0 and latest["orders"]["rows_already_loaded"] > 0


def test_a_rerun_that_loaded_the_wrong_number_of_rows_is_still_caught(project, generated):
    project.run(now=GENERATOR_NOW)
    corrupt(project, "update pipeline_runs set rows_already_loaded = rows_already_loaded - 1, rows_rejected = rows_rejected + 1 "
                     "where dataset = 'orders' and rowid = (select max(rowid) from pipeline_runs where dataset = 'orders')")
    failures = failed(report_for(project, expected_dir=generated))
    assert ("orders", "expected_run_counts") in failures


def test_wrong_expected_answers_are_reported_as_differences(project, generated):
    rejects = generated / "expected_rejects.csv"
    lines = rejects.read_text(encoding="utf-8").splitlines()
    rejects.write_text("\n".join(lines[:1] + lines[2:]) + "\n", encoding="utf-8")        # forget one planted reject
    summary = json.loads((generated / "expected_summary.json").read_text(encoding="utf-8"))
    summary["orders"]["current_order_amount_cents_sum"] += 1
    (generated / "expected_summary.json").write_text(json.dumps(summary), encoding="utf-8")

    failures = failed(report_for(project, expected_dir=generated))
    assert any(name == "expected_rejects" for _, name in failures)
    assert ("orders", "expected_current_order_amount_cents_sum") in failures


def test_data_corruption_is_caught_by_the_expected_comparison_too(project, generated):
    corrupt(project, "update orders_current set status = 'placed'")
    assert ("orders", "expected_current_rows") in failed(report_for(project, expected_dir=generated))


# ---------- the Markdown report ----------

def test_markdown_report_shows_sections_and_result(project, generated):
    text = render_markdown(report_for(project, expected_dir=generated))
    for heading in ("# Reconciliation report", "## 1. Run reconciliation", "## 2. Where the rows went",
                    "## 3. Integrity checks", "## 4. Source-to-target", "## 5. Comparison with the expected answers"):
        assert heading in text
    assert "Result: **PASS**" in text and "FAIL" not in text.replace("PASS or FAIL", "")


def test_markdown_report_marks_failures(project):
    write_mixed_input(project)
    project.run()
    corrupt(project, "update orders_current set record_hash = 'tampered'")
    text = render_markdown(report_for(project))
    assert "Result: **FAIL**" in text and "| FAIL |" in text
    assert "section 5 was skipped" in text


# ---------- the command line ----------

def run_report_cli(project, *extra: str) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, "run_report.py", "--db", str(project.db_path),
                           "--report-file", str(project.input_dir.parent / "report.md"), *extra],
                          cwd=PROJECT_ROOT, capture_output=True, text=True)


def test_cli_exit_0_prints_and_saves_the_report(project, generated):
    done = run_report_cli(project, "--input-dir", str(project.input_dir), "--expected-dir", str(generated))
    assert done.returncode == 0, done.stdout + done.stderr
    assert "Result: **PASS**" in done.stdout
    assert "Result: **PASS**" in (project.input_dir.parent / "report.md").read_text(encoding="utf-8")


def test_cli_exit_1_when_a_check_fails(project, generated):
    corrupt(project, "update customers_current set record_hash = 'tampered'")
    done = run_report_cli(project, "--expected-dir", str(generated))
    assert done.returncode == 1
    assert "Result: **FAIL**" in done.stdout


def test_cli_exit_2_when_there_is_no_database(project):
    done = run_report_cli(project)
    assert done.returncode == 2
    assert "REPORT ERROR" in done.stderr


# ---------- the SQL files ----------

def test_reconciliation_sql_returns_zero_violations_on_good_data(project):
    write_mixed_input(project)
    project.run()
    connection = sqlite3.connect(project.db_path)
    results = {name: violations for name, violations in
               (connection.execute(s).fetchone() for s in sql_statements(PROJECT_ROOT / "sql" / "reconciliation.sql"))}
    connection.close()
    assert len(results) >= 14
    assert all(v == 0 for v in results.values()), results


def test_reconciliation_sql_detects_corruption(project):
    write_mixed_input(project)
    project.run()
    corrupt(project, "update orders_current set order_amount_cents = order_amount_cents + 1",
            "update pipeline_runs set rows_in = rows_in + 1 where dataset = 'orders'")
    connection = sqlite3.connect(project.db_path)
    results = dict(connection.execute(s).fetchone() for s in sql_statements(PROJECT_ROOT / "sql" / "reconciliation.sql"))
    connection.close()
    assert results["orders_amount_cents_total"] > 0
    assert results["run_counts_add_up"] > 0


def test_every_sample_query_runs_and_the_main_ones_return_rows(project):
    write_mixed_input(project)
    project.run()
    connection = sqlite3.connect(project.db_path)
    queries = list(sql_statements(PROJECT_ROOT / "sql" / "sample_queries.sql"))
    results = [connection.execute(q).fetchall() for q in queries]
    connection.close()
    assert len(queries) >= 12
    assert results[0], "Q1 (orders by current status) returned nothing"
    # Orders 1 and 5 are still "placed", order 2 is "delivered" (its older "placed" version is only in history).
    assert {status: n for status, n, _ in results[0]} == {"placed": 2, "delivered": 1}
