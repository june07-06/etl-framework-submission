"""Rerun safety: running the same input again must change nothing."""
from __future__ import annotations

from tests.helpers import assert_reconciled, basic_customers, counts, customer, order

TABLES = ["customers_history", "customers_current", "orders_history", "orders_current", "rejected_records"]


def _snapshot(project) -> dict[str, list[tuple]]:
    """Every row of every data table (rejects included), so 'unchanged' really means unchanged."""
    return {t: project.query(f"select * from {t} order by 1, 2") for t in TABLES}


def _mixed_input(project) -> None:
    project.write("customers", basic_customers(3) + [customer(customer_id="C000004", email=""),
                                                     customer(customer_id="C000001", email="a@example.com")[:-1]])
    project.write("orders", [order(order_id="O00000001", customer_id="C000001"),
                             order(order_id="O00000002", customer_id="C000002", status="delivered"),
                             order(order_id="O00000002", customer_id="C000002", status="placed",
                                   updated_at="2024-01-01T10:00:00Z"),
                             order(order_id="O00000003", customer_id="C777777"),       # orphan
                             order(order_id="O00000004", quantity="0")])               # out of range


def test_rerun_is_idempotent(project):
    _mixed_input(project)
    first = project.run()
    before = _snapshot(project)
    second = project.run()
    after = _snapshot(project)

    for name in ("customers", "orders"):
        assert second[name].rows_inserted == 0
        assert second[name].rows_already_loaded == first[name].rows_inserted
        assert second[name].rows_rejected == first[name].rows_rejected          # still reported by every run
        assert_reconciled(first[name])
        assert_reconciled(second[name])
    # ... and no row of any table was added, changed or re-stamped.
    for table in TABLES:
        if table != "rejected_records":
            assert after[table] == before[table], table
    assert len(after["rejected_records"]) == len(before["rejected_records"])


def test_three_reruns_still_change_nothing(project):
    _mixed_input(project)
    project.run()
    before = _snapshot(project)
    for _ in range(3):
        project.run()
    assert [r for t, r in _snapshot(project).items() if t != "rejected_records"] == \
           [r for t, r in before.items() if t != "rejected_records"]


def test_rejected_row_is_stored_once_and_only_last_seen_changes(project):
    project.write("customers", [customer(), customer(customer_id="C000002", email="")])
    project.run(["customers"])
    project.run(["customers"])

    assert project.scalar("select count(*) from rejected_records") == 1
    first_seen, last_seen = project.query("select first_seen_run_id, last_seen_run_id from rejected_records")[0]
    assert first_seen == project.run_ids[0]
    assert last_seen == project.run_ids[1]


def test_changed_record_with_same_key_and_version_is_rejected_not_ignored(project):
    """A stored version must never be silently kept while different data with the same key and version is dropped."""
    project.write("customers", [customer(full_name="Original")])
    project.run(["customers"])
    project.write("customers", [customer(full_name="Changed")])
    result = project.run(["customers"])["customers"]

    assert counts(result) == (1, 0, 0, 1, 0, 0)
    assert project.rejects() == [(2, "CONFLICTING_DUPLICATE:customer_id,updated_at (differs from already loaded record)")]
    assert project.query("select full_name from customers_current") == [("Original",)]
    assert_reconciled(result)


def test_rerun_after_adding_new_rows_loads_only_the_new_ones(project):
    project.write("customers", basic_customers(2))
    project.run(["customers"])
    project.write("customers", basic_customers(3))
    result = project.run(["customers"])["customers"]
    assert counts(result) == (3, 1, 2, 0, 0, 0)
    assert project.scalar("select count(*) from customers_current") == 3
