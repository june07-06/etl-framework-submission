"""Duplicate handling inside one file."""
from __future__ import annotations

from tests.helpers import assert_reconciled, counts, customer, order, basic_customers


def test_exact_duplicate_counted_not_loaded(project):
    project.write("customers", [customer(), customer()])
    result = project.run(["customers"])["customers"]

    assert counts(result) == (2, 1, 0, 0, 1, 0)                   # in, inserted, already, rejected, dups, late
    assert project.scalar("select count(*) from customers_history") == 1
    assert project.scalar("select source_row_number from customers_history") == 2   # the FIRST copy is kept
    assert project.rejects() == []
    assert_reconciled(result)


def test_duplicate_that_differs_only_in_formatting_is_still_a_duplicate(project):
    """Whitespace, e-mail case and timestamp text are cleaned first, so these two rows are the same record."""
    project.write("customers", [
        customer(),
        customer(full_name=" Asha Rao ", email="ASHA@EXAMPLE.COM", updated_at="2024-01-15T09:00:00+00:00"),
    ])
    result = project.run(["customers"])["customers"]
    assert counts(result) == (2, 1, 0, 0, 1, 0)


def test_conflicting_duplicate_rejects_all_copies(project):
    """Same key and version but different content: we cannot know which copy is right."""
    project.write("customers", [customer(), customer(full_name="Someone Else"),
                                customer(customer_id="C000002", email="b@example.com")])
    result = project.run(["customers"])["customers"]

    assert counts(result) == (3, 1, 0, 2, 0, 0)
    reason = "CONFLICTING_DUPLICATE:customer_id,updated_at"
    assert project.rejects() == [(2, reason), (3, reason)]
    assert project.scalar("select count(*) from customers_history where customer_id = 'C000001'") == 0
    assert_reconciled(result)


def test_same_key_with_different_versions_is_not_a_duplicate(project):
    project.write("customers", [customer(updated_at="2024-01-15T09:00:00Z"),
                                customer(full_name="Asha Rao-Menon", updated_at="2024-06-01T09:00:00Z")])
    result = project.run(["customers"])["customers"]
    assert counts(result) == (2, 2, 0, 0, 0, 0)
    assert project.scalar("select count(*) from customers_history") == 2
    assert project.query("select full_name from customers_current") == [("Asha Rao-Menon",)]


def test_conflicting_order_versions_are_rejected_too(project):
    project.write("customers", basic_customers(1))
    project.write("orders", [order(unit_price="10.00"), order(unit_price="12.00")])
    result = project.run()["orders"]
    assert counts(result) == (2, 0, 0, 2, 0, 0)
    assert project.rejects("orders") == [(2, "CONFLICTING_DUPLICATE:order_id,updated_at"),
                                         (3, "CONFLICTING_DUPLICATE:order_id,updated_at")]


def test_every_input_row_is_accounted_for(project):
    """A mixed file: nothing may disappear without being loaded, rejected or counted as a duplicate."""
    project.write("customers", [
        customer(customer_id="C000001"),                                      # valid
        customer(customer_id="C000001"),                                      # exact duplicate
        customer(customer_id="C000002", email=""),                            # missing email
        customer(customer_id="C000003")[:-1],                                 # malformed
        customer(customer_id="C000004", email="d@example.com"),               # conflicting pair ...
        customer(customer_id="C000004", email="d@example.com", full_name="X"),  # ... second copy
        customer(customer_id="C000005", email="e@example.com"),               # valid
    ])
    result = project.run(["customers"])["customers"]
    assert counts(result) == (7, 2, 0, 4, 1, 0)
    assert_reconciled(result)
