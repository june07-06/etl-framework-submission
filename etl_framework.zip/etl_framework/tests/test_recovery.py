"""Failure, rollback and retry: a failed load must leave no half-written data, and a rerun must finish the job."""
from __future__ import annotations

import pytest

import etl.extract
import etl.load
import etl.validate
from tests.helpers import assert_reconciled, basic_customers, counts, order


def test_failure_mid_load_rolls_back_and_retry_succeeds(project, monkeypatch):
    project.write("customers", basic_customers(2))
    project.write("orders", [order(order_id="O00000001", customer_id="C000001"),
                             order(order_id="O00000002", customer_id="C000002"),
                             order(order_id="O00000003", quantity="0")])     # a reject, so the failure point is reached
    real_reject_id = etl.load._reject_id
    calls = []

    def explode_for_orders(dataset, source_file, row_number, raw_record):
        """Fails AFTER the history and current rows were already written inside the transaction."""
        if dataset == "orders":
            calls.append(row_number)
            raise RuntimeError("injected failure after history was written")
        return real_reject_id(dataset, source_file, row_number, raw_record)

    monkeypatch.setattr(etl.load, "_reject_id", explode_for_orders)
    first = project.run()

    assert calls, "the injected failure point was never reached"
    assert first["customers"].status == "SUCCESS"                             # committed before orders started
    assert first["orders"].status == "FAILED"
    assert "injected failure" in first["orders"].failure_reason
    for table in ("orders_history", "orders_current"):
        assert project.scalar(f"select count(*) from {table}") == 0, table    # rolled back, nothing half-written
    assert project.rejects("orders") == []
    assert project.scalar("select count(*) from customers_history") == 2
    assert project.query("select status, failure_reason is not null from pipeline_runs "
                         "where dataset = 'orders'") == [("FAILED", 1)]

    monkeypatch.undo()                                                         # the cause is fixed; just rerun
    second = project.run()

    assert counts(second["customers"]) == (2, 0, 2, 0, 0, 0)                 # already loaded, skipped
    assert counts(second["orders"]) == (3, 2, 0, 1, 0, 0)
    assert project.scalar("select count(*) from orders_current") == 2
    assert project.rejects("orders") == [(4, "OUT_OF_RANGE:quantity")]
    assert_reconciled(second["orders"])


def test_count_mismatch_rolls_everything_back(project, monkeypatch):
    """The reconciliation safety net: if rows do not add up, nothing is committed."""
    project.write("customers", basic_customers(2))
    real_check = etl.validate.check_duplicates

    def claims_a_duplicate_that_does_not_exist(df, config):
        kept, reasons, dropped = real_check(df, config)
        return kept, reasons, dropped + 1

    monkeypatch.setattr(etl.validate, "check_duplicates", claims_a_duplicate_that_does_not_exist)
    result = project.run(["customers"])["customers"]

    assert result.status == "FAILED"
    assert result.failure_reason.startswith("ReconciliationError")
    assert project.scalar("select count(*) from customers_history") == 0
    assert project.scalar("select count(*) from customers_current") == 0


def test_crash_leaves_a_running_row_as_evidence(project, monkeypatch):
    """Even a hard crash (not a normal error) leaves a RUNNING row, so an operator can see what was in flight."""
    project.write("customers", basic_customers(1))

    def crash(path):
        raise KeyboardInterrupt

    monkeypatch.setattr(etl.extract, "extract_csv", crash)
    with pytest.raises(KeyboardInterrupt):
        project.run(["customers"])
    assert project.query("select dataset, status, ended_at from pipeline_runs") == [("customers", "RUNNING", None)]


def test_failed_run_does_not_block_the_next_run(project):
    project.write("customers", [["C000001"]], header=["customer_id"])
    assert project.run(["customers"])["customers"].status == "FAILED"
    project.write("customers", basic_customers(1))
    assert project.run(["customers"])["customers"].status == "SUCCESS"
    assert project.query("select status from pipeline_runs order by started_at") == [("FAILED",), ("SUCCESS",)]
