"""Tests for the mini ETL framework (run with: python -m pytest -q)."""
