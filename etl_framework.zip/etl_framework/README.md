# Mini-ETL-Framework
A Data Engineering project that provides reusable, config-driven components for extraction, validation, transformation, load, logging and metrics, demonstrated on two datasets (customers and orders) with quarantine of invalid rows, idempotent reruns, a reconciliation report, automated tests and a measured performance optimization.
# Mini ETL Framework

A reproducible batch ETL framework. It reads CSV files, validates every row against rules kept in YAML config, quarantines invalid rows with a reason instead of dropping them silently, keeps the full history of every record, loads results into SQLite, and records each run with counts, timings and failure reasons. The same core code runs both datasets: `customers` (parent) and `orders` (child, referencing customers). A new dataset is added with a new config file, not new code. A reconciliation report proves the loaded data agrees with the source files, the run log and a separately stored answer key.

Stack: Python, pandas, SQLite (built into Python), PyYAML, pytest. Runs in Google Colab or locally.

Status: the framework, both datasets, the seeded data generator, 191 automated tests, the reconciliation report with sample queries, and the performance measurement are built. Still to come: a separate design and trade-off note (see "Not built yet").

## Quick start

**Google Colab (documented cloud environment)**

1. Open colab.research.google.com, then File > Upload notebook, and pick `etl_framework_submission.ipynb` (the notebook is generated from the project files by `python build_notebook.py`).
2. Runtime > Run all. Section 1 installs the libraries, section 2 writes every project file, section 3 runs the tests, section 4 loads the sample data and prints the reconciliation report, section 5 reruns the same input, section 6 runs the SQL files, section 7 loads a 100,000-order dataset, section 8 runs the benchmark (a few minutes), and section 9 packages everything into a zip you can download.

**Locally** (Python 3.10 or newer; developed on 3.14)

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux:       source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest -q
python run_pipeline.py
python run_report.py --input-dir data/sample --expected-dir data/expected
```

Expected results on the included sample (columns of the printed summary):

| dataset | rows_in | rows_inserted | rows_rejected | duplicates_dropped | late_records |
|---|---|---|---|---|---|
| customers | 41 | 27 | 12 | 2 | 0 |
| orders | 114 | 95 | 17 | 2 | 11 |

`python -m pytest -q` reports 191 passed. The report command prints `Result: **PASS** (36 of 36 checks passed)`. Running the pipeline a second time inserts nothing: `rows_inserted` is 0, `rows_already_loaded` is 27 (customers) and 95 (orders), and no table changes.

## Architecture

```text
config/pipeline.yaml + config/datasets/*.yaml
                 |
                 v
        CSV file --> extract.py   read text, keep line numbers, set aside malformed rows
                 |
                 v
        validate.py   schema check (missing required column = run fails; extra column = warning)
                 |    row rules: required, type, pattern, allowed values, range, not in future
                 |                         |
          valid rows                 rejected rows
                 |                         |
                 v                         |
        transform.py   cast types, clean values, derived fields, record_hash
                 |                         |
                 v                         |
        validate.py   duplicate keys, then parent reference check
                 |                         |
                 +-------> load.py <-------+
                           one SQLite transaction per dataset
                                  |
             +--------------------+-------------------+
             v                    v                   v
     <name>_history        <name>_current      rejected_records
                                  |
                       metrics.py -> pipeline_runs      logging_setup.py -> JSON log lines
                                  |
                       reconcile.py -> run_report.py -> reports/reconciliation_report.md
```

`pipeline.py` coordinates the steps for each dataset in the order listed in `config/pipeline.yaml`. `config_loader.py` reads and checks the config files. `parsing.py` holds the shared type-parsing helpers. `errors.py` defines the named failure types. `reconcile.py` generates its checks from the same dataset configs. No module contains customer or order logic: every rule, key, table name and derived field comes from the dataset config. `generator/generate_data.py` creates the synthetic input and the answer key; `run_benchmark.py` measures performance.

## Configuration and commands

| Command | Purpose |
|---|---|
| `python run_pipeline.py` | Load every dataset in `config/pipeline.yaml` |
| `python run_report.py` | Reconciliation report for a database (exit 0 = all checks passed) |
| `python -m generator.generate_data` | Generate the small sample and its expected answers |
| `python run_benchmark.py` | Measure performance and the optimization |
| `python -m pytest -q` | Run the automated tests |
| `python build_notebook.py` | Rebuild the Colab notebook from the project files (`--check` reports whether it is out of date) |

`run_pipeline.py` options:

| Option | Default | Purpose |
|---|---|---|
| `--config FILE` | `config/pipeline.yaml` | Pipeline config: database, input folder, log file, dataset order |
| `--input-dir DIR` | `data/sample` | Folder with the source CSV files |
| `--db FILE` | `output/warehouse.db` | SQLite target database |
| `--log-file FILE` | `logs/pipeline.log` | JSON-lines log file (appended) |
| `--dataset NAME` | all | Run only this dataset (repeatable) |

Exit code 0 means every dataset succeeded, 1 means a dataset failed, 2 means a configuration or argument error. Each invocation gets one `run_id` (a UUID) shared by its datasets and stamped on every log line, metrics row, loaded row and reject row.

`run_report.py` takes `--db`, `--input-dir` (re-counts the source files), `--expected-dir` (compares with the answer key) and `--report-file`; it exits 0 when every check passes, 1 when one fails, 2 when no report can be made. `run_benchmark.py` takes `--customers`, `--orders`, `--seed`, `--repeats`, `--no-scaling`, `--no-profile` and `--report-file`.

**Adding a dataset with config only.** Create `config/datasets/<name>.yaml`, add its path to `datasets` in `config/pipeline.yaml`, and place the CSV in the input folder. A dataset config defines `name`, `source_file`, `natural_key`, `version_column`, the target tables, `columns` (type, required, pattern, allowed_values, min, max, not_in_future, transform), `references` and `derived` fields. Column types are `string`, `integer`, `decimal`, `date`, `timestamp`. Derived operations are `split_part`, `multiply_to_cents` and `date_part`; a new kind of calculation would need a small code addition. Unknown options in a config file fail the run before any data is read, so a typo cannot silently disable a rule. A test adds a third dataset (`products`) this way, with no change to `etl/`.

## Data dictionary

### Input files

| File | Columns | Meaning |
|---|---|---|
| `data/sample/customers.csv` | `customer_id`, `full_name`, `email`, `country_code`, `signup_date`, `updated_at` | One row per customer version. `customer_id` is `C` plus 6 digits; `country_code` is one of IN, US, GB, AE, SG; `email` needs one `@` and a dot after it and is stored in lowercase; `signup_date` is `YYYY-MM-DD`; `signup_date` and `updated_at` may not be in the future. |
| `data/sample/orders.csv` | `order_id`, `customer_id`, `order_ts`, `status`, `quantity`, `unit_price`, `currency`, `updated_at` | One row per order version. `order_id` is `O` plus 8 digits; `customer_id` must exist in `customers_current`; `status` is placed, shipped, delivered or cancelled; `quantity` is 1 to 1000; `unit_price` is 0 to 100000 (0 is allowed); `currency` is INR or USD. |

Extraction reads every value as text, trims whitespace, and treats empty text as missing. Rows with the wrong number of fields are rejected as `MALFORMED_ROW`. Fully blank lines are ignored but counted in the log. A file with only a header is a valid empty batch; a completely empty file fails the run. Columns are matched by name, so their order does not matter.

### Output tables (SQLite)

| Table | Key and contents |
|---|---|
| `customers_history`, `orders_history` | Append-only, one row per version, primary key (natural key, `updated_at`). Stores business columns, derived columns, `record_hash`, `run_id`, `source_file`, `source_row_number`, `loaded_at`. |
| `customers_current`, `orders_current` | One row per natural key, the latest version only. Same columns as history. Replaced only when the incoming `updated_at` is newer. |
| `rejected_records` | One row per distinct bad record: `reject_id`, `dataset`, `source_file`, `row_number` (header is line 1), `reject_reasons`, `raw_record` (the original row as JSON), `first_seen_run_id`, `first_seen_at`, `last_seen_run_id`, `last_seen_at`, `resolved_run_id`, `resolved_at`. |
| `pipeline_runs` | One row per dataset per run: `run_id`, `dataset`, `source_file`, `status` (RUNNING, SUCCESS, FAILED, SKIPPED), `started_at`, `ended_at`, `duration_seconds`, `rows_in`, `rows_inserted`, `rows_already_loaded`, `rows_rejected`, `duplicates_dropped`, `late_records`, four per-stage timings, `failure_reason`, `warnings`. |

Derived fields: `email_domain` (text after the `@`), `order_amount_cents` (quantity times unit price times 100, exact decimal arithmetic rounded half up to a whole number of cents, so source and target totals reconcile exactly), `order_date` (UTC date of `order_ts`), and `record_hash` (SHA-256 of the cleaned business columns).

Naming: snake_case tables and columns; timestamps are ISO-8601 UTC with second precision (`2024-02-01T10:00:00Z`; an offset such as `+05:30` is converted to UTC and a timestamp without an offset is read as UTC); `run_id` and `source_file` appear on loaded and rejected rows; IDs that identify data come from the source and are never random.

## Validation rules and reject codes

Each rejected input row produces one reject record that lists every failed rule, for example `INVALID_ALLOWED_VALUE:status; OUT_OF_RANGE:unit_price`.

| Code | When |
|---|---|
| `MALFORMED_ROW` | Wrong number of fields on the line |
| `MISSING_REQUIRED_FIELD` | A required value is empty |
| `INVALID_TYPE` | Not a valid integer, decimal, date or timestamp (for example `2024-02-30`) |
| `INVALID_FORMAT` | Fails the column pattern (id format, email) |
| `INVALID_ALLOWED_VALUE` | Not in the allowed list; matching is case-sensitive |
| `OUT_OF_RANGE` | Below the minimum or above the maximum |
| `FUTURE_TIMESTAMP` | Date or timestamp later than the run time |
| `CONFLICTING_DUPLICATE` | Same key and version but different content, inside the file or against an already loaded record |
| `INVALID_REFERENCE` | `customer_id` has no matching row in `customers_current` |

A missing required column, a duplicated column name or a file with no header is not a row reject: it fails the dataset with a `failure_reason` such as `SCHEMA_MISSING_COLUMNS: ['email']`, and datasets after it in the same run are marked `SKIPPED`. Extra columns are ignored and recorded as a warning.

Duplicate handling inside one file: the first copy of an exact duplicate is kept and the rest are counted in `duplicates_dropped`. Copies with the same key and version but different content cannot be trusted, so all copies are rejected as `CONFLICTING_DUPLICATE`.

## Idempotency, retry, restart and late data

Loading one dataset is a single transaction: history, current and rejects are written together or not at all. A `RUNNING` row is committed to `pipeline_runs` before any work starts, so a crashed run leaves evidence; failures are recorded as `FAILED` with their reason. Before committing, the load checks `rows_in = rows_inserted + rows_already_loaded + rows_rejected + duplicates_dropped` and rolls everything back if it does not hold.

Rerunning the same file is safe. A version already stored with the same `record_hash` is counted as `rows_already_loaded` and nothing is written. Bad records already seen keep their first reject record and only `last_seen_run_id` and `last_seen_at` change; every run still counts them in its own `rows_rejected`. Retry and restart are the same command again: a failed transaction was rolled back, and anything already committed is skipped through the primary keys.

Late and out-of-order versions: an older version arriving after a newer one is stored in history, counted in `late_records`, and does not replace the current row, so for example an order stays `delivered` when an old `placed` version arrives later. A backfill is a run on an older file; old versions go to history and the current table is protected the same way.

Orders whose customer does not exist yet are rejected as `INVALID_REFERENCE`. Rerunning the same orders file after the customer has loaded inserts the order and marks the earlier reject as resolved (`resolved_run_id`, matched by file name and row number).

## Reproducible sample and larger run

The generator uses a fixed seed (default 42): the same seed and options always give identical files. It writes the **input** files (`customers.csv`, `orders.csv`) to one folder and the **answer key** to another, so labels never sit next to the data they describe:

| File in `data/expected/` | Meaning |
|---|---|
| `expected_rejects.csv` | Every planted bad row: file, line number, exact expected reject reason, and a readable defect name |
| `expected_summary.json` | Expected counts per dataset (rows in, inserted, rejected, duplicates, late, history and current rows) and order totals in cents |
| `expected_current_customers.csv`, `expected_current_orders.csv` | The latest version of every valid record |

It plants valid records with several versions, boundary orders (quantity 1 and 1000, price 0.00 and 100000.00), timestamps in `Z`, `+00:00` and `+05:30` forms, padded names and upper-case e-mails, older versions placed after newer ones in the file, exact duplicates, and 11 customer and 16 order defect types (missing values, wrong types, out-of-range values, conflicting duplicates, unknown customers, malformed lines and a row with two defects). Every defect type appears at any size. Generate a larger dataset (about 24,600 customer rows and 240,000 order rows) with:

```bash
python -m generator.generate_data --customers 20000 --orders 100000 --out-dir data/large --expected-dir data/large/expected
python run_pipeline.py --input-dir data/large --db output/large.db
python run_report.py --db output/large.db --input-dir data/large --expected-dir data/large/expected
```

## Correctness evidence and tests

`python -m pytest -q` runs 191 tests, each using its own temporary folder and database. They cover every required edge case: happy path, empty and header-only input, malformed rows, every required column blank, 28 invalid-value cases with exact reasons, boundary values and future-date edges, exact and conflicting duplicates, schema changes (missing, extra, repeated columns), late and out-of-order data (including an old status not overwriting a newer one), invalid references and their replay, reruns, failure mid-load with rollback and retry, a crash leaving a `RUNNING` row, log and metrics content, configuration mistakes, a new dataset added with config only, the command-line exit codes, deterministic generation, the reconciliation report (including corrupting the database on purpose to prove each check fails), and the performance tooling. Separate tests compare the pipeline's output with the generator's answer key for three seeds, the committed sample, and a 10,000-order run.

`python run_report.py --input-dir data/sample --expected-dir data/expected` prints a reconciliation report with 36 checks, each counting violations (0 = PASS):

- `rows_in = inserted + already loaded + rejected + duplicates dropped` for every successful run;
- the source file re-counted independently of the pipeline equals `rows_in`;
- primary keys are unique, every current row equals the newest history row, every history key has a current row, history rows equal the sum of `rows_inserted`;
- every order's customer exists, and the order total in cents agrees between current and the newest history versions;
- every reject has a reason, source file, line number and original row, and uses a documented reason code;
- the run counts, table row counts, rejected rows and reasons, current rows and order totals equal the answer key.

`sql/reconciliation.sql` holds 14 of the same checks as plain SQL and `sql/sample_queries.sql` holds 14 analysis queries (current status counts, revenue by country, order timelines from history, reject summaries, lineage, run history and throughput). `reports/reconciliation_report.md` and `reports/reconciliation_report_large.md` are saved results: both pass all 36 checks.

## Performance and trade-offs

`python run_benchmark.py` generates the data, runs the pipeline repeatedly on an empty database, and writes `reports/performance_report.md`. Measured on Windows, Python 3.14, pandas 3.1.1, 12 CPUs, with 24,600 customer rows and 240,373 order rows:

- The whole run takes about 10.9 s, roughly 24,000 rows per second. Within the orders dataset, load is the largest stage (44%), then transform (26%) and validate (25%); extract is 5%. Throughput stays between about 21,000 and 24,000 rows per second from 5,000 to 100,000 orders, so cost grows in proportion to the data.
- A profile of the first version showed about 2.5 million slow per-value accesses into pandas string columns, coming from row loops that iterate a column directly. The optimization converts each column to a plain list once (`_plain` in `etl/transform.py`). It made the transform stage 13% faster (faster in 5 of 5 paired repeats) and the whole run about 5% faster (4 of 5 repeats), and cut the slow accesses from 2,553,363 to 523,247. A content fingerprint of every table is identical before and after, so the stored data did not change.
- The gain is moderate. SQLite inserts and pandas' own string handling dominate what remains. Installing `pyarrow` would likely help more, but it is an extra dependency and was not measured.
- Other ideas measured separately during development changed the total by only 2 to 4%, within run-to-run noise, and were not adopted. Memory use was not measured.

Design trade-offs: SQLite and pandas keep the setup to one `pip install` and fit a single-machine batch job, at the cost of single-writer loading and string handling that is slower than a columnar engine. History is kept as an append-only table plus a current table instead of SCD Type 2: late data becomes one more history row and cannot corrupt date ranges, and `valid_to` can be derived with a window function when needed (sample query 4).

## Known limitations

- Timestamps are kept to second precision; sub-second differences are dropped.
- `unit_price` is stored as a floating-point `REAL`; the exact money value is `order_amount_cents`.
- Marking a reject as resolved matches by file name and row number, so a file edited in a way that shifts rows can resolve a reject for a different record.
- Rejects are checked in stages: a row rejected by an earlier stage is not checked by later stages (a row with a rule failure is not also reference-checked).
- A parent dataset must come before its children in `config/pipeline.yaml`.
- Batch processing with a single writer; concurrent writers are not handled.
- Changing a dataset config after its tables exist does not migrate the existing tables.
- The reconciliation report compares the latest successful run of each dataset and assumes nothing else writes to the database.
- The answer key and the pipeline share the same reject-reason names, so a naming mistake made in both would not be caught by the comparison.
- Developed and tested on Windows with Python 3.14 and pandas 3.1.1. The Colab notebook has been executed cell by cell on that machine; other platforms and versions are untested until it is run on Colab.

## Not built yet

A separate design and trade-off note (the trade-offs above are a summary).

## Project contents

```text
config/            pipeline.yaml and one YAML file per dataset (customers, orders)
etl/               extract, validate, transform, load, metrics, logging_setup, pipeline,
                   config_loader, parsing, errors, reconcile
generator/         seeded synthetic data generator with a separate answer key
sql/               reconciliation.sql and sample_queries.sql
tests/             191 automated tests
data/sample/       generated customers.csv and orders.csv (seed 42)
data/expected/     the answer key for the sample
reports/           saved reconciliation and performance reports
run_pipeline.py    command-line entry point
run_report.py      reconciliation report
run_benchmark.py   performance measurement
build_notebook.py  rebuilds the Colab notebook from the project files
etl_framework_submission.ipynb   self-contained Colab notebook: writes every file above and runs everything
requirements.txt   pinned dependencies
logs/ output/      created at run time (JSON log file, SQLite database)
```
