"""Command-line entry point.

Examples:
    python run_pipeline.py                         # run every dataset in config/pipeline.yaml
    python run_pipeline.py --dataset customers     # run only customers
    python run_pipeline.py --input-dir data/large --db output/large.db
Exit code: 0 = all datasets succeeded, 1 = a dataset failed, 2 = bad config/arguments.
"""
from __future__ import annotations

import argparse
import sys

from etl.errors import ConfigError
from etl.pipeline import run_pipeline

COLUMNS = ["dataset", "status", "rows_in", "rows_inserted", "rows_already_loaded", "rows_rejected",
           "duplicates_dropped", "late_records", "duration_seconds"]


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the mini ETL pipeline.")
    parser.add_argument("--config", default="config/pipeline.yaml", help="pipeline config file")
    parser.add_argument("--input-dir", help="folder with the source CSV files (overrides config)")
    parser.add_argument("--db", help="SQLite database file (overrides config)")
    parser.add_argument("--log-file", help="log file (overrides config)")
    parser.add_argument("--dataset", action="append", help="run only this dataset (repeatable)")
    args = parser.parse_args()
    try:
        results = run_pipeline(args.config, input_dir=args.input_dir, db_path=args.db,
                               log_file=args.log_file, dataset_names=args.dataset)
    except ConfigError as exc:
        print(f"CONFIG ERROR: {exc}", file=sys.stderr)
        return 2

    print(f"\nrun_id: {results[0].run_id}")
    print("  ".join(f"{c:>19}" if c != "dataset" else f"{c:<12}" for c in COLUMNS))
    for r in results:
        row = vars(r)
        print("  ".join(f"{row[c]!s:>19}" if c != "dataset" else f"{row[c]!s:<12}" for c in COLUMNS))
        if r.failure_reason:
            print(f"  -> {r.failure_reason}")
        for warning in r.warnings:
            print(f"  -> warning: {warning}")
    return 1 if any(r.status == "FAILED" for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
