"""Load: write history, current and reject tables to SQLite in ONE transaction.

Idempotency rules (running the same input twice leaves the database unchanged):
  * history table : append-only, primary key (natural key + version). A version that is
                    already stored with the same record_hash is counted as 'already loaded'.
                    A stored version with a DIFFERENT record_hash is rejected (conflict),
                    never silently ignored.
  * current table : one row per natural key; replaced only when the incoming version is NEWER.
  * rejected_records : one row per distinct bad record; seen again later -> only last_seen_* updates.
Everything for one dataset commits together or not at all.
"""
from __future__ import annotations

import hashlib
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd

from etl.errors import ReconciliationError
from etl.transform import DERIVED_SQL_TYPES
from etl.validate import build_reject_rows, empty_rejects

COLUMN_SQL_TYPES = {"string": "TEXT", "integer": "INTEGER", "decimal": "REAL", "date": "TEXT", "timestamp": "TEXT"}
META_COLUMNS = ["run_id", "source_file", "source_row_number", "loaded_at"]

REJECTED_RECORDS_DDL = """
CREATE TABLE IF NOT EXISTS rejected_records (
    reject_id          TEXT PRIMARY KEY,   -- hash of dataset|source_file|row_number|raw_record (stable across runs)
    dataset            TEXT NOT NULL,
    source_file        TEXT NOT NULL,
    row_number         INTEGER NOT NULL,   -- line number in the source file (header = line 1)
    reject_reasons     TEXT NOT NULL,
    raw_record         TEXT NOT NULL,      -- the original row as JSON, so it can be fixed and replayed
    first_seen_run_id  TEXT NOT NULL,
    first_seen_at      TEXT NOT NULL,
    last_seen_run_id   TEXT NOT NULL,
    last_seen_at       TEXT NOT NULL,
    resolved_run_id    TEXT,               -- run in which this row position later loaded successfully
    resolved_at        TEXT
)
"""


@dataclass
class LoadResult:
    """Counts produced by the load step."""

    rows_inserted: int
    rows_already_loaded: int
    rows_rejected: int       # all rejects for the dataset, including conflicts found at load time
    late_records: int


def connect(db_path: Path) -> sqlite3.Connection:
    """Open SQLite in autocommit mode; we control transactions explicitly with BEGIN/COMMIT."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(db_path, isolation_level=None)


def ensure_reject_table(conn: sqlite3.Connection) -> None:
    conn.execute(REJECTED_RECORDS_DDL)


def dataset_columns(config: dict[str, Any]) -> list[str]:
    """Business + derived columns + record_hash, in table order (metadata columns come after)."""
    return [*config["columns"], *(config.get("derived") or {}), "record_hash"]


def _table_ddl(table: str, config: dict[str, Any], primary_key: list[str]) -> str:
    lines = []
    for col, spec in config["columns"].items():
        not_null = " NOT NULL" if spec.get("required", False) else ""
        lines.append(f"    {col} {COLUMN_SQL_TYPES[spec['type']]}{not_null}")
    for col, spec in (config.get("derived") or {}).items():
        lines.append(f"    {col} {DERIVED_SQL_TYPES[spec['operation']]}")
    lines.append("    record_hash TEXT NOT NULL")
    lines += ["    run_id TEXT NOT NULL", "    source_file TEXT NOT NULL",
              "    source_row_number INTEGER NOT NULL", "    loaded_at TEXT NOT NULL"]
    lines.append(f"    PRIMARY KEY ({', '.join(primary_key)})")
    return f"CREATE TABLE IF NOT EXISTS {table} (\n" + ",\n".join(lines) + "\n)"


def ensure_dataset_tables(conn: sqlite3.Connection, config: dict[str, Any]) -> None:
    """Create the history and current tables for a dataset (from config) if needed."""
    key = config["natural_key"]
    conn.execute(_table_ddl(config["target"]["history_table"], config, [*key, config["version_column"]]))
    conn.execute(_table_ddl(config["target"]["current_table"], config, key))


def fetch_parent_keys(conn: sqlite3.Connection, table: str, column: str) -> set:
    """All values of a parent key column. A parent table that does not exist yet means no keys."""
    exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (table,)).fetchone()
    if not exists:
        return set()
    return {row[0] for row in conn.execute(f"SELECT DISTINCT {column} FROM {table}")}


def _py_rows(df: pd.DataFrame, columns: list[str]) -> list[tuple]:
    """DataFrame rows as plain Python tuples (missing values -> None) that sqlite3 can bind."""
    sub = df[columns].astype(object)
    sub = sub.where(sub.notna(), None)
    return [tuple(row) for row in sub.itertuples(index=False, name=None)]


def _read_existing(conn: sqlite3.Connection, config: dict[str, Any], df: pd.DataFrame
                   ) -> tuple[dict[int, str], dict[tuple, str]]:
    """Look up incoming rows in the target: {row_number: stored record_hash}, {key: current version}."""
    if df.empty:
        return {}, {}
    keys, version = config["natural_key"], config["version_column"]
    hist, cur = config["target"]["history_table"], config["target"]["current_table"]
    incoming = df[[*keys, version, "record_hash"]].copy()
    incoming["row_number"] = df.index
    columns = [*keys, version, "record_hash", "row_number"]
    conn.execute(f"CREATE TEMP TABLE _incoming ({', '.join(columns)})")
    try:
        marks = ", ".join("?" * len(columns))
        conn.executemany(f"INSERT INTO _incoming VALUES ({marks})", _py_rows(incoming, columns))
        join_hist = " AND ".join(f"h.{c} = i.{c}" for c in [*keys, version])
        hashes = {row[0]: row[1] for row in conn.execute(
            f"SELECT i.row_number, h.record_hash FROM _incoming i JOIN {hist} h ON {join_hist}")}
        join_cur = " AND ".join(f"c.{c} = i.{c}" for c in keys)
        key_list = ", ".join(f"i.{c}" for c in keys)
        versions = {tuple(row[:-1]): row[-1] for row in conn.execute(
            f"SELECT DISTINCT {key_list}, c.{version} FROM _incoming i JOIN {cur} c ON {join_cur}")}
    finally:
        conn.execute("DROP TABLE IF EXISTS _incoming")
    return hashes, versions


def _flag_late(keys: list[tuple], versions: list[str], known: dict[tuple, str]) -> list[bool]:
    """A row is late if a NEWER version of the same key is already known (in the target or earlier in the file)."""
    newest = dict(known)
    flags = []
    for key, version in zip(keys, versions):
        top = newest.get(key)
        flags.append(top is not None and version < top)
        if top is None or version > top:
            newest[key] = version
    return flags


def _reject_id(dataset: str, source_file: str, row_number: int, raw_record: str) -> str:
    return hashlib.sha256(f"{dataset}|{source_file}|{row_number}|{raw_record}".encode("utf-8")).hexdigest()


def load_dataset(conn: sqlite3.Connection, config: dict[str, Any], df: pd.DataFrame, rejects: pd.DataFrame,
                 raw: pd.DataFrame, *, run_id: str, source_file: str, rows_in: int,
                 duplicates_dropped: int, now_iso: str) -> LoadResult:
    """Write one dataset atomically. Raises (after rolling back) on any error, including count mismatch."""
    ensure_dataset_tables(conn, config)
    conn.execute("BEGIN")
    try:
        result = _load_in_transaction(conn, config, df, rejects, raw, run_id=run_id, source_file=source_file,
                                      rows_in=rows_in, duplicates_dropped=duplicates_dropped, now_iso=now_iso)
        conn.execute("COMMIT")
    except BaseException:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    return result


def _load_in_transaction(conn: sqlite3.Connection, config: dict[str, Any], df: pd.DataFrame,
                         rejects: pd.DataFrame, raw: pd.DataFrame, *, run_id: str, source_file: str,
                         rows_in: int, duplicates_dropped: int, now_iso: str) -> LoadResult:
    keys, version = config["natural_key"], config["version_column"]
    hist, cur = config["target"]["history_table"], config["target"]["current_table"]
    dataset = config["name"]
    df = df.sort_index()

    # 1. Compare incoming rows with what is already stored.
    stored_hash, current_version = _read_existing(conn, config, df)
    stored = pd.Series(df.index.map(stored_hash.get), index=df.index, dtype="object")
    is_new = stored.isna()
    is_same = stored.notna() & (stored == df["record_hash"])
    is_conflict = stored.notna() & ~is_same
    new_rows, already_rows = df[is_new], df[is_same]

    # 2. Conflicts with an already-stored version are rejected, not ignored.
    conflict_reasons = pd.Series(
        f"CONFLICTING_DUPLICATE:{','.join([*keys, version])} (differs from already loaded record)",
        index=pd.Index(df.index[is_conflict], name="row_number"), dtype="object")
    all_rejects = pd.concat([rejects, build_reject_rows(raw, conflict_reasons)]).sort_index() \
        if not conflict_reasons.empty else rejects

    # 3. Late records: new versions that are older than a version we already know.
    key_tuples = list(zip(*[new_rows[c] for c in keys])) if len(new_rows) else []
    late_flags = _flag_late(key_tuples, list(new_rows[version]), current_version)

    # 4. Write history (append) and current (only if newer).
    columns = dataset_columns(config)
    stamped = new_rows.copy()
    stamped["run_id"], stamped["source_file"] = run_id, source_file
    stamped["source_row_number"], stamped["loaded_at"] = stamped.index, now_iso
    write_columns = [*columns, *META_COLUMNS]
    marks = ", ".join("?" * len(write_columns))
    conn.executemany(f"INSERT INTO {hist} ({', '.join(write_columns)}) VALUES ({marks})",
                     _py_rows(stamped, write_columns))
    latest = stamped.sort_values(version, kind="stable").drop_duplicates(keys, keep="last")
    updates = ", ".join(f"{c} = excluded.{c}" for c in write_columns if c not in keys)
    conn.executemany(
        f"INSERT INTO {cur} ({', '.join(write_columns)}) VALUES ({marks}) "
        f"ON CONFLICT({', '.join(keys)}) DO UPDATE SET {updates} WHERE excluded.{version} > {cur}.{version}",
        _py_rows(latest, write_columns))

    # 5. Rejects: insert once, or just refresh last_seen_* if we saw the same bad record before.
    reject_rows = [
        (_reject_id(dataset, source_file, int(n), rec), dataset, source_file, int(n), reasons, rec,
         run_id, now_iso, run_id, now_iso)
        for n, reasons, rec in zip(all_rejects.index, all_rejects["reject_reasons"], all_rejects["raw_record"])]
    conn.executemany(
        "INSERT INTO rejected_records (reject_id, dataset, source_file, row_number, reject_reasons, raw_record, "
        "first_seen_run_id, first_seen_at, last_seen_run_id, last_seen_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
        "ON CONFLICT(reject_id) DO UPDATE SET reject_reasons = excluded.reject_reasons, "
        "last_seen_run_id = excluded.last_seen_run_id, last_seen_at = excluded.last_seen_at, "
        "resolved_run_id = NULL, resolved_at = NULL", reject_rows)

    # 6. An earlier reject at a row position that now loads (or is already loaded) is marked resolved.
    ok_rows = [(int(n),) for n in [*new_rows.index, *already_rows.index]]
    if ok_rows:
        conn.execute("CREATE TEMP TABLE _ok_rows (row_number INTEGER)")
        try:
            conn.executemany("INSERT INTO _ok_rows VALUES (?)", ok_rows)
            conn.execute(
                "UPDATE rejected_records SET resolved_run_id = ?, resolved_at = ? "
                "WHERE dataset = ? AND source_file = ? AND resolved_run_id IS NULL "
                "AND row_number IN (SELECT row_number FROM _ok_rows)", (run_id, now_iso, dataset, source_file))
        finally:
            conn.execute("DROP TABLE IF EXISTS _ok_rows")

    # 7. Safety net: every input row must be accounted for, or the whole load is rolled back.
    result = LoadResult(rows_inserted=len(new_rows), rows_already_loaded=len(already_rows),
                        rows_rejected=len(all_rejects), late_records=sum(late_flags))
    accounted = result.rows_inserted + result.rows_already_loaded + result.rows_rejected + duplicates_dropped
    if accounted != rows_in:
        raise ReconciliationError(
            f"rows_in={rows_in} but inserted+already_loaded+rejected+duplicates_dropped={accounted}")
    return result
