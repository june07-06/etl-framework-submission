"""Validate: schema check, row-level rules, duplicate keys and reference keys.

Every function here is driven by the dataset config; none knows what a
"customer" or an "order" is. Failing rows are never dropped silently: each one
gets a reject reason string such as 'MISSING_REQUIRED_FIELD:email; OUT_OF_RANGE:quantity'.
"""
from __future__ import annotations

import json
from datetime import datetime
from decimal import Decimal
from typing import Any

import numpy as np
import pandas as pd

from etl.errors import SchemaError
from etl.parsing import (
    DECIMAL_RE,
    INTEGER_RE,
    matches,
    parse_date,
    parse_timestamp,
)


# ---------- schema ----------

def check_schema(header: list[str], columns_cfg: dict[str, Any]) -> list[str]:
    """Fail on duplicate or missing required columns; return the extra columns (to warn about)."""
    duplicates = sorted({name for name in header if header.count(name) > 1})
    if duplicates:
        raise SchemaError(f"SCHEMA_DUPLICATE_COLUMNS: {duplicates}")
    missing = [c for c, spec in columns_cfg.items() if spec.get("required", False) and c not in header]
    if missing:
        raise SchemaError(f"SCHEMA_MISSING_COLUMNS: {missing}")
    return [name for name in header if name not in columns_cfg]


def normalize(raw: pd.DataFrame, columns_cfg: dict[str, Any]) -> pd.DataFrame:
    """Keep only configured columns, trim whitespace, and turn empty text into a real missing value."""
    out = pd.DataFrame(index=raw.index)
    for col in columns_cfg:
        if col in raw.columns:
            text = raw[col].astype("string").str.strip()
            out[col] = text.mask((text == "").fillna(False), pd.NA)
        else:  # optional column absent from the file
            out[col] = pd.Series(pd.NA, index=raw.index, dtype="string")
    return out


# ---------- reject helpers ----------

def empty_rejects() -> pd.DataFrame:
    """An empty reject frame with the standard shape (index = source row number)."""
    return pd.DataFrame(
        {"reject_reasons": pd.Series(dtype="object"), "raw_record": pd.Series(dtype="object")},
        index=pd.Index([], name="row_number", dtype="int64"),
    )


def build_reject_rows(raw: pd.DataFrame, reasons: pd.Series) -> pd.DataFrame:
    """Turn {row_number: reason text} into reject rows that also keep the original record as JSON."""
    if reasons.empty:
        return empty_rejects()
    originals = raw.loc[reasons.index].astype(object).to_dict("records")
    return pd.DataFrame(
        {
            "reject_reasons": reasons.to_numpy(),
            "raw_record": [json.dumps(rec, ensure_ascii=False) for rec in originals],
        },
        index=pd.Index(reasons.index, name="row_number"),
    )


def reasons_from_flags(flags: dict[str, pd.Series], index: pd.Index) -> pd.Series:
    """Combine named True/False checks into one reason string per failing row."""
    empty = pd.Series(dtype="object", index=pd.Index([], name="row_number", dtype="int64"))
    if not flags or len(index) == 0:
        return empty
    flag_df = pd.DataFrame(flags, index=index).astype(bool)
    failing = flag_df.any(axis=1)
    if not failing.any():
        return empty
    names = np.array(flag_df.columns)
    texts = ["; ".join(names[row]) for row in flag_df[failing].to_numpy()]
    return pd.Series(texts, index=pd.Index(flag_df.index[failing], name="row_number"), dtype="object")


# ---------- row rules ----------

def _column_flags(col: str, spec: dict[str, Any], s: pd.Series, now: datetime) -> dict[str, pd.Series]:
    """Return {'REASON_CODE:column': True-where-the-rule-fails} for one column."""
    flags: dict[str, pd.Series] = {}
    present = s.notna()
    kind = spec["type"]

    if spec.get("required", False):
        flags[f"MISSING_REQUIRED_FIELD:{col}"] = ~present

    parsed = None
    if kind == "integer":
        type_ok = matches(s, INTEGER_RE)
    elif kind == "decimal":
        type_ok = matches(s, DECIMAL_RE)
    elif kind == "date":
        parsed = parse_date(s)
        type_ok = parsed.notna()
    elif kind == "timestamp":
        parsed = parse_timestamp(s)
        type_ok = parsed.notna()
    else:
        type_ok = present
    if kind != "string":
        flags[f"INVALID_TYPE:{col}"] = present & ~type_ok
    typed_ok = present & type_ok

    if "pattern" in spec:
        flags[f"INVALID_FORMAT:{col}"] = present & ~matches(s, spec["pattern"])
    if "allowed_values" in spec:
        flags[f"INVALID_ALLOWED_VALUE:{col}"] = present & ~s.isin([str(v) for v in spec["allowed_values"]])

    if "min" in spec or "max" in spec:
        out_of_range = pd.Series(False, index=s.index)
        values = s[typed_ok].map(Decimal)  # Decimal compares exactly (no float rounding surprises)
        if len(values):
            bad = pd.Series(False, index=values.index)
            if "min" in spec:
                bad |= values < Decimal(str(spec["min"]))
            if "max" in spec:
                bad |= values > Decimal(str(spec["max"]))
            out_of_range.loc[bad.index[bad]] = True
        flags[f"OUT_OF_RANGE:{col}"] = out_of_range

    if spec.get("not_in_future"):
        limit = pd.Timestamp(now) if kind == "timestamp" else pd.Timestamp(now.date())
        flags[f"FUTURE_TIMESTAMP:{col}"] = (parsed > limit).fillna(False).astype(bool)

    return flags


def validate_rows(norm: pd.DataFrame, columns_cfg: dict[str, Any], now: datetime,
                  mode: str = "vectorized") -> pd.Series:
    """Check every row against the column rules. Returns reason text for the rows that fail."""
    if mode != "vectorized":
        raise NotImplementedError("validation_mode 'rowwise' is added in Phase 3 step 7 (performance comparison)")
    flags: dict[str, pd.Series] = {}
    for col, spec in columns_cfg.items():
        flags.update(_column_flags(col, spec, norm[col], now))
    return reasons_from_flags(flags, norm.index)


# ---------- duplicates and references (run on transformed rows) ----------

def check_duplicates(df: pd.DataFrame, config: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series, int]:
    """Handle repeated (natural key + version) rows inside one file.

    Same key+version and identical content: keep the first copy, count the rest as duplicates.
    Same key+version but different content: we cannot know which is right, so reject every copy.
    Returns (rows to keep, reject reasons for conflicting rows, number of exact duplicates dropped).
    """
    keys = [*config["natural_key"], config["version_column"]]
    if df.empty:
        return df, pd.Series(dtype="object"), 0
    group = df.groupby(keys, sort=False)["record_hash"]
    conflict = (group.transform("size") > 1) & (group.transform("nunique") > 1)
    exact_duplicate = ~conflict & df.duplicated(keys, keep="first")
    reasons = pd.Series(
        f"CONFLICTING_DUPLICATE:{','.join(keys)}",
        index=pd.Index(df.index[conflict], name="row_number"),
        dtype="object",
    )
    return df[~conflict & ~exact_duplicate], reasons, int(exact_duplicate.sum())


def check_references(df: pd.DataFrame, references: list[dict[str, str]],
                     parent_keys: dict[tuple[str, str], set]) -> pd.Series:
    """Reject rows whose reference column has no matching parent key (INVALID_REFERENCE)."""
    flags = {}
    for ref in references:
        known = parent_keys[(ref["parent_table"], ref["parent_column"])]
        flags[f"INVALID_REFERENCE:{ref['column']}"] = ~df[ref["column"]].isin(known)
    return reasons_from_flags(flags, df.index)
