"""Logging: one JSON object per line, every line tagged with run_id.

Why JSON lines: they are easy to search by machine, e.g. "all ERROR lines for run X".
Logs go to stderr (console) and to a log file (appended).
"""
from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

LOGGER_NAME = "etl"
_STANDARD_ATTRIBUTES = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {"message", "asctime"}
_LEADING_FIELDS = ("run_id", "dataset", "step")


class JsonFormatter(logging.Formatter):
    """Format a log record as a single JSON line."""

    def format(self, record: logging.LogRecord) -> str:
        extras = {k: v for k, v in record.__dict__.items() if k not in _STANDARD_ATTRIBUTES}
        moment = datetime.fromtimestamp(record.created, tz=timezone.utc)
        payload: dict[str, Any] = {"ts": moment.strftime("%Y-%m-%dT%H:%M:%SZ"), "level": record.levelname}
        for name in _LEADING_FIELDS:
            if name in extras:
                payload[name] = extras.pop(name)
        payload["message"] = record.getMessage()
        payload.update(extras)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


class RunLogger(logging.LoggerAdapter):
    """Adds run_id to every log call and merges any per-call fields (dataset, step, counts...)."""

    def process(self, msg: Any, kwargs: Any) -> tuple[Any, Any]:
        kwargs["extra"] = {**self.extra, **kwargs.get("extra", {})}
        return msg, kwargs


def setup_logging(log_file: Path | None, level: int = logging.INFO) -> None:
    """(Re)configure the framework logger. Safe to call many times (e.g. once per test)."""
    shutdown_logging()
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(level)
    logger.propagate = False
    formatter = JsonFormatter()
    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(formatter)
    logger.addHandler(console)
    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)


def shutdown_logging() -> None:
    """Close and remove handlers (releases the log file, which matters on Windows)."""
    logger = logging.getLogger(LOGGER_NAME)
    for handler in list(logger.handlers):
        handler.close()
        logger.removeHandler(handler)


def get_run_logger(run_id: str) -> RunLogger:
    """Logger that stamps run_id on every line."""
    return RunLogger(logging.getLogger(LOGGER_NAME), {"run_id": run_id})
