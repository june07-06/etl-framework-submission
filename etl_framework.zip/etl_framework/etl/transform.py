"""Transform: cast types, clean values, compute derived fields and record_hash.

Transformations are deterministic: the same input always gives the same output.
`record_hash` is a SHA-256 fingerprint of the cleaned business columns; it lets us
tell "exactly the same record again" from "same key but different content".
"""
from __future__ import annotations

import hashlib
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

import pandas as pd

from etl.parsing import decimal_to_text, parse_date, parse_timestamp, ISO_TIMESTAMP_FORMAT

# SQLite type of every derived-field operation (also tells config_loader which operations exist).
DERIVED_SQL_TYPES = {"split_part": "TEXT", "multiply_to_cents": "INTEGER", "date_part": "TEXT"}

_FIELD_SEPARATOR = "\x1f"  # a control character that never appears in normal text


def _plain(series: pd.Series) -> list:
    """The values of a column as a plain Python list.

    Looping over a pandas string column directly costs one slow method call per value (about 2.5 million of
    them in a 240,000-row run). Converting the column once, then looping over the list, gives the same values
    faster. run_benchmark.py swaps this function for an identity function to reproduce the "before" timing.
    """
    return series.to_numpy(dtype=object).tolist()


def _canonicalize(s: pd.Series, spec: dict[str, Any]) -> tuple[pd.Series, pd.Series]:
    """Return (value to store, canonical text used for hashing and derived fields)."""
    kind = spec["type"]
    if kind == "string":
        transform = spec.get("transform")
        out = s.str.lower() if transform == "lowercase" else s.str.upper() if transform == "uppercase" else s
        return out, out
    if kind == "integer":
        ints = pd.to_numeric(s).astype("Int64")
        return ints, ints.astype("string")
    if kind == "decimal":
        decimals = _plain(s.map(Decimal, na_action="ignore"))
        stored = pd.Series([float(d) if isinstance(d, Decimal) else None for d in decimals],
                           index=s.index, dtype="Float64")
        text = pd.Series([decimal_to_text(d) if isinstance(d, Decimal) else pd.NA for d in decimals],
                         index=s.index, dtype="string")
        return stored, text
    if kind == "date":
        text = parse_date(s).dt.strftime("%Y-%m-%d").astype("string")
        return text, text
    text = parse_timestamp(s).dt.strftime(ISO_TIMESTAMP_FORMAT).astype("string")  # timestamp, UTC
    return text, text


def _derive(spec: dict[str, Any], canon: pd.DataFrame) -> pd.Series:
    """Compute one derived column from canonical source columns."""
    operation = spec["operation"]
    source = canon[spec["sources"][0]]
    if operation == "split_part":
        return source.str.split(spec["delimiter"]).str[spec["index"]].astype("string")
    if operation == "date_part":
        return source.str[:10].astype("string")
    # multiply_to_cents: exact Decimal math, rounded half-up to a whole number of cents
    parts = [_plain(canon[name].map(Decimal, na_action="ignore")) for name in spec["sources"]]
    cents: list[Any] = []
    for values in zip(*parts):
        if all(isinstance(v, Decimal) for v in values):
            product = Decimal(1)
            for v in values:
                product *= v
            cents.append(int((product * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP)))
        else:
            cents.append(None)
    return pd.Series(cents, index=canon.index, dtype="Int64")


def _hash_rows(canon: pd.DataFrame) -> pd.Series:
    """SHA-256 of each row's canonical business values, in config column order."""
    columns = [_plain(canon[name].fillna("")) for name in canon.columns]
    hashes = [hashlib.sha256(_FIELD_SEPARATOR.join(values).encode("utf-8")).hexdigest()
              for values in zip(*columns)]
    return pd.Series(hashes, index=canon.index, dtype="string")


def transform(valid: pd.DataFrame, config: dict[str, Any]) -> pd.DataFrame:
    """Turn validated text rows into typed target rows (+ derived columns + record_hash)."""
    stored: dict[str, pd.Series] = {}
    canon: dict[str, pd.Series] = {}
    for col, spec in config["columns"].items():
        stored[col], canon[col] = _canonicalize(valid[col], spec)
    out = pd.DataFrame(stored, index=valid.index)
    canon_df = pd.DataFrame(canon, index=valid.index)
    for name, spec in (config.get("derived") or {}).items():
        out[name] = _derive(spec, canon_df)
    out["record_hash"] = _hash_rows(canon_df)
    return out
