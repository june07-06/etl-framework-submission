"""Load pipeline.yaml and dataset YAML files and check they are well-formed.

Why check so much: a typo such as `requried: true` would otherwise be ignored
silently and a rule would quietly stop working. We fail early with a clear message.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from etl.errors import ConfigError
from etl.transform import DERIVED_SQL_TYPES

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IDENTIFIER = re.compile(r"^[a-z][a-z0-9_]*$")  # snake_case; also keeps names safe to use in SQL
COLUMN_TYPES = {"string", "integer", "decimal", "date", "timestamp"}
COLUMN_KEYS = {"type", "required", "pattern", "allowed_values", "min", "max", "not_in_future", "transform"}
VALIDATION_MODES = {"vectorized", "rowwise"}


def resolve_path(value: str | Path) -> Path:
    """Relative paths are relative to the project root; absolute paths are kept."""
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path


def _read_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ConfigError(f"config file not found: {path}")
    with open(path, encoding="utf-8") as handle:
        content = yaml.safe_load(handle)
    if not isinstance(content, dict):
        raise ConfigError(f"config file is not a YAML mapping: {path}")
    return content


def _require(config: dict, key: str, where: str) -> Any:
    if key not in config or config[key] in (None, ""):
        raise ConfigError(f"{where}: missing required key '{key}'")
    return config[key]


def _check_identifier(value: Any, where: str) -> None:
    if not isinstance(value, str) or not IDENTIFIER.match(value):
        raise ConfigError(f"{where}: '{value}' must be snake_case (lowercase letters, digits, underscores)")


def load_pipeline_config(path: str | Path) -> dict[str, Any]:
    """Read pipeline.yaml and resolve its paths."""
    config = _read_yaml(resolve_path(path))
    for key in ("database_path", "input_dir", "log_file", "reports_dir", "datasets"):
        _require(config, key, "pipeline.yaml")
    mode = config.setdefault("validation_mode", "vectorized")
    if mode not in VALIDATION_MODES:
        raise ConfigError(f"pipeline.yaml: validation_mode must be one of {sorted(VALIDATION_MODES)}")
    if not isinstance(config["datasets"], list) or not config["datasets"]:
        raise ConfigError("pipeline.yaml: 'datasets' must be a non-empty list of dataset config paths")
    for key in ("database_path", "input_dir", "log_file", "reports_dir"):
        config[key] = resolve_path(config[key])
    config["datasets"] = [resolve_path(item) for item in config["datasets"]]
    return config


def load_dataset_config(path: str | Path) -> dict[str, Any]:
    """Read one dataset YAML file and validate its structure."""
    config = _read_yaml(resolve_path(path))
    validate_dataset_config(config)
    return config


def validate_dataset_config(config: dict[str, Any]) -> None:
    """Raise ConfigError if the dataset config is incomplete or uses unsupported options."""
    name = _require(config, "name", "dataset config")
    where = f"dataset '{name}'"
    _check_identifier(name, where)
    _require(config, "source_file", where)
    columns = _require(config, "columns", where)
    natural_key = _require(config, "natural_key", where)
    version_column = _require(config, "version_column", where)
    target = _require(config, "target", where)
    for key in ("history_table", "current_table"):
        _check_identifier(_require(target, key, f"{where} target"), f"{where} target.{key}")

    for col, spec in columns.items():
        _check_identifier(col, f"{where} column")
        _validate_column_spec(col, spec, where)
    for key_col in [*natural_key, version_column]:
        if key_col not in columns:
            raise ConfigError(f"{where}: key column '{key_col}' is not defined under columns")
        if not columns[key_col].get("required", False):
            raise ConfigError(f"{where}: key column '{key_col}' must be required: true")

    for ref in config.get("references") or []:
        for key in ("column", "parent_table", "parent_column"):
            _require(ref, key, f"{where} reference")
        if ref["column"] not in columns:
            raise ConfigError(f"{where}: reference column '{ref['column']}' is not defined under columns")
        _check_identifier(ref["parent_table"], f"{where} reference parent_table")
        _check_identifier(ref["parent_column"], f"{where} reference parent_column")

    for derived_name, spec in (config.get("derived") or {}).items():
        _validate_derived(derived_name, spec, columns, where)


def _validate_column_spec(col: str, spec: dict, where: str) -> None:
    label = f"{where} column '{col}'"
    if spec.get("type") not in COLUMN_TYPES:
        raise ConfigError(f"{label}: type must be one of {sorted(COLUMN_TYPES)}")
    unknown = set(spec) - COLUMN_KEYS
    if unknown:
        raise ConfigError(f"{label}: unknown option(s) {sorted(unknown)}; supported: {sorted(COLUMN_KEYS)}")
    kind = spec["type"]
    if ("min" in spec or "max" in spec) and kind not in ("integer", "decimal"):
        raise ConfigError(f"{label}: min/max only apply to integer or decimal columns")
    if spec.get("not_in_future") and kind not in ("date", "timestamp"):
        raise ConfigError(f"{label}: not_in_future only applies to date or timestamp columns")
    if "transform" in spec and (kind != "string" or spec["transform"] not in ("lowercase", "uppercase")):
        raise ConfigError(f"{label}: transform must be 'lowercase' or 'uppercase' on a string column")
    if "allowed_values" in spec and not isinstance(spec["allowed_values"], list):
        raise ConfigError(f"{label}: allowed_values must be a list")
    if "pattern" in spec:
        try:
            re.compile(spec["pattern"])
        except re.error as exc:
            raise ConfigError(f"{label}: invalid regex pattern ({exc})") from exc


def _validate_derived(name: str, spec: dict, columns: dict, where: str) -> None:
    label = f"{where} derived '{name}'"
    _check_identifier(name, label)
    if name in columns:
        raise ConfigError(f"{label}: clashes with a source column of the same name")
    operation = spec.get("operation")
    if operation not in DERIVED_SQL_TYPES:
        raise ConfigError(f"{label}: operation must be one of {sorted(DERIVED_SQL_TYPES)}")
    sources = spec.get("sources") or []
    for source in sources:
        if source not in columns:
            raise ConfigError(f"{label}: source column '{source}' is not defined under columns")
    if operation == "split_part":
        if len(sources) != 1 or "delimiter" not in spec or "index" not in spec:
            raise ConfigError(f"{label}: split_part needs one source, a delimiter and an index")
    elif operation == "multiply_to_cents":
        if not sources or any(columns[s]["type"] not in ("integer", "decimal") for s in sources):
            raise ConfigError(f"{label}: multiply_to_cents needs integer/decimal source columns")
    elif operation == "date_part":
        if len(sources) != 1 or columns[sources[0]]["type"] not in ("date", "timestamp"):
            raise ConfigError(f"{label}: date_part needs one date/timestamp source column")
