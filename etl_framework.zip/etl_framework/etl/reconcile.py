"""Reconciliation: prove the target tables agree with the source file, the run log and (optionally)
the expected answers.

Every check counts VIOLATIONS: 0 means PASS. All checks are generated from the dataset configs,
so a new dataset is reconciled without code changes. Nothing here writes to the database.

Sections of the report:
  1. run reconciliation   rows_in = inserted + already loaded + rejected + duplicates dropped
  2. where the rows went  rejects by reason, so every difference is explained
  3. integrity checks     keys, current = latest history, references, aggregates, lineage, rejects
  4. source-to-target     the source file is re-counted independently of the pipeline
  5. expected answers     (optional) comparison with the generator's separately stored answers
"""
from __future__ import annotations

import csv
import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from etl.parsing import utc_iso

KNOWN_REJECT_CODES = {"MALFORMED_ROW", "MISSING_REQUIRED_FIELD", "INVALID_TYPE", "INVALID_FORMAT",
                      "INVALID_ALLOWED_VALUE", "OUT_OF_RANGE", "FUTURE_TIMESTAMP", "CONFLICTING_DUPLICATE",
                      "INVALID_REFERENCE"}
RUN_COLUMNS = ["run_id", "source_file", "rows_in", "rows_inserted", "rows_already_loaded", "rows_rejected",
               "duplicates_dropped", "late_records"]


class ReportError(Exception):
    """The report cannot be produced (for example the pipeline has never run on this database)."""


@dataclass
class CheckResult:
    """One check. violations == 0 means PASS."""

    section: str          # integrity | source | expected
    dataset: str
    name: str
    description: str
    violations: int
    detail: str = ""

    @property
    def passed(self) -> bool:
        return self.violations == 0


@dataclass
class Report:
    generated_at: str
    database: str
    runs: list[dict[str, Any]]                          # latest successful run per dataset
    breakdowns: dict[str, list[tuple[str, int]]]        # dataset -> [(reject reason, rows)]
    checks: list[CheckResult] = field(default_factory=list)
    compared_with_expected: bool = False

    @property
    def passed(self) -> bool:
        return all(check.passed for check in self.checks)


# ---------- small database helpers ----------

def _scalar(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> Any:
    return conn.execute(sql, params).fetchone()[0]


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    return bool(conn.execute("select 1 from sqlite_master where type = 'table' and name = ?", (name,)).fetchone())


def _row_dict(cursor: sqlite3.Cursor) -> dict[str, Any] | None:
    row = cursor.fetchone()
    return dict(zip([d[0] for d in cursor.description], row)) if row else None


def _latest_run(conn: sqlite3.Connection, dataset: str, success_only: bool) -> dict[str, Any] | None:
    status = "and status = 'SUCCESS' " if success_only else ""
    return _row_dict(conn.execute(
        f"select status, {', '.join(RUN_COLUMNS)} from pipeline_runs where dataset = ? {status}"
        "order by started_at desc, rowid desc limit 1", (dataset,)))


def _on(keys: list[str], left: str, right: str) -> str:
    return " and ".join(f"{left}.{k} = {right}.{k}" for k in keys)


# ---------- integrity checks (database only) ----------

def _dataset_checks(conn: sqlite3.Connection, cfg: dict[str, Any]) -> list[CheckResult]:
    name, keys, version = cfg["name"], cfg["natural_key"], cfg["version_column"]
    hist, cur = cfg["target"]["history_table"], cfg["target"]["current_table"]
    key_list = ", ".join(keys)
    results: list[CheckResult] = []

    def add(check: str, description: str, violations: int, detail: str = "") -> None:
        results.append(CheckResult("integrity", name, check, description, int(violations), detail))

    latest_any = _latest_run(conn, name, success_only=False)
    add("latest_run_succeeded", "the most recent run of this dataset finished with status SUCCESS",
        0 if latest_any and latest_any["status"] == "SUCCESS" else 1,
        f"latest status = {latest_any['status'] if latest_any else 'no run recorded'}")
    add("run_counts_add_up", "in every successful run rows_in = inserted + already loaded + rejected + duplicates",
        _scalar(conn, "select count(*) from pipeline_runs where dataset = ? and status = 'SUCCESS' and rows_in != "
                      "rows_inserted + rows_already_loaded + rows_rejected + duplicates_dropped", (name,)))
    if not (_table_exists(conn, hist) and _table_exists(conn, cur)):
        add("target_tables_exist", "the history and current tables exist", 1, "run the pipeline first")
        return results

    add("history_key_unique", "primary key (natural key + version) is unique in the history table",
        _scalar(conn, f"select count(*) from (select 1 from {hist} group by {key_list}, {version} having count(*) > 1)"))
    add("current_key_unique", "natural key is unique in the current table",
        _scalar(conn, f"select count(*) from (select 1 from {cur} group by {key_list} having count(*) > 1)"))
    add("current_has_history", "every current row has a history row",
        _scalar(conn, f"select count(*) from {cur} c where not exists "
                      f"(select 1 from {hist} h where {_on(keys, 'h', 'c')})"))
    add("history_has_current", "every history key has a current row",
        _scalar(conn, f"select count(*) from (select distinct {key_list} from {hist}) h where not exists "
                      f"(select 1 from {cur} c where {_on(keys, 'c', 'h')})"))
    add("current_is_latest_history_row", "each current row is identical to the newest version in history",
        _scalar(conn, f"select count(*) from {cur} c where not exists (select 1 from {hist} h where "
                      f"{_on(keys, 'h', 'c')} and h.{version} = (select max(x.{version}) from {hist} x where "
                      f"{_on(keys, 'x', 'c')}) and h.record_hash = c.record_hash)"))
    inserted = _scalar(conn, "select coalesce(sum(rows_inserted), 0) from pipeline_runs "
                             "where dataset = ? and status = 'SUCCESS'", (name,))
    in_history = _scalar(conn, f"select count(*) from {hist}")
    add("history_equals_inserted", "history rows = sum of rows_inserted over successful runs",
        abs(in_history - inserted), f"history rows = {in_history}, sum(rows_inserted) = {inserted}")
    add("lineage_complete", "every history row points to a successful run of this dataset",
        _scalar(conn, f"select count(*) from {hist} where run_id not in (select run_id from pipeline_runs "
                      f"where dataset = ? and status = 'SUCCESS')", (name,)))

    for ref in cfg.get("references") or []:
        parent, column, parent_column = ref["parent_table"], ref["column"], ref["parent_column"]
        if not _table_exists(conn, parent):
            add(f"reference_{column}", f"{column} exists in {parent}", _scalar(conn, f"select count(*) from {hist}"),
                f"parent table {parent} does not exist")
            continue
        add(f"reference_{column}", f"every {hist}.{column} exists in {parent}.{parent_column} (referential integrity)",
            _scalar(conn, f"select count(*) from {hist} h where not exists "
                          f"(select 1 from {parent} p where p.{parent_column} = h.{column})"))

    for column, spec in (cfg.get("derived") or {}).items():
        if spec["operation"] == "multiply_to_cents":          # key aggregate: current total = total of newest versions
            in_current = _scalar(conn, f"select coalesce(sum({column}), 0) from {cur}")
            newest = _scalar(conn, f"select coalesce(sum(h.{column}), 0) from {hist} h where h.{version} = "
                                   f"(select max(x.{version}) from {hist} x where {_on(keys, 'x', 'h')})")
            add(f"aggregate_{column}", f"sum({column}) in current = sum over the newest history versions",
                abs(in_current - newest), f"current = {in_current}, newest history = {newest}")
    return results


def _reject_checks(conn: sqlite3.Connection, datasets: list[dict[str, Any]]) -> list[CheckResult]:
    results: list[CheckResult] = []
    if not _table_exists(conn, "rejected_records"):
        return [CheckResult("integrity", "all", "rejects_table_exists", "rejected_records exists", 1)]
    basic = "reject_reasons = '' or source_file = '' or row_number < 2"
    try:
        untraceable = _scalar(conn, f"select count(*) from rejected_records where {basic} or not json_valid(raw_record)")
    except sqlite3.OperationalError:                        # this SQLite build has no JSON functions
        untraceable = _scalar(conn, f"select count(*) from rejected_records where {basic} or raw_record = ''")
    results.append(CheckResult("integrity", "all", "rejects_traceable",
                               "every reject has a reason, source file, line number (>= 2) and the original row as JSON",
                               int(untraceable)))
    unknown = 0
    for (reasons,) in conn.execute("select distinct reject_reasons from rejected_records").fetchall():
        unknown += sum(1 for part in reasons.split("; ") if part.split(":")[0] not in KNOWN_REJECT_CODES)
    results.append(CheckResult("integrity", "all", "reject_reason_codes_known",
                               "every reject reason uses a documented reason code", unknown))
    for cfg in datasets:
        run = _latest_run(conn, cfg["name"], success_only=True)
        if run is None:
            continue
        seen = _scalar(conn, "select count(*) from rejected_records where dataset = ? and last_seen_run_id = ?",
                       (cfg["name"], run["run_id"]))
        results.append(CheckResult("integrity", cfg["name"], "rejects_cover_latest_run",
                                   "rejects seen in the latest run = rows_rejected of that run",
                                   abs(seen - run["rows_rejected"]),
                                   f"reject records = {seen}, rows_rejected = {run['rows_rejected']}"))
    return results


# ---------- source-to-target ----------

def _source_checks(conn: sqlite3.Connection, datasets: list[dict[str, Any]], input_dir: Path) -> list[CheckResult]:
    results = []
    for cfg in datasets:
        run = _latest_run(conn, cfg["name"], success_only=True)
        path = input_dir / cfg["source_file"]
        if not path.exists():
            results.append(CheckResult("source", cfg["name"], "source_rows_equal_rows_in",
                                       "source file row count = rows_in of the latest run", 1, f"{path} not found"))
            continue
        with open(path, newline="", encoding="utf-8-sig") as handle:      # counted without any pipeline code
            reader = csv.reader(handle)
            next(reader, None)
            source_rows = sum(1 for row in reader if row)
        rows_in = run["rows_in"] if run else None
        results.append(CheckResult(
            "source", cfg["name"], "source_rows_equal_rows_in",
            "source file row count (counted independently) = rows_in of the latest run",
            abs(source_rows - rows_in) if run else 1, f"source rows = {source_rows}, rows_in = {rows_in}"))
    return results


# ---------- comparison with expected answers ----------

def _compare_with_expected(conn: sqlite3.Connection, datasets: list[dict[str, Any]],
                           expected_dir: Path) -> list[CheckResult]:
    summary = json.loads((expected_dir / "expected_summary.json").read_text(encoding="utf-8"))
    rejects_file = expected_dir / "expected_rejects.csv"
    expected_rejects = list(csv.DictReader(open(rejects_file, encoding="utf-8"))) if rejects_file.exists() else []
    results: list[CheckResult] = []
    for cfg in datasets:
        name, want = cfg["name"], summary.get(cfg["name"])
        if want is None:
            continue
        hist, cur = cfg["target"]["history_table"], cfg["target"]["current_table"]
        run = _latest_run(conn, name, success_only=True)

        def add(check: str, description: str, violations: int, detail: str = "") -> None:
            results.append(CheckResult("expected", name, check, description, int(violations), detail))

        if run is None:
            add("expected_run_counts", "a successful run exists to compare", 1, "no successful run")
            continue
        # The answer key describes loading the file into an empty database. A rerun inserts nothing new (those rows
        # are "already loaded"), so compare rows LOADED = inserted + already loaded, and the late count only for a
        # first load.
        wrong = [f"{f}: got {run[f]}, expected {want[f]}" for f in ("rows_in", "rows_rejected", "duplicates_dropped")
                 if run[f] != want[f]]
        loaded = run["rows_inserted"] + run["rows_already_loaded"]
        if loaded != want["rows_inserted"]:
            wrong.append(f"rows loaded (inserted + already loaded): got {loaded}, expected {want['rows_inserted']}")
        if run["rows_already_loaded"] == 0 and run["late_records"] != want["late_records"]:
            wrong.append(f"late_records: got {run['late_records']}, expected {want['late_records']}")
        add("expected_run_counts", "run counts equal expected_summary.json (rows in, rows loaded = inserted + already "
            "loaded, rejected, duplicates; late records for a first load)", len(wrong), "; ".join(wrong))
        tables = {"history_rows": _scalar(conn, f"select count(*) from {hist}"),
                  "current_rows": _scalar(conn, f"select count(*) from {cur}")}
        wrong = [f"{k}: got {v}, expected {want[k]}" for k, v in tables.items() if v != want[k]]
        add("expected_table_rows", "history and current row counts equal expected_summary.json", len(wrong),
            "; ".join(wrong))

        wanted = {(int(r["row_number"]), r["expected_reject_reasons"]) for r in expected_rejects
                  if r["dataset"] == name}
        found = set(conn.execute("select row_number, reject_reasons from rejected_records where dataset = ? "
                                 "and last_seen_run_id = ?", (name, run["run_id"])))
        add("expected_rejects", "rejected rows and their reasons equal expected_rejects.csv (row number and reason)",
            len(wanted ^ found), f"missing {len(wanted - found)}, unexpected {len(found - wanted)}")

        current_file = expected_dir / f"expected_current_{name}.csv"
        if current_file.exists():
            with open(current_file, encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                columns = list(reader.fieldnames or [])
                wanted_rows = {tuple(row[c] for c in columns) for row in reader}
            found_rows = {tuple(str(v) for v in row) for row in conn.execute(f"select {', '.join(columns)} from {cur}")}
            add("expected_current_rows", f"current rows equal {current_file.name} (the latest version of every record)",
                len(wanted_rows ^ found_rows), f"missing {len(wanted_rows - found_rows)}, unexpected "
                                               f"{len(found_rows - wanted_rows)}")
        for key, expected_total in want.items():                   # e.g. current_order_amount_cents_sum
            if key.endswith("_sum") and key.startswith(("current_", "history_")):
                prefix = key.split("_")[0]
                column = key[len(prefix) + 1:-len("_sum")]
                table = cur if prefix == "current" else hist
                total = _scalar(conn, f"select coalesce(sum({column}), 0) from {table}")
                add(f"expected_{key}", f"sum({column}) in {table} equals the expected total",
                    abs(total - expected_total), f"got {total}, expected {expected_total}")
    return results


# ---------- the report ----------

def build_report(conn: sqlite3.Connection, datasets: list[dict[str, Any]], *, input_dir: Path | None = None,
                 expected_dir: Path | None = None, database: str = "") -> Report:
    """Run every check and collect the numbers for the report."""
    if not _table_exists(conn, "pipeline_runs"):
        raise ReportError("pipeline_runs does not exist: run the pipeline on this database first")
    runs, breakdowns = [], {}
    for cfg in datasets:
        run = _latest_run(conn, cfg["name"], success_only=True)
        if run is not None:
            runs.append({"dataset": cfg["name"], **run})
            if _table_exists(conn, "rejected_records"):
                breakdowns[cfg["name"]] = conn.execute(
                    "select reject_reasons, count(*) from rejected_records where dataset = ? and last_seen_run_id = ? "
                    "group by reject_reasons order by count(*) desc, reject_reasons", (cfg["name"], run["run_id"])).fetchall()
    report = Report(utc_iso(datetime.now(timezone.utc)), database, runs, breakdowns)
    for cfg in datasets:
        report.checks += _dataset_checks(conn, cfg)
    report.checks += _reject_checks(conn, datasets)
    if input_dir is not None:
        report.checks += _source_checks(conn, datasets, input_dir)
    if expected_dir is not None:
        report.checks += _compare_with_expected(conn, datasets, expected_dir)
        report.compared_with_expected = True
    return report


def _table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    lines += ["| " + " | ".join(str(cell) for cell in row) + " |" for row in rows]
    return lines


def render_markdown(report: Report) -> str:
    """The report as Markdown (printed to the console and saved to a file)."""
    passed = sum(1 for c in report.checks if c.passed)
    lines = ["# Reconciliation report", "",
             f"Generated: {report.generated_at}  ", f"Database: `{report.database}`  ",
             f"Result: **{'PASS' if report.passed else 'FAIL'}** ({passed} of {len(report.checks)} checks passed)", "",
             "## 1. Run reconciliation (latest successful run of each dataset)", "",
             "`rows_in = rows_inserted + rows_already_loaded + rows_rejected + duplicates_dropped`", ""]
    rows = []
    for r in report.runs:
        total = r["rows_inserted"] + r["rows_already_loaded"] + r["rows_rejected"] + r["duplicates_dropped"]
        rows.append([r["dataset"], r["run_id"][:8], r["rows_in"], r["rows_inserted"], r["rows_already_loaded"],
                     r["rows_rejected"], r["duplicates_dropped"], r["late_records"],
                     f"{total} = {r['rows_in']}: {'PASS' if total == r['rows_in'] else 'FAIL'}"])
    lines += _table(["dataset", "run", "rows_in", "inserted", "already_loaded", "rejected", "duplicates_dropped",
                     "late (kept in history)", "sum of parts = rows_in"], rows)
    lines += ["", "## 2. Where the rows went: rejects by reason (latest run)", ""]
    reason_rows = [[ds, reason, n] for ds, items in report.breakdowns.items() for reason, n in items]
    lines += _table(["dataset", "reject reason", "rows"], reason_rows) if reason_rows else ["No rejected rows."]
    for section, title in (("integrity", "3. Integrity checks"), ("source", "4. Source-to-target"),
                           ("expected", "5. Comparison with the expected answers")):
        checks = [c for c in report.checks if c.section == section]
        if not checks:
            continue
        lines += ["", f"## {title}", ""]
        lines += _table(["dataset", "check", "violations", "result", "what it proves"],
                        [[c.dataset, c.name, c.violations, "PASS" if c.passed else "FAIL",
                          c.description + (f" ({c.detail})" if c.detail and not c.passed else "")] for c in checks])
    if not report.compared_with_expected:
        lines += ["", "_No expected answers were given, so section 5 was skipped._"]
    return "\n".join(lines) + "\n"
