"""Extract: read a source CSV into a DataFrame of text values.

Why the csv module and not pandas.read_csv: we need the exact line number of
every row, and we must catch rows with the wrong number of fields (malformed)
instead of letting pandas skip or crash on them.
"""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from etl.errors import SchemaError


@dataclass
class ExtractResult:
    """What extract hands to the next step."""

    header: list[str]
    data: pd.DataFrame        # well-formed rows; every value is text; index = source line number
    malformed: pd.DataFrame   # rows with the wrong field count, already in reject format
    blank_lines: int          # fully blank lines (ignored, but counted and logged)

    @property
    def rows_in(self) -> int:
        """Number of data rows read (well-formed + malformed). The header is not a data row."""
        return len(self.data) + len(self.malformed)


def extract_csv(path: Path) -> ExtractResult:
    """Read a CSV file. Raises FileNotFoundError if missing, SchemaError if it has no header."""
    row_numbers: list[int] = []
    rows: list[list[str]] = []
    bad_numbers: list[int] = []
    bad_records: list[str] = []
    blank_lines = 0

    with open(path, newline="", encoding="utf-8-sig") as handle:  # utf-8-sig removes an Excel BOM
        reader = csv.reader(handle)
        header = next(reader, None)
        if header is None:
            raise SchemaError("SCHEMA_NO_HEADER: file is empty")
        header = [name.strip() for name in header]

        for fields in reader:
            line_number = reader.line_num  # header is line 1
            if not fields:
                blank_lines += 1
            elif len(fields) != len(header):
                bad_numbers.append(line_number)
                bad_records.append(json.dumps({"raw_fields": fields}, ensure_ascii=False))
            else:
                row_numbers.append(line_number)
                rows.append(fields)

    index = pd.Index(row_numbers, name="row_number", dtype="int64")
    data = pd.DataFrame(rows, columns=header, index=index, dtype="string")
    malformed = pd.DataFrame(
        {"reject_reasons": "MALFORMED_ROW", "raw_record": bad_records},
        index=pd.Index(bad_numbers, name="row_number", dtype="int64"),
    )
    return ExtractResult(header=header, data=data, malformed=malformed, blank_lines=blank_lines)
