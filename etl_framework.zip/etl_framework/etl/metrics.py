"""Metrics: the pipeline_runs table (one row per dataset per run).

A row is written as RUNNING *before* any work starts and committed immediately,
so even a crashed run leaves evidence. It is later updated to SUCCESS or FAILED.
"""
from __future__ import annotations

import sqlite3
from typing import Any

PIPELINE_RUNS_DDL = """
CREATE TABLE IF NOT EXISTS pipeline_runs (
    run_id               TEXT NOT NULL,
    dataset              TEXT NOT NULL,
    source_file          TEXT NOT NULL,
    status               TEXT NOT NULL,          -- RUNNING / SUCCESS / FAILED / SKIPPED
    started_at           TEXT NOT NULL,
    ended_at             TEXT,
    duration_seconds     REAL,
    rows_in              INTEGER,
    rows_inserted        INTEGER,
    rows_already_loaded  INTEGER,
    rows_rejected        INTEGER,
    duplicates_dropped   INTEGER,
    late_records         INTEGER,
    extract_seconds      REAL,
    validate_seconds     REAL,
    transform_seconds    REAL,
    load_seconds         REAL,
    failure_reason       TEXT,
    warnings             TEXT,
    PRIMARY KEY (run_id, dataset)
)
"""

COUNT_FIELDS = ("rows_in", "rows_inserted", "rows_already_loaded", "rows_rejected",
                "duplicates_dropped", "late_records")
TIMING_FIELDS = ("extract_seconds", "validate_seconds", "transform_seconds", "load_seconds")


def init_metrics(conn: sqlite3.Connection) -> None:
    """Create the pipeline_runs table if it does not exist."""
    conn.execute(PIPELINE_RUNS_DDL)


def start_run(conn: sqlite3.Connection, run_id: str, dataset: str, source_file: str, started_at: str) -> None:
    """Record that a dataset run has begun (status RUNNING)."""
    conn.execute(
        "INSERT INTO pipeline_runs (run_id, dataset, source_file, status, started_at) VALUES (?, ?, ?, 'RUNNING', ?)",
        (run_id, dataset, source_file, started_at),
    )


def _finish(conn: sqlite3.Connection, run_id: str, dataset: str, status: str, ended_at: str,
            duration: float, counts: dict[str, int], timings: dict[str, float],
            failure_reason: str | None, warnings: list[str]) -> None:
    values: dict[str, Any] = {"status": status, "ended_at": ended_at, "duration_seconds": round(duration, 4),
                              "failure_reason": failure_reason,
                              "warnings": "; ".join(warnings) if warnings else None}
    values.update({name: counts.get(name) for name in COUNT_FIELDS})
    values.update({name: round(timings[name], 4) if name in timings else None for name in TIMING_FIELDS})
    assignments = ", ".join(f"{name} = ?" for name in values)
    conn.execute(f"UPDATE pipeline_runs SET {assignments} WHERE run_id = ? AND dataset = ?",
                 [*values.values(), run_id, dataset])


def finish_success(conn: sqlite3.Connection, run_id: str, dataset: str, ended_at: str, duration: float,
                   counts: dict[str, int], timings: dict[str, float], warnings: list[str]) -> None:
    """Mark a dataset run SUCCESS and store its counts and timings."""
    _finish(conn, run_id, dataset, "SUCCESS", ended_at, duration, counts, timings, None, warnings)


def finish_failed(conn: sqlite3.Connection, run_id: str, dataset: str, ended_at: str, duration: float,
                  reason: str, counts: dict[str, int], timings: dict[str, float], warnings: list[str]) -> None:
    """Mark a dataset run FAILED with the failure reason (counts are whatever was known)."""
    _finish(conn, run_id, dataset, "FAILED", ended_at, duration, counts, timings, reason, warnings)


def record_skipped(conn: sqlite3.Connection, run_id: str, dataset: str, source_file: str,
                   now: str, reason: str) -> None:
    """Record a dataset that was not attempted because an earlier dataset failed."""
    conn.execute(
        "INSERT INTO pipeline_runs (run_id, dataset, source_file, status, started_at, ended_at, failure_reason) "
        "VALUES (?, ?, ?, 'SKIPPED', ?, ?, ?)",
        (run_id, dataset, source_file, now, now, reason),
    )
