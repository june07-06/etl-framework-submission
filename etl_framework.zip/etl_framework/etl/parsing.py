"""Small parsing helpers shared by validate.py and transform.py.

All values arrive as text. These helpers decide whether a text value is a valid
integer / decimal / date / timestamp and convert it in a deterministic way.
"""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

import pandas as pd

INTEGER_RE = r"[+-]?\d+"
DECIMAL_RE = r"[+-]?\d+(\.\d+)?"
DATE_RE = r"\d{4}-\d{2}-\d{2}"
TIMESTAMP_RE = r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?"

ISO_TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%SZ"


def matches(series: pd.Series, pattern: str) -> pd.Series:
    """True where the whole text matches the regex; missing values give False."""
    return series.str.fullmatch(pattern).fillna(False).astype(bool)


def parse_date(series: pd.Series) -> pd.Series:
    """Parse 'YYYY-MM-DD' text; anything invalid (including 2024-02-30) becomes NaT."""
    ok = matches(series, DATE_RE)
    return pd.to_datetime(series.where(ok), format="%Y-%m-%d", errors="coerce")


def parse_timestamp(series: pd.Series) -> pd.Series:
    """Parse ISO-8601 timestamps into UTC. A timestamp without an offset is treated as UTC."""
    ok = matches(series, TIMESTAMP_RE)
    return pd.to_datetime(series.where(ok), format="ISO8601", utc=True, errors="coerce")


def decimal_to_text(value: Decimal) -> str:
    """Canonical text for a decimal: '12.50' -> '12.5', '100' -> '100', '-0.00' -> '0'."""
    return format((value + 0).normalize(), "f")


def utc_iso(moment: datetime) -> str:
    """Format a datetime as ISO-8601 UTC with second precision, e.g. 2026-11-14T10:00:01Z."""
    return moment.astimezone(timezone.utc).strftime(ISO_TIMESTAMP_FORMAT)
