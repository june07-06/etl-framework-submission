"""Reusable mini ETL framework core. Contains no dataset-specific logic."""
