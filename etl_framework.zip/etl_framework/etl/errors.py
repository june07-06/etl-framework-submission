"""Custom exceptions so failures have clear, searchable names in logs and metrics."""


class ConfigError(Exception):
    """A config file is missing a key, has a typo, or uses an unsupported option."""


class SchemaError(Exception):
    """The source file's columns do not match the dataset config (e.g. a required column is missing)."""


class ReconciliationError(Exception):
    """Row counts do not add up: some input row was neither loaded, rejected nor counted."""
