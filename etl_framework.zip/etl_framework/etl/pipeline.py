"""Orchestrator: run each configured dataset through
extract -> validate -> transform -> duplicate/reference checks -> load,
recording logs and metrics. It contains no dataset-specific logic.
"""
from __future__ import annotations

import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

import pandas as pd

from etl import extract, load, metrics, transform, validate
from etl.config_loader import load_dataset_config, load_pipeline_config, resolve_path
from etl.errors import ConfigError
from etl.logging_setup import get_run_logger, setup_logging, shutdown_logging
from etl.parsing import utc_iso


@dataclass
class DatasetResult:
    """Outcome of one dataset in one run (mirrors a pipeline_runs row)."""

    run_id: str
    dataset: str
    status: str
    rows_in: int = 0
    rows_inserted: int = 0
    rows_already_loaded: int = 0
    rows_rejected: int = 0
    duplicates_dropped: int = 0
    late_records: int = 0
    duration_seconds: float = 0.0
    failure_reason: str | None = None
    warnings: list[str] = field(default_factory=list)


@contextmanager
def _timed(timings: dict[str, float], name: str) -> Iterator[None]:
    """Add the elapsed seconds of a block to timings[name]."""
    start = time.perf_counter()
    try:
        yield
    finally:
        timings[name] = timings.get(name, 0.0) + time.perf_counter() - start


def _failure_reason(exc: Exception) -> str:
    """SchemaError messages already start with a code such as SCHEMA_MISSING_COLUMNS."""
    return str(exc) if type(exc).__name__ == "SchemaError" else f"{type(exc).__name__}: {exc}"


def run_pipeline(config_path: str | Path = "config/pipeline.yaml", *, input_dir: str | Path | None = None,
                 db_path: str | Path | None = None, log_file: str | Path | None = None,
                 dataset_names: list[str] | None = None, now: datetime | None = None) -> list[DatasetResult]:
    """Run all (or the named) datasets once. One run_id is shared by every dataset in this call."""
    pipeline_cfg = load_pipeline_config(config_path)
    datasets = [load_dataset_config(p) for p in pipeline_cfg["datasets"]]
    if dataset_names:
        known = [d["name"] for d in datasets]
        unknown = [n for n in dataset_names if n not in known]
        if unknown:
            raise ConfigError(f"unknown dataset(s) {unknown}; configured: {known}")
        datasets = [d for d in datasets if d["name"] in dataset_names]

    input_path = resolve_path(input_dir) if input_dir else pipeline_cfg["input_dir"]
    database = resolve_path(db_path) if db_path else pipeline_cfg["database_path"]
    log_path = resolve_path(log_file) if log_file else pipeline_cfg["log_file"]
    run_id = str(uuid.uuid4())
    now = now or datetime.now(timezone.utc)

    setup_logging(log_path)
    log = get_run_logger(run_id)
    log.info("run started", extra={"step": "run", "datasets": [d["name"] for d in datasets],
                                   "input_dir": str(input_path), "database": str(database)})
    conn = load.connect(database)
    results: list[DatasetResult] = []
    try:
        metrics.init_metrics(conn)
        load.ensure_reject_table(conn)
        failed: str | None = None
        for config in datasets:
            if failed is not None:
                reason = f"UPSTREAM_FAILED: dataset '{failed}' failed earlier in this run"
                metrics.record_skipped(conn, run_id, config["name"], config["source_file"], utc_iso(now), reason)
                log.warning("dataset skipped", extra={"dataset": config["name"], "step": "run", "reason": reason})
                results.append(DatasetResult(run_id, config["name"], "SKIPPED", failure_reason=reason))
                continue
            result = _run_dataset(conn, config, input_path, run_id, now, pipeline_cfg["validation_mode"], log)
            results.append(result)
            if result.status == "FAILED":
                failed = config["name"]
        log.info("run finished", extra={"step": "run", "statuses": {r.dataset: r.status for r in results}})
    finally:
        conn.close()
        shutdown_logging()
    return results


def _run_dataset(conn, config: dict[str, Any], input_dir: Path, run_id: str, now: datetime,
                 validation_mode: str, log) -> DatasetResult:
    """Run one dataset; any error is recorded as FAILED (with reason) instead of crashing the run."""
    name = config["name"]
    source_path = input_dir / config["source_file"]
    source_file = source_path.name
    started = time.perf_counter()
    timings: dict[str, float] = {}
    counts: dict[str, int] = {}
    warnings: list[str] = []
    metrics.start_run(conn, run_id, name, source_file, utc_iso(datetime.now(timezone.utc)))
    log.info("dataset started", extra={"dataset": name, "step": "start", "source_file": source_file})
    try:
        with _timed(timings, "extract_seconds"):
            extracted = extract.extract_csv(source_path)
        counts["rows_in"] = extracted.rows_in
        log.info("extract done", extra={"dataset": name, "step": "extract", "rows_in": extracted.rows_in,
                                        "malformed_rows": len(extracted.malformed),
                                        "blank_lines_ignored": extracted.blank_lines})

        with _timed(timings, "validate_seconds"):
            extra_columns = validate.check_schema(extracted.header, config["columns"])
            if extra_columns:
                warnings.append(f"EXTRA_COLUMNS_IGNORED: {extra_columns}")
                log.warning("extra columns ignored", extra={"dataset": name, "step": "validate",
                                                            "extra_columns": extra_columns})
            normalized = validate.normalize(extracted.data, config["columns"])
            reasons = validate.validate_rows(normalized, config["columns"], now, validation_mode)
            valid = normalized.drop(index=reasons.index)
            reject_parts = [extracted.malformed, validate.build_reject_rows(extracted.data, reasons)]
        log.info("row validation done", extra={"dataset": name, "step": "validate", "valid_rows": len(valid),
                                               "rule_failures": len(reasons)})

        with _timed(timings, "transform_seconds"):
            typed = transform.transform(valid, config)

        with _timed(timings, "validate_seconds"):
            typed, conflict_reasons, duplicates_dropped = validate.check_duplicates(typed, config)
            reject_parts.append(validate.build_reject_rows(extracted.data, conflict_reasons))
            references = config.get("references") or []
            parent_keys = {(r["parent_table"], r["parent_column"]):
                           load.fetch_parent_keys(conn, r["parent_table"], r["parent_column"]) for r in references}
            reference_reasons = validate.check_references(typed, references, parent_keys)
            typed = typed.drop(index=reference_reasons.index)
            reject_parts.append(validate.build_reject_rows(extracted.data, reference_reasons))
        counts["duplicates_dropped"] = duplicates_dropped
        rejects = pd.concat([part for part in reject_parts if not part.empty] or [validate.empty_rejects()])
        log.info("duplicate and reference checks done", extra={
            "dataset": name, "step": "validate", "duplicates_dropped": duplicates_dropped,
            "conflicting_duplicates": len(conflict_reasons), "invalid_references": len(reference_reasons)})

        with _timed(timings, "load_seconds"):
            loaded = load.load_dataset(conn, config, typed, rejects.sort_index(), extracted.data, run_id=run_id,
                                       source_file=source_file, rows_in=extracted.rows_in,
                                       duplicates_dropped=duplicates_dropped, now_iso=utc_iso(now))
        counts.update(rows_inserted=loaded.rows_inserted, rows_already_loaded=loaded.rows_already_loaded,
                      rows_rejected=loaded.rows_rejected, late_records=loaded.late_records)
        duration = time.perf_counter() - started
        metrics.finish_success(conn, run_id, name, utc_iso(datetime.now(timezone.utc)), duration,
                               counts, timings, warnings)
        log.info("dataset finished", extra={"dataset": name, "step": "finish", "status": "SUCCESS",
                                            "duration_seconds": round(duration, 3), **counts})
        return DatasetResult(run_id, name, "SUCCESS", duration_seconds=round(duration, 3),
                             warnings=warnings, **counts)
    except Exception as exc:  # noqa: BLE001 - every failure must be recorded, then reported
        duration = time.perf_counter() - started
        reason = _failure_reason(exc)
        metrics.finish_failed(conn, run_id, name, utc_iso(datetime.now(timezone.utc)), duration,
                              reason, counts, timings, warnings)
        log.error("dataset failed", exc_info=True, extra={"dataset": name, "step": "failed", "failure_reason": reason})
        return DatasetResult(run_id, name, "FAILED", duration_seconds=round(duration, 3),
                             failure_reason=reason, warnings=warnings, **counts)


def results_as_dicts(results: list[DatasetResult]) -> list[dict[str, Any]]:
    """Plain dicts, handy for printing and tests."""
    return [asdict(r) for r in results]
