"""Build the self-contained Google Colab notebook from the project files.

    python build_notebook.py            # writes etl_framework_submission.ipynb next to this file
    python build_notebook.py --check    # exit 1 if the notebook on disk is out of date

The notebook contains one cell per project file (written with %%writefile) followed by cells that run the tests,
the sample data, the reconciliation report, the SQL files, a 100,000-order dataset, the benchmark and a zip of the
results. Rebuild it after changing any project file, so Colab always runs exactly what is in this folder.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NOTEBOOK = ROOT / "etl_framework_submission.ipynb"
NL, QUOTE = chr(10), chr(39)

FOLDERS = ["config/datasets", "data/expected", "data/large", "data/sample", "etl", "generator", "logs", "output",
           "reports", "sql", "tests"]
PACKAGED = ["README.md", "pytest.ini", "requirements.txt", "run_pipeline.py", "run_report.py", "run_benchmark.py",
            "build_notebook.py", "config", "etl", "generator", "sql", "tests", "data/sample", "data/expected", "reports"]

SQL_CELL = '''import sqlite3


def statements(path):
    """Split a .sql file into complete statements (comment-only lines between them are skipped)."""
    buffer = ""
    for line in open(path, encoding="utf-8"):
        if line.strip().startswith("--") and not buffer:
            continue
        buffer += line
        if sqlite3.complete_statement(buffer):
            yield buffer.strip()
            buffer = ""


con = sqlite3.connect("file:output/warehouse.db?mode=ro", uri=True)       # read-only
print("sql/reconciliation.sql: every check must show 0 violations")
for statement in statements("sql/reconciliation.sql"):
    name, violations = con.execute(statement).fetchone()
    print(f"  {'PASS' if violations == 0 else 'FAIL'}  {name}  ({violations})")

queries = list(statements("sql/sample_queries.sql"))
print()
print(len(queries), "sample queries in sql/sample_queries.sql; running Q1, Q2 and Q4:")
for number in (1, 2, 4):
    cursor = con.execute(queries[number - 1])
    print()
    print(f"Q{number}: " + " | ".join(d[0] for d in cursor.description))
    for row in cursor.fetchmany(8):
        print("   " + " | ".join(str(x) for x in row))
con.close()'''

ZIP_CELL = '''import zipfile
from pathlib import Path

include = PACKAGED_LIST
with zipfile.ZipFile("etl_project.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for item in include:
        root = Path(item)
        for path in sorted(root.rglob("*") if root.is_dir() else [root]):
            if path.is_file() and "__pycache__" not in path.parts:
                archive.write(path)
with zipfile.ZipFile("etl_project.zip") as archive:
    print(len(archive.namelist()), "files in etl_project.zip, for example:")
    for name in archive.namelist()[:8]:
        print("  ", name)'''

DOWNLOAD_CELL = '''try:
    from google.colab import files
    files.download("etl_project.zip")
except Exception as exc:  # not running in the Colab front end
    print("download skipped:", exc)'''


def project_files() -> list[str]:
    """Every file the notebook writes, in a fixed order."""
    return (["requirements.txt", "pytest.ini", "config/pipeline.yaml", "config/datasets/customers.yaml",
             "config/datasets/orders.yaml"]
            + sorted(f"etl/{p.name}" for p in (ROOT / "etl").glob("*.py"))
            + ["generator/__init__.py", "generator/generate_data.py", "run_pipeline.py", "run_report.py",
               "run_benchmark.py", "build_notebook.py", "sql/reconciliation.sql", "sql/sample_queries.sql"]
            + sorted(f"tests/{p.name}" for p in (ROOT / "tests").glob("*.py"))
            + ["data/sample/customers.csv", "data/sample/orders.csv"]
            + sorted(f"data/expected/{p.name}" for p in (ROOT / "data" / "expected").iterdir() if p.is_file()))


def run_command(extra: str = "") -> str:
    grep = "grep -v " + QUOTE + '^{"ts"' + QUOTE
    return ("!python run_pipeline.py" + extra + ' > /tmp/etl_out.txt 2> /tmp/etl_err.txt; echo "exit code: $?"; '
            "cat /tmp/etl_out.txt; " + grep + " /tmp/etl_err.txt")


def build() -> str:
    """Return the notebook as JSON text."""
    readme_full = (ROOT / "README.md").read_text(encoding="utf-8")
    readme_body = readme_full[readme_full.index(NL + "# Mini ETL Framework" + NL) + 1:]   # from the second heading
    files = project_files()
    counter = [0]

    def cell(kind: str, text: str) -> dict:
        counter[0] += 1
        entry = {"cell_type": kind, "id": hashlib.sha1(f"{counter[0]}:{text[:40]}".encode()).hexdigest()[:8],
                 "metadata": {}, "source": text.splitlines(True)}
        if kind == "code":
            entry.update({"execution_count": None, "outputs": []})
        return entry

    md = lambda text: cell("markdown", text)
    code = lambda text: cell("code", text)
    versions = ("!python -c " + '"import sys, platform, sqlite3, pandas, yaml, pytest; '
                + "; ".join(f"print({QUOTE}{label}{QUOTE}, {value})" for label, value in [
                    ("Python :", "sys.version.split()[0]"), ("Pandas :", "pandas.__version__"),
                    ("PyYAML :", "yaml.__version__"), ("Pytest :", "pytest.__version__"),
                    ("SQLite :", "sqlite3.sqlite_version"), ("OS     :", "platform.platform()")]) + '"')
    cells = [
        md(readme_body),
        md("## 1. Setup" + NL + NL + "`pip` may print dependency warnings about other packages that Colab pre-installs; they "
           "do not affect this project, whose commands all run as separate Python processes with the versions installed here."),
        code("!pip -q install pandas==3.1.1 PyYAML==6.0.3 pytest==9.2.0" + NL + versions),
        md("## 2. Project files" + NL + NL + "Each cell below writes one file, exactly as it was tested."),
        code("from pathlib import Path" + NL + NL + f"for folder in {FOLDERS!r}:" + NL
             + "    Path(folder).mkdir(parents=True, exist_ok=True)"),
    ]
    for name in files:
        text = (ROOT / name).read_text(encoding="utf-8").rstrip(NL) + NL
        assert chr(13) not in text, f"{name} has Windows line endings"
        cells.append(code(f"%%writefile {name}" + NL + text))
    cells.append(code("%%writefile README.md" + NL + readme_body.rstrip(NL) + NL))
    check = (f"import os{NL}missing = [f for f in {files + ['README.md']!r} if not os.path.exists(f)]{NL}"
             f"assert not missing, f'files missing - re-run the %%writefile cells: {{missing}}'{NL}"
             f"print('all', {len(files) + 1}, 'project files present')")
    cells += [
        code(check),
        md("## 3. Run the tests" + NL + NL + "Expected: every test passes (the README gives the number). Each test uses its own "
           "temporary folder and database."),
        code("!python -m pytest -q -p no:cacheprovider 2>&1 | tail -n 30"),
        md("## 4. Sample data: load, then reconcile with the source files and the expected answers" + NL + NL
           + "Expected: customers `41 in / 27 inserted / 12 rejected / 2 duplicates / 0 late`, orders `114 / 95 / 17 / 2 / 11`. "
             "The first line removes any old database so this section always starts clean; the JSON log lines are hidden here "
             "(they are in `logs/pipeline.log`) but any error text and the exit code are shown."),
        code("!rm -f output/warehouse.db logs/pipeline.log" + NL + run_command()),
        md("The reconciliation report: `Result: **PASS** (36 of 36 checks passed)`. Section 5 of the report compares the "
           "database with the answer key in `data/expected/`, which the generator stored separately from the input."),
        code("!python run_report.py --input-dir data/sample --expected-dir data/expected"),
        md("## 5. Rerun the same input: nothing may change" + NL + NL + "Expected: `rows_inserted 0`; customers "
           "`rows_already_loaded 27`, orders `rows_already_loaded 95`; the report still passes."),
        code(run_command()),
        code("!python run_report.py --input-dir data/sample --expected-dir data/expected | head -n 5"),
        md("## 6. SQL: reconciliation checks and sample queries"),
        code(SQL_CELL),
        md("## 7. Larger dataset: 20,000 customers and 100,000 orders (about 265,000 rows)" + NL + NL
           + "The generator writes the input and, separately, the expected answers. On Colab this takes roughly a minute."),
        code("!python -m generator.generate_data --customers 20000 --orders 100000 --out-dir data/large "
             "--expected-dir data/large/expected"),
        code("!rm -f output/large.db" + NL + run_command(" --input-dir data/large --db output/large.db --log-file logs/large.log")),
        code("!python run_report.py --db output/large.db --input-dir data/large --expected-dir data/large/expected "
             "--report-file reports/reconciliation_report_large.md | head -n 8"),
        md("## 8. Performance: where the time goes and one measured optimization" + NL + NL
           + "Runs the pipeline on a fresh 100,000-order dataset, 3 repeats of the code before and after the optimization "
             "(alternating), a scaling run and a profile; takes a few minutes. The report is printed and saved to "
             "`reports/performance_report.md`. Timings depend on the machine, so Colab's numbers will differ from the ones "
             "in the README."),
        code("!python run_benchmark.py --repeats 3"),
        md("## 9. Package the results" + NL + NL + "Creates `etl_project.zip` with all the code, tests, SQL, sample data and reports."),
        code(ZIP_CELL.replace("PACKAGED_LIST", repr(PACKAGED))),
        code(DOWNLOAD_CELL),
    ]
    notebook = {"cells": cells,
                "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                             "language_info": {"name": "python"}, "colab": {"provenance": []}},
                "nbformat": 4, "nbformat_minor": 5}
    return json.dumps(notebook, indent=1, ensure_ascii=False)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the Colab notebook from the project files.")
    parser.add_argument("--check", action="store_true", help="only check that the notebook on disk is up to date")
    args = parser.parse_args()
    text = build()
    if args.check:
        # Compare the content, not the formatting: an editor that re-saves the notebook may reorder keys.
        current = json.loads(NOTEBOOK.read_text(encoding="utf-8")) if NOTEBOOK.exists() else None
        if current == json.loads(text):
            print(f"{NOTEBOOK.name} is up to date")
            return 0
        print(f"{NOTEBOOK.name} is out of date or missing: run python build_notebook.py", file=sys.stderr)
        return 1
    NOTEBOOK.write_text(text, encoding="utf-8", newline="\n")
    print(f"wrote {NOTEBOOK.name}: {len(project_files()) + 1} files embedded (including README.md)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
