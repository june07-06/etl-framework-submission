"""Command-line reconciliation report.

Examples:
    python run_report.py                                              # default database, no source/expected comparison
    python run_report.py --input-dir data/sample --expected-dir data/expected
Exit code: 0 = every check passed, 1 = at least one check failed, 2 = the report could not be produced.
"""
from __future__ import annotations

import argparse
import sqlite3
import sys

from etl.config_loader import PROJECT_ROOT, load_dataset_config, load_pipeline_config, resolve_path
from etl.errors import ConfigError
from etl.reconcile import ReportError, build_report, render_markdown


def _display_path(path) -> str:
    """Show the database path relative to the project (keeps personal folder names out of saved reports)."""
    try:
        return path.relative_to(PROJECT_ROOT).as_posix()
    except ValueError:
        return path.name


def main() -> int:
    parser = argparse.ArgumentParser(description="Reconcile the target database with the source and the run log.")
    parser.add_argument("--config", default="config/pipeline.yaml", help="pipeline config file")
    parser.add_argument("--db", help="SQLite database (overrides config)")
    parser.add_argument("--input-dir", help="folder with the source CSV files, to re-count source rows")
    parser.add_argument("--expected-dir", help="folder with expected_summary.json etc., to compare with expected answers")
    parser.add_argument("--report-file", help="where to save the Markdown report (default: reports/reconciliation_report.md)")
    args = parser.parse_args()
    try:
        pipeline = load_pipeline_config(args.config)
        datasets = [load_dataset_config(p) for p in pipeline["datasets"]]
        database = resolve_path(args.db) if args.db else pipeline["database_path"]
        if not database.exists():
            raise ReportError(f"database not found: {database} (run the pipeline first)")
        report_file = resolve_path(args.report_file) if args.report_file else pipeline["reports_dir"] / "reconciliation_report.md"
        connection = sqlite3.connect(f"{database.as_uri()}?mode=ro", uri=True)      # read-only
        try:
            report = build_report(
                connection, datasets, database=_display_path(database),
                input_dir=resolve_path(args.input_dir) if args.input_dir else None,
                expected_dir=resolve_path(args.expected_dir) if args.expected_dir else None)
        finally:
            connection.close()
    except (ConfigError, ReportError, FileNotFoundError, sqlite3.DatabaseError) as exc:
        print(f"REPORT ERROR: {exc}", file=sys.stderr)
        return 2
    text = render_markdown(report)
    report_file.parent.mkdir(parents=True, exist_ok=True)
    report_file.write_text(text, encoding="utf-8")
    print(text)
    print(f"report saved to {report_file}")
    return 0 if report.passed else 1


if __name__ == "__main__":
    sys.exit(main())
