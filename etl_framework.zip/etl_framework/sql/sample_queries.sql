-- Sample queries for the customers + orders warehouse (SQLite).
-- Run one at a time in any SQLite tool, or all of them:  sqlite3 -header -column output/warehouse.db < sql/sample_queries.sql
-- Money is stored as whole cents (order_amount_cents); divide by 100.0 to show it as a currency amount.

-- Q1. Orders by their CURRENT status, with total value.
select status, count(*) as orders, sum(order_amount_cents) / 100.0 as total_amount
from orders_current
group by status
order by orders desc;

-- Q2. Delivered revenue per customer country (joins the child to its parent).
select c.country_code, count(*) as delivered_orders, sum(o.order_amount_cents) / 100.0 as revenue
from orders_current o
join customers_current c on c.customer_id = o.customer_id
where o.status = 'delivered'
group by c.country_code
order by revenue desc;

-- Q3. Top 5 customers by order value (cancelled orders excluded).
select c.customer_id, c.full_name, count(*) as orders, sum(o.order_amount_cents) / 100.0 as total_amount
from orders_current o
join customers_current c on c.customer_id = o.customer_id
where o.status != 'cancelled'
group by c.customer_id, c.full_name
order by total_amount desc
limit 5;

-- Q4. Order lifecycle from history, with the time window each version was the latest one.
select order_id, status, updated_at as valid_from,
       lead(updated_at) over (partition by order_id order by updated_at) as valid_to
from orders_history
order by order_id, updated_at
limit 20;

-- Q5. Customers whose details changed (more than one stored version).
select customer_id, count(*) as versions, min(updated_at) as first_version, max(updated_at) as latest_version
from customers_history
group by customer_id
having count(*) > 1
order by versions desc, customer_id;

-- Q6. Superseded versions: history rows that are no longer the current row (includes late arrivals).
select h.order_id, h.status as old_status, h.updated_at, c.status as current_status, c.updated_at as current_version
from orders_history h
join orders_current c on c.order_id = h.order_id and c.updated_at != h.updated_at
order by h.order_id, h.updated_at
limit 20;

-- Q7. Rejected rows by reason: what is wrong with the source data, most common first.
select dataset, reject_reasons, count(*) as rows
from rejected_records
group by dataset, reject_reasons
order by rows desc, dataset, reject_reasons;

-- Q8. Rejects still waiting to be fixed, with the original row so it can be corrected and replayed.
select dataset, source_file, row_number, reject_reasons, raw_record
from rejected_records
where resolved_run_id is null
order by dataset, row_number
limit 10;

-- Q9. Rejects that a later rerun resolved (for example orders whose customer arrived later).
select dataset, source_file, row_number, reject_reasons, first_seen_run_id, resolved_run_id
from rejected_records
where resolved_run_id is not null;

-- Q10. Run history: counts and whether the run reconciles.
select substr(run_id, 1, 8) as run, dataset, status, rows_in, rows_inserted, rows_already_loaded, rows_rejected,
       duplicates_dropped, late_records,
       case when rows_in = rows_inserted + rows_already_loaded + rows_rejected + duplicates_dropped
            then 'OK' else 'MISMATCH' end as reconciles
from pipeline_runs
order by started_at, dataset;

-- Q11. Data-quality trend: share of input rows rejected in each run.
select substr(run_id, 1, 8) as run, dataset, rows_in, rows_rejected,
       round(100.0 * rows_rejected / nullif(rows_in, 0), 2) as reject_percent
from pipeline_runs
where status = 'SUCCESS'
order by started_at, dataset;

-- Q12. Where the time goes in each run (seconds per stage) and the throughput.
select substr(run_id, 1, 8) as run, dataset, extract_seconds, validate_seconds, transform_seconds, load_seconds,
       duration_seconds, round(rows_in / nullif(duration_seconds, 0)) as rows_per_second
from pipeline_runs
where status = 'SUCCESS'
order by started_at, dataset;

-- Q13. Lineage: trace loaded orders back to the exact source file and line.
select order_id, source_file, source_row_number, run_id
from orders_current
order by order_id
limit 5;

-- Q14. Failed or unfinished runs and why.
select run_id, dataset, status, failure_reason, started_at
from pipeline_runs
where status != 'SUCCESS'
order by started_at;
