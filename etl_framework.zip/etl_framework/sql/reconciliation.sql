-- Reconciliation queries for the customers + orders warehouse (SQLite).
-- Every query returns one row: check_name, violations. 0 violations = PASS.
-- Run them all with:  sqlite3 output/warehouse.db < sql/reconciliation.sql
-- (python run_report.py runs the same kinds of checks, generated from the config, and writes a report.)

-- 1. Every successful run accounts for every input row.
select 'run_counts_add_up' as check_name, count(*) as violations
from pipeline_runs
where status = 'SUCCESS'
  and rows_in != rows_inserted + rows_already_loaded + rows_rejected + duplicates_dropped;

-- 2. Primary keys are unique (history: key + version, current: key).
select 'customers_history_key_unique', count(*) from (
  select 1 from customers_history group by customer_id, updated_at having count(*) > 1);
select 'customers_current_key_unique', count(*) from (
  select 1 from customers_current group by customer_id having count(*) > 1);
select 'orders_history_key_unique', count(*) from (
  select 1 from orders_history group by order_id, updated_at having count(*) > 1);
select 'orders_current_key_unique', count(*) from (
  select 1 from orders_current group by order_id having count(*) > 1);

-- 3. "Current" is exactly the newest version found in history.
select 'customers_current_is_newest_history_row', count(*) from customers_current c
where not exists (
  select 1 from customers_history h
  where h.customer_id = c.customer_id and h.record_hash = c.record_hash
    and h.updated_at = (select max(x.updated_at) from customers_history x where x.customer_id = c.customer_id));
select 'orders_current_is_newest_history_row', count(*) from orders_current c
where not exists (
  select 1 from orders_history h
  where h.order_id = c.order_id and h.record_hash = c.record_hash
    and h.updated_at = (select max(x.updated_at) from orders_history x where x.order_id = c.order_id));

-- 4. Every history key has a current row.
select 'customers_history_has_current', count(*) from (select distinct customer_id from customers_history) h
where not exists (select 1 from customers_current c where c.customer_id = h.customer_id);
select 'orders_history_has_current', count(*) from (select distinct order_id from orders_history) h
where not exists (select 1 from orders_current c where c.order_id = h.order_id);

-- 5. Referential integrity: no order points to a customer that does not exist.
select 'orders_reference_existing_customer', count(*) from orders_history o
where not exists (select 1 from customers_current c where c.customer_id = o.customer_id);

-- 6. History holds exactly the rows the runs say they inserted (nothing lost, nothing added by hand).
select 'customers_history_equals_inserted',
       abs((select count(*) from customers_history)
           - (select coalesce(sum(rows_inserted), 0) from pipeline_runs where dataset = 'customers' and status = 'SUCCESS'));
select 'orders_history_equals_inserted',
       abs((select count(*) from orders_history)
           - (select coalesce(sum(rows_inserted), 0) from pipeline_runs where dataset = 'orders' and status = 'SUCCESS'));

-- 7. Key aggregate: total order amount (cents) in current = total over the newest history versions.
select 'orders_amount_cents_total',
       abs((select coalesce(sum(order_amount_cents), 0) from orders_current)
           - (select coalesce(sum(h.order_amount_cents), 0) from orders_history h
              where h.updated_at = (select max(x.updated_at) from orders_history x where x.order_id = h.order_id)));

-- 8. Every reject can be traced: reason, source file, line number and the original row as JSON.
select 'rejects_traceable', count(*) from rejected_records
where reject_reasons = '' or source_file = '' or row_number < 2 or not json_valid(raw_record);
