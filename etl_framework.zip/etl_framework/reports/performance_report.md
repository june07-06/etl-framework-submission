# Performance report

Generated: 2026-11-14T11:30:40Z  
Machine: Windows-11-10.0.26300-SP0, 12 CPUs; Python 3.14.0, pandas 3.1.1, SQLite 3.50.4  
Data: seed 42, 24,600 customer rows + 240,373 order rows (20,000 customers, 100,000 orders, with bad rows, duplicates and late versions)  
Method: 5 repeats per variant, alternating order, empty database each run, medians shown (see the notes at the end for what these numbers can and cannot tell you).

## 1. Where the time goes (after the optimization)

**orders** (240,373 rows in)

| stage | median seconds | fastest-slowest | share of dataset time |
|---|---|---|---|
| extract | 0.51 | 0.49-0.56 | 5% |
| validate | 2.45 | 2.29-2.58 | 25% |
| transform | 2.56 | 2.47-2.65 | 26% |
| load | 4.33 | 4.01-4.66 | 44% |
| **total** | **9.78** | 9.44-10.22 | 24,583 rows/s |

**customers** (24,600 rows in)

| stage | median seconds | fastest-slowest | share of dataset time |
|---|---|---|---|
| extract | 0.04 | 0.04-0.05 | 5% |
| validate | 0.17 | 0.16-0.28 | 21% |
| transform | 0.13 | 0.12-0.14 | 15% |
| load | 0.44 | 0.43-0.56 | 54% |
| **total** | **0.83** | 0.78-0.91 | 29,642 rows/s |

Whole run (both datasets, wall clock): **10.87 s**, 24,378 rows per second.

## 2. The optimization: loop over plain lists instead of pandas string columns

**What the measurement showed.** Load is the largest stage, then transform and validate (section 1). A profile of the unoptimized code shows millions of calls into pandas' per-value string access, coming from loops that iterate a pandas string column directly (`transform._hash_rows` and the decimal handling). Converting each column to a list once (`etl.transform._plain`) returns exactly the same values with far fewer slow calls.

Profile of one **before** run (the functions that use the most CPU time themselves; profiling slows the code, so read the proportions, not the seconds):

| function | own seconds | cumulative seconds | calls |
|---|---|---|---|
| `<method 'executemany' of 'sqlite3.Connection' objects>` | 1.88 | 1.88 | 10 |
| `arrays/_mixins.py:__getitem__` | 1.22 | 1.42 | 2,553,363 |
| `<method 'fullmatch' of 're.Pattern' objects>` | 0.91 | 0.91 | 2,056,970 |
| `etl/load.py:_py_rows` | 0.82 | 1.13 | 6 |
| `arrays/base.py:__iter__` | 0.60 | 2.01 | 2,553,124 |
| `etl/transform.py:_hash_rows` | 0.54 | 2.57 | 2 |
| `etl/transform.py:_derive` | 0.53 | 1.13 | 3 |
| `etl/extract.py:extract_csv` | 0.53 | 0.85 | 2 |
| `strings/object_array.py:<lambda>` | 0.51 | 1.43 | 2,056,970 |
| `arrays/datetimes.py:_format_native_types` | 0.51 | 0.51 | 4 |

Slow per-value pandas accesses (`__getitem__` calls): **2,553,363 before, 523,247 after**.

**Before vs after** (5 repeats each, orders dataset, median seconds; change = after minus before, so a negative number is faster):

| stage | before | after | change (s) | change | speed-up |
|---|---|---|---|---|---|
| extract | 0.49 | 0.51 | +0.02 | +4% | 0.96x |
| validate | 2.56 | 2.45 | -0.11 | -4% | 1.05x |
| transform | 2.94 | 2.56 | -0.38 | -13% | 1.15x |
| load | 4.47 | 4.33 | -0.14 | -3% | 1.03x |
| **orders total** | **10.38** | **9.78** | -0.61 | -6% | **1.06x** |
| **whole run (wall clock)** | **11.42** | **10.87** | -0.55 | -5% | **1.05x** |

Whole-run range: before 10.99-11.70 s, after 10.43-11.33 s. Ranges overlap when one repeat is slow, so each repeat's before and after (run back to back) are also compared as pairs: after was faster in 4 of 5 repeats (median saving 0.66 s) for the whole run and faster in 5 of 5 repeats (median saving 0.41 s) for the transform stage.

**Output unchanged:** **yes**. A content fingerprint (ignoring run ids and timestamps) of every table is identical for all measured runs of both variants: `customers_history` 9320028594bf4a42, `customers_current` 8f69b3e9f8fa738d, `orders_history` d4e3c67011f91271, `orders_current` bbd5d9b8cd494805, `rejected_records` 0cf79c536805a290.

## 3. How it scales (optimized pipeline)

| orders (distinct) | rows read | seconds | rows per second |
|---|---|---|---|
| 5,000 | 13,140 | 0.62 | 21,182 |
| 25,000 | 66,124 | 2.86 | 23,153 |
| 50,000 | 132,418 | 5.46 | 24,270 |
| 100,000 | 264,973 | 10.87 | 24,378 |

Throughput at the largest size is 100% of the best measured (24,378 rows/s). A big drop would suggest a step whose cost grows faster than the data; small inputs are slower per row because fixed start-up costs are spread over few rows. The smaller sizes are single runs and the largest is the median of the repeats above.

## Notes and limits

- Timings vary from run to run (the repeats above show by how much); a difference smaller than that range is not evidence of an improvement.
- The gain here is moderate: pandas' own string handling and SQLite inserts dominate the rest of the time.
- Memory use was not measured.
- Not tried: installing `pyarrow` (pandas then uses much faster string storage). It is an extra dependency, so it is a decision for the project owner; Google Colab already includes it, so results there may differ.
- Other candidates were measured separately during development (this runner does not repeat them) and not adopted, because each changed the total by only 2-4%, close to the run-to-run noise: compiling regular expressions once and applying them to plain values, building SQLite rows with `to_numpy`, and raising SQLite's page cache.
