# Reconciliation report

Generated: 2026-11-14T11:07:44Z  
Database: `output/warehouse.db`  
Result: **PASS** (36 of 36 checks passed)

## 1. Run reconciliation (latest successful run of each dataset)

`rows_in = rows_inserted + rows_already_loaded + rows_rejected + duplicates_dropped`

| dataset | run | rows_in | inserted | already_loaded | rejected | duplicates_dropped | late (kept in history) | sum of parts = rows_in |
|---|---|---|---|---|---|---|---|---|
| customers | fc09477c | 41 | 27 | 0 | 12 | 2 | 0 | 41 = 41: PASS |
| orders | fc09477c | 114 | 95 | 0 | 17 | 2 | 11 | 114 = 114: PASS |

## 2. Where the rows went: rejects by reason (latest run)

| dataset | reject reason | rows |
|---|---|---|
| customers | CONFLICTING_DUPLICATE:customer_id,updated_at | 2 |
| customers | FUTURE_TIMESTAMP:signup_date | 1 |
| customers | INVALID_ALLOWED_VALUE:country_code | 1 |
| customers | INVALID_FORMAT:customer_id | 1 |
| customers | INVALID_FORMAT:email | 1 |
| customers | INVALID_TYPE:signup_date | 1 |
| customers | INVALID_TYPE:updated_at | 1 |
| customers | MALFORMED_ROW | 1 |
| customers | MISSING_REQUIRED_FIELD:email | 1 |
| customers | MISSING_REQUIRED_FIELD:email; INVALID_ALLOWED_VALUE:country_code | 1 |
| customers | MISSING_REQUIRED_FIELD:full_name | 1 |
| orders | CONFLICTING_DUPLICATE:order_id,updated_at | 2 |
| orders | INVALID_TYPE:quantity | 2 |
| orders | OUT_OF_RANGE:quantity | 2 |
| orders | OUT_OF_RANGE:unit_price | 2 |
| orders | FUTURE_TIMESTAMP:order_ts | 1 |
| orders | INVALID_ALLOWED_VALUE:currency | 1 |
| orders | INVALID_ALLOWED_VALUE:status | 1 |
| orders | INVALID_ALLOWED_VALUE:status; OUT_OF_RANGE:unit_price | 1 |
| orders | INVALID_FORMAT:order_id | 1 |
| orders | INVALID_REFERENCE:customer_id | 1 |
| orders | MALFORMED_ROW | 1 |
| orders | MISSING_REQUIRED_FIELD:customer_id | 1 |
| orders | MISSING_REQUIRED_FIELD:order_ts | 1 |

## 3. Integrity checks

| dataset | check | violations | result | what it proves |
|---|---|---|---|---|
| customers | latest_run_succeeded | 0 | PASS | the most recent run of this dataset finished with status SUCCESS |
| customers | run_counts_add_up | 0 | PASS | in every successful run rows_in = inserted + already loaded + rejected + duplicates |
| customers | history_key_unique | 0 | PASS | primary key (natural key + version) is unique in the history table |
| customers | current_key_unique | 0 | PASS | natural key is unique in the current table |
| customers | current_has_history | 0 | PASS | every current row has a history row |
| customers | history_has_current | 0 | PASS | every history key has a current row |
| customers | current_is_latest_history_row | 0 | PASS | each current row is identical to the newest version in history |
| customers | history_equals_inserted | 0 | PASS | history rows = sum of rows_inserted over successful runs |
| customers | lineage_complete | 0 | PASS | every history row points to a successful run of this dataset |
| orders | latest_run_succeeded | 0 | PASS | the most recent run of this dataset finished with status SUCCESS |
| orders | run_counts_add_up | 0 | PASS | in every successful run rows_in = inserted + already loaded + rejected + duplicates |
| orders | history_key_unique | 0 | PASS | primary key (natural key + version) is unique in the history table |
| orders | current_key_unique | 0 | PASS | natural key is unique in the current table |
| orders | current_has_history | 0 | PASS | every current row has a history row |
| orders | history_has_current | 0 | PASS | every history key has a current row |
| orders | current_is_latest_history_row | 0 | PASS | each current row is identical to the newest version in history |
| orders | history_equals_inserted | 0 | PASS | history rows = sum of rows_inserted over successful runs |
| orders | lineage_complete | 0 | PASS | every history row points to a successful run of this dataset |
| orders | reference_customer_id | 0 | PASS | every orders_history.customer_id exists in customers_current.customer_id (referential integrity) |
| orders | aggregate_order_amount_cents | 0 | PASS | sum(order_amount_cents) in current = sum over the newest history versions |
| all | rejects_traceable | 0 | PASS | every reject has a reason, source file, line number (>= 2) and the original row as JSON |
| all | reject_reason_codes_known | 0 | PASS | every reject reason uses a documented reason code |
| customers | rejects_cover_latest_run | 0 | PASS | rejects seen in the latest run = rows_rejected of that run |
| orders | rejects_cover_latest_run | 0 | PASS | rejects seen in the latest run = rows_rejected of that run |

## 4. Source-to-target

| dataset | check | violations | result | what it proves |
|---|---|---|---|---|
| customers | source_rows_equal_rows_in | 0 | PASS | source file row count (counted independently) = rows_in of the latest run |
| orders | source_rows_equal_rows_in | 0 | PASS | source file row count (counted independently) = rows_in of the latest run |

## 5. Comparison with the expected answers

| dataset | check | violations | result | what it proves |
|---|---|---|---|---|
| customers | expected_run_counts | 0 | PASS | run counts equal expected_summary.json (in, inserted, rejected, duplicates, late) |
| customers | expected_table_rows | 0 | PASS | history and current row counts equal expected_summary.json |
| customers | expected_rejects | 0 | PASS | rejected rows and their reasons equal expected_rejects.csv (row number and reason) |
| customers | expected_current_rows | 0 | PASS | current rows equal expected_current_customers.csv (the latest version of every record) |
| orders | expected_run_counts | 0 | PASS | run counts equal expected_summary.json (in, inserted, rejected, duplicates, late) |
| orders | expected_table_rows | 0 | PASS | history and current row counts equal expected_summary.json |
| orders | expected_rejects | 0 | PASS | rejected rows and their reasons equal expected_rejects.csv (row number and reason) |
| orders | expected_current_rows | 0 | PASS | current rows equal expected_current_orders.csv (the latest version of every record) |
| orders | expected_history_order_amount_cents_sum | 0 | PASS | sum(order_amount_cents) in orders_history equals the expected total |
| orders | expected_current_order_amount_cents_sum | 0 | PASS | sum(order_amount_cents) in orders_current equals the expected total |
