"""Generate synthetic customers and orders CSV files with a fixed random seed.

Two kinds of files are written, in two different folders so the answer key never
sits next to the input:
  * INPUT files     (--out-dir)      customers.csv, orders.csv
  * EXPECTED files  (--expected-dir) which rows must be rejected and why, expected
                                     counts and totals, and the expected "current" rows

The generator knows what it planted, so the expected answers are computed here,
independently of the pipeline. Same seed + same options = identical files.

Examples:
    python -m generator.generate_data                       # small sample -> data/sample, data/expected
    python -m generator.generate_data --customers 20000 --orders 100000 \\
        --out-dir data/large --expected-dir data/large/expected
"""
from __future__ import annotations

import argparse
import csv
import json
import random
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DEFAULT_SEED = 42
# All valid timestamps stay before 2025-08-01, so a run on any later date never sees them as 'future'.
LATE_RATE = 0.2             # share of multi-version records whose older versions arrive later in the file
DUPLICATE_RATE = 0.02       # exact duplicate rows, as a share of records (at least 2)
CUSTOMER_UPDATE_RATE = 0.15  # share of customers that get a second (changed) version
NOISE_RATE = 0.05           # share of valid rows with harmless noise (padded name, upper-case email)

COUNTRIES = ["IN", "US", "GB", "AE", "SG"]
CURRENCIES = ["INR", "USD"]
FIRST_NAMES = ["Asha", "John", "Meera", "Omar", "Li", "Priya", "Ravi", "Sara", "Tom", "Uma", "Vik", "Nina",
               "Carlos", "Fatima", "Hiro", "Ivan", "Julia", "Kofi", "Lena", "Mateo"]
LAST_NAMES = ["Rao", "Smith", "Nair", "Khan", "Wei", "Das", "Patel", "Lee", "Brown", "Iyer", "Shah", "Gupta",
              "Silva", "Ali", "Sato", "Petrov", "Meyer", "Mensah", "Berg", "Lopez"]
EMAIL_DOMAINS = ["example.com", "mail.example.org", "corp.example.net"]
ORDER_STATUS_PATHS = [["placed"], ["placed", "shipped"], ["placed", "shipped", "delivered"], ["placed", "cancelled"]]
ORDER_STATUS_WEIGHTS = [2, 2, 5, 1]
# (quantity, unit price in cents): exactly on the limits of the order rules, so they must be ACCEPTED
BOUNDARY_ORDERS = [(1, 0), (1000, 10_000_000), (1, 1), (1000, 0)]

CUSTOMER_HEADER = ["customer_id", "full_name", "email", "country_code", "signup_date", "updated_at"]
ORDER_HEADER = ["order_id", "customer_id", "order_ts", "status", "quantity", "unit_price", "currency", "updated_at"]

CUSTOMER_DEFECTS = ["missing_email", "missing_full_name", "invalid_email_format", "invalid_customer_id_format",
                    "invalid_country_code", "future_signup_date", "invalid_signup_date", "invalid_updated_at",
                    "multiple_defects", "malformed_row", "conflicting_duplicate"]
ORDER_DEFECTS = ["quantity_zero", "quantity_above_max", "negative_price", "price_above_max",
                 "quantity_not_a_number", "quantity_fractional", "invalid_status", "invalid_currency",
                 "missing_order_ts", "missing_customer_id", "future_order_ts", "invalid_order_id_format",
                 "invalid_reference", "multiple_defects", "malformed_row", "conflicting_duplicate"]


@dataclass
class Row:
    """One line of an input file plus what the generator knows about it."""

    fields: list[str]
    kind: str                      # valid | bad | duplicate_exact | conflict
    reasons: str = ""              # expected reject_reasons text (for bad and conflict rows)
    defect: str = ""               # human-readable name of the planted defect
    key: tuple = ()                # natural key (valid rows)
    version: datetime | None = None
    canon: dict[str, Any] = field(default_factory=dict)   # expected cleaned values (valid rows)
    cents: int | None = None       # order amount in cents (valid order rows)
    after: int | None = None       # a duplicate must be placed after base row number `after`


# ---------- small helpers ----------

def iso_z(moment: datetime) -> str:
    return moment.strftime("%Y-%m-%dT%H:%M:%SZ")


def format_timestamp(moment: datetime, rng: random.Random) -> str:
    """Mostly 'Z' timestamps, sometimes '+00:00' or '+05:30' (same instant, different text)."""
    roll = rng.random()
    if roll < 0.90:
        return iso_z(moment)
    if roll < 0.95:
        return moment.strftime("%Y-%m-%dT%H:%M:%S") + "+00:00"
    return (moment + timedelta(hours=5, minutes=30)).strftime("%Y-%m-%dT%H:%M:%S") + "+05:30"


def price_text(cents: int) -> str:
    return f"{cents // 100}.{cents % 100:02d}"


def random_moment(rng: random.Random, start: datetime, days: int) -> datetime:
    return start + timedelta(days=rng.randint(0, days), seconds=rng.randint(0, 86399))


def merge_rows(base: list[Row], extras: list[Row], rng: random.Random) -> list[Row]:
    """Place each extra row at a random position; a duplicate always lands after its original."""
    slots = []
    for seq, row in enumerate(extras):
        low = row.after + 1 if row.after is not None else 0
        slots.append((rng.randint(low, len(base)), seq, row))
    slots.sort(key=lambda slot: (slot[0], slot[1]))
    merged: list[Row] = []
    j = 0
    for index, row in enumerate(base):
        while j < len(slots) and slots[j][0] <= index:
            merged.append(slots[j][2])
            j += 1
        merged.append(row)
    merged.extend(slot[2] for slot in slots[j:])
    return merged


def duplicate_rows(base: list[Row], rng: random.Random) -> list[Row]:
    """Exact copies of some valid rows (same text), to be dropped as duplicates."""
    count = min(len(base), max(2, round(DUPLICATE_RATE * len(base))))
    return [Row(fields=list(base[i].fields), kind="duplicate_exact", defect="exact_duplicate", after=i)
            for i in sorted(rng.sample(range(len(base)), count))]


# ---------- customers ----------

def _person(rng: random.Random, number: int) -> tuple[str, str, str]:
    first, last = rng.choice(FIRST_NAMES), rng.choice(LAST_NAMES)
    return first, last, f"{first}.{last}{number}@{rng.choice(EMAIL_DOMAINS)}".lower()


def build_customers(count: int, bad_rate: float, rng: random.Random) -> tuple[list[Row], list[str]]:
    """Return (rows in file order, ids of customers that will NOT be loaded)."""
    keyed: list[tuple[int, int, Row]] = []
    epoch = datetime(2022, 1, 1, tzinfo=timezone.utc)
    for i in range(1, count + 1):
        cid = f"C{i:06d}"
        first, last, email = _person(rng, i)
        signup = random_moment(rng, epoch, 1094)
        versions = [(f"{first} {last}", rng.choice(COUNTRIES), signup)]
        if rng.random() < CUSTOMER_UPDATE_RATE:
            later = signup + timedelta(days=rng.randint(30, 200), seconds=rng.randint(1, 86399))
            versions.append((f"{first} {rng.choice(LAST_NAMES)}", rng.choice(COUNTRIES), later))
        late = len(versions) > 1 and rng.random() < LATE_RATE
        for v, (name, country, moment) in enumerate(versions):
            shown_name = f"  {name} " if rng.random() < NOISE_RATE else name
            shown_email = email.upper() if rng.random() < NOISE_RATE else email
            fields = [cid, shown_name, shown_email, country, signup.date().isoformat(), format_timestamp(moment, rng)]
            row = Row(fields=fields, kind="valid", key=(cid,), version=moment,
                      canon={"customer_id": cid, "full_name": name, "email": email, "country_code": country,
                             "updated_at": iso_z(moment)})
            shift = rng.randint(1, 20) if late and v < len(versions) - 1 else 0
            keyed.append((i + shift, len(keyed), row))
    base = [row for _, _, row in sorted(keyed, key=lambda item: (item[0], item[1]))]

    extras, rejected_ids = _customer_defect_rows(count, bad_rate, rng)
    extras += duplicate_rows(base, rng)
    return merge_rows(base, extras, rng), rejected_ids


def _customer_defect_rows(count: int, bad_rate: float, rng: random.Random) -> tuple[list[Row], list[str]]:
    items = max(len(CUSTOMER_DEFECTS), round(bad_rate * count))
    extras: list[Row] = []
    rejected_ids: list[str] = []
    for n in range(items):
        defect = CUSTOMER_DEFECTS[n % len(CUSTOMER_DEFECTS)]
        cid = f"C{count + 1 + n:06d}"
        first, last, email = _person(rng, count + 1 + n)
        moment = random_moment(rng, datetime(2022, 1, 1, tzinfo=timezone.utc), 1094)
        f = [cid, f"{first} {last}", email, rng.choice(COUNTRIES), moment.date().isoformat(), iso_z(moment)]
        reasons = {
            "missing_email": "MISSING_REQUIRED_FIELD:email",
            "missing_full_name": "MISSING_REQUIRED_FIELD:full_name",
            "invalid_email_format": "INVALID_FORMAT:email",
            "invalid_customer_id_format": "INVALID_FORMAT:customer_id",
            "invalid_country_code": "INVALID_ALLOWED_VALUE:country_code",
            "future_signup_date": "FUTURE_TIMESTAMP:signup_date",
            "invalid_signup_date": "INVALID_TYPE:signup_date",
            "invalid_updated_at": "INVALID_TYPE:updated_at",
            "multiple_defects": "MISSING_REQUIRED_FIELD:email; INVALID_ALLOWED_VALUE:country_code",
            "malformed_row": "MALFORMED_ROW",
            "conflicting_duplicate": "CONFLICTING_DUPLICATE:customer_id,updated_at",
        }[defect]
        if defect == "missing_email":
            f[2] = ""
        elif defect == "missing_full_name":
            f[1] = ""
        elif defect == "invalid_email_format":
            f[2] = "no-at-sign.example.com"
        elif defect == "invalid_customer_id_format":
            f[0] = f"CUST-{n}"
        elif defect == "invalid_country_code":
            f[3] = rng.choice(["XX", "ZZ", "in"])          # 'in' = wrong case, which must also be rejected
        elif defect == "future_signup_date":
            f[4] = "2999-01-01"
        elif defect == "invalid_signup_date":
            f[4] = rng.choice(["2024-02-30", "2024-13-01", "31/12/2024"])
        elif defect == "invalid_updated_at":
            f[5] = rng.choice(["not-a-timestamp", "2024-99-99T00:00:00Z", "yesterday"])
        elif defect == "multiple_defects":
            f[2], f[3] = "", "XX"
        elif defect == "malformed_row":
            f = f[:-1] if rng.random() < 0.5 else f + ["unexpected_extra_field"]
        if defect == "conflicting_duplicate":
            second = list(f)
            second[1] = f"{first} {last} (changed)"          # same key and version, different content
            extras += [Row(fields=f, kind="conflict", reasons=reasons, defect=defect),
                       Row(fields=second, kind="conflict", reasons=reasons, defect=defect)]
        else:
            extras.append(Row(fields=f, kind="bad", reasons=reasons, defect=defect))
        if defect != "invalid_customer_id_format":
            rejected_ids.append(cid)
    return extras, rejected_ids


# ---------- orders ----------

def build_orders(count: int, customers: int, bad_rate: float, orphan_ids: list[str],
                 rng: random.Random) -> list[Row]:
    keyed: list[tuple[int, int, Row]] = []
    epoch = datetime(2024, 1, 1, tzinfo=timezone.utc)
    for i in range(1, count + 1):
        oid, cust = f"O{i:08d}", f"C{rng.randint(1, customers):06d}"
        if i <= len(BOUNDARY_ORDERS):
            quantity, price_cents = BOUNDARY_ORDERS[i - 1]
        elif rng.random() < 0.01:
            quantity, price_cents = rng.choice(BOUNDARY_ORDERS)
        else:
            quantity, price_cents = rng.randint(1, 20), rng.randint(100, 200_000)
        currency = rng.choice(CURRENCIES)
        order_ts = random_moment(rng, epoch, 546)
        statuses = rng.choices(ORDER_STATUS_PATHS, ORDER_STATUS_WEIGHTS)[0]
        late = len(statuses) > 1 and rng.random() < LATE_RATE
        moment = order_ts
        for v, status in enumerate(statuses):
            if v:
                moment = moment + timedelta(hours=rng.randint(2, 72), seconds=rng.randint(0, 3599))
            fields = [oid, cust, format_timestamp(order_ts, rng), status, str(quantity), price_text(price_cents),
                      currency, format_timestamp(moment, rng)]
            row = Row(fields=fields, kind="valid", key=(oid,), version=moment, cents=quantity * price_cents,
                      canon={"order_id": oid, "customer_id": cust, "status": status,
                             "order_amount_cents": quantity * price_cents, "updated_at": iso_z(moment)})
            shift = rng.randint(1, 50) if late and v < len(statuses) - 1 else 0
            keyed.append((i + shift, len(keyed), row))
    base = [row for _, _, row in sorted(keyed, key=lambda item: (item[0], item[1]))]

    extras = _order_defect_rows(count, customers, bad_rate, orphan_ids, rng)
    extras += duplicate_rows(base, rng)
    return merge_rows(base, extras, rng)


def _order_defect_rows(count: int, customers: int, bad_rate: float, orphan_ids: list[str],
                       rng: random.Random) -> list[Row]:
    items = max(len(ORDER_DEFECTS), round(bad_rate * count))
    extras: list[Row] = []
    for n in range(items):
        defect = ORDER_DEFECTS[n % len(ORDER_DEFECTS)]
        oid = f"O{count + 1 + n:08d}"
        moment = random_moment(rng, datetime(2024, 1, 1, tzinfo=timezone.utc), 546)
        f = [oid, f"C{rng.randint(1, customers):06d}", iso_z(moment), "placed", str(rng.randint(1, 20)),
             price_text(rng.randint(100, 200_000)), rng.choice(CURRENCIES), iso_z(moment)]
        reasons = {
            "quantity_zero": "OUT_OF_RANGE:quantity",
            "quantity_above_max": "OUT_OF_RANGE:quantity",
            "negative_price": "OUT_OF_RANGE:unit_price",
            "price_above_max": "OUT_OF_RANGE:unit_price",
            "quantity_not_a_number": "INVALID_TYPE:quantity",
            "quantity_fractional": "INVALID_TYPE:quantity",
            "invalid_status": "INVALID_ALLOWED_VALUE:status",
            "invalid_currency": "INVALID_ALLOWED_VALUE:currency",
            "missing_order_ts": "MISSING_REQUIRED_FIELD:order_ts",
            "missing_customer_id": "MISSING_REQUIRED_FIELD:customer_id",
            "future_order_ts": "FUTURE_TIMESTAMP:order_ts",
            "invalid_order_id_format": "INVALID_FORMAT:order_id",
            "invalid_reference": "INVALID_REFERENCE:customer_id",
            "multiple_defects": "INVALID_ALLOWED_VALUE:status; OUT_OF_RANGE:unit_price",
            "malformed_row": "MALFORMED_ROW",
            "conflicting_duplicate": "CONFLICTING_DUPLICATE:order_id,updated_at",
        }[defect]
        if defect == "quantity_zero":
            f[4] = "0"
        elif defect == "quantity_above_max":
            f[4] = "1001"
        elif defect == "negative_price":
            f[5] = "-0.01"
        elif defect == "price_above_max":
            f[5] = "100000.01"
        elif defect == "quantity_not_a_number":
            f[4] = "abc"
        elif defect == "quantity_fractional":
            f[4] = "2.5"
        elif defect == "invalid_status":
            f[3] = "lost"
        elif defect == "invalid_currency":
            f[6] = "EUR"
        elif defect == "missing_order_ts":
            f[2] = ""
        elif defect == "missing_customer_id":
            f[1] = ""
        elif defect == "future_order_ts":
            f[2] = "2999-01-01T00:00:00Z"
        elif defect == "invalid_order_id_format":
            f[0] = f"ORD-{n}"
        elif defect == "invalid_reference":
            f[1] = rng.choice(orphan_ids) if orphan_ids else f"C{customers + 500_000:06d}"
        elif defect == "multiple_defects":
            f[3], f[5] = "lost", "-5.00"
        elif defect == "malformed_row":
            f = f[:-1] if rng.random() < 0.5 else f + ["unexpected_extra_field"]
        if defect == "conflicting_duplicate":
            second = list(f)
            second[5] = price_text(int(round(float(f[5]) * 100)) + 100)      # same key and version, other price
            extras += [Row(fields=f, kind="conflict", reasons=reasons, defect=defect),
                       Row(fields=second, kind="conflict", reasons=reasons, defect=defect)]
        else:
            extras.append(Row(fields=f, kind="bad", reasons=reasons, defect=defect))
    return extras


# ---------- expected answers ----------

def summarize(rows: list[Row]) -> tuple[dict[str, Any], dict[tuple, Row]]:
    """Expected counts for one dataset, worked out from what was planted (not from the pipeline)."""
    valid = [r for r in rows if r.kind == "valid"]
    rejected = [r for r in rows if r.kind in ("bad", "conflict")]
    dropped = [r for r in rows if r.kind == "duplicate_exact"]
    assert len({(r.key, r.version) for r in valid}) == len(valid), "generator made a duplicate key+version"

    newest: dict[tuple, datetime] = {}
    late = 0
    current: dict[tuple, Row] = {}
    for row in valid:                      # file order = the order the pipeline reads them
        top = newest.get(row.key)
        if top is not None and row.version < top:
            late += 1                      # an older version arriving after a newer one
        if top is None or row.version > top:
            newest[row.key] = row.version
            current[row.key] = row
    summary: dict[str, Any] = {
        "rows_in": len(rows), "rows_inserted": len(valid), "rows_rejected": len(rejected),
        "duplicates_dropped": len(dropped), "late_records": late,
        "history_rows": len(valid), "current_rows": len(current),
        "rejects_by_reason": dict(sorted(Counter(r.reasons for r in rejected).items())),
    }
    assert summary["rows_in"] == (summary["rows_inserted"] + summary["rows_rejected"]
                                  + summary["duplicates_dropped"]), "expected counts do not add up"
    if valid and valid[0].cents is not None:
        summary["history_order_amount_cents_sum"] = sum(r.cents for r in valid)
        summary["current_order_amount_cents_sum"] = sum(r.cents for r in current.values())
    return summary, current


def write_input(path: Path, header: list[str], rows: list[Row]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        for row in rows:
            assert not any("\n" in value for value in row.fields)
            writer.writerow(row.fields)


def write_expected(path: Path, columns: list[str], current: dict[tuple, Row]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(columns)
        for key in sorted(current):
            writer.writerow([current[key].canon[c] for c in columns])


def resolve(path: str) -> Path:
    p = Path(path)
    return p if p.is_absolute() else PROJECT_ROOT / p


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Generate synthetic customers/orders data with labelled bad rows.")
    parser.add_argument("--customers", type=int, default=25, help="distinct valid customers (default 25)")
    parser.add_argument("--orders", type=int, default=40, help="distinct valid orders (default 40)")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED, help="random seed (default 42)")
    parser.add_argument("--bad-rate", type=float, default=0.05,
                        help="bad rows per dataset as a share of its records; every defect type is always included")
    parser.add_argument("--out-dir", default="data/sample", help="folder for customers.csv and orders.csv")
    parser.add_argument("--expected-dir", default="data/expected", help="folder for the expected-answer files")
    args = parser.parse_args(argv)
    if args.customers < 1 or args.orders < 1 or args.customers > 400_000 or not 0 <= args.bad_rate <= 1:
        parser.error("need 1 <= customers <= 400000, orders >= 1 and 0 <= bad-rate <= 1")

    customer_rows, rejected_customer_ids = build_customers(
        args.customers, args.bad_rate, random.Random(f"{args.seed}-customers"))
    order_rows = build_orders(args.orders, args.customers, args.bad_rate, rejected_customer_ids,
                              random.Random(f"{args.seed}-orders"))

    out_dir, expected_dir = resolve(args.out_dir), resolve(args.expected_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    expected_dir.mkdir(parents=True, exist_ok=True)
    write_input(out_dir / "customers.csv", CUSTOMER_HEADER, customer_rows)
    write_input(out_dir / "orders.csv", ORDER_HEADER, order_rows)

    customers_summary, customers_current = summarize(customer_rows)
    orders_summary, orders_current = summarize(order_rows)
    with open(expected_dir / "expected_rejects.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["dataset", "source_file", "row_number", "expected_reject_reasons", "defect"])
        for name, rows in (("customers", customer_rows), ("orders", order_rows)):
            for index, row in enumerate(rows):
                if row.kind in ("bad", "conflict"):
                    writer.writerow([name, f"{name}.csv", index + 2, row.reasons, row.defect])   # header is line 1
    write_expected(expected_dir / "expected_current_customers.csv",
                   ["customer_id", "full_name", "email", "country_code", "updated_at"], customers_current)
    write_expected(expected_dir / "expected_current_orders.csv",
                   ["order_id", "customer_id", "status", "order_amount_cents", "updated_at"], orders_current)
    (expected_dir / "expected_summary.json").write_text(json.dumps({
        "generator": {"seed": args.seed, "customers": args.customers, "orders": args.orders,
                      "bad_rate": args.bad_rate},
        "customers": customers_summary, "orders": orders_summary,
    }, indent=2) + "\n", encoding="utf-8", newline="\n")

    for name, summary in (("customers", customers_summary), ("orders", orders_summary)):
        print(f"{name:<10} rows={summary['rows_in']:>7}  valid={summary['rows_inserted']:>7}  "
              f"rejected={summary['rows_rejected']:>5}  exact_duplicates={summary['duplicates_dropped']:>4}  "
              f"late={summary['late_records']:>5}")
    print(f"inputs   -> {out_dir}\nexpected -> {expected_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
