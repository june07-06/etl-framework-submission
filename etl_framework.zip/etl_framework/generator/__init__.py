"""Synthetic data generator package."""
